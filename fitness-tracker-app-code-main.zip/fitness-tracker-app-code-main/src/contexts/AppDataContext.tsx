import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

interface Goal {
  id: string;
  title: string;
  description: string;
  category: 'Fitness' | 'Weight' | 'Nutrition' | 'Wellness';
  target_date: string;
  progress: number;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

interface WeightLog {
  id: string;
  date: string;
  weight: number;
  bmi?: number;
  created_at: string;
}

interface Meal {
  id: string;
  date: string;
  meal_type: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
  food_name: string;
  calories: number;
  created_at: string;
}

interface Workout {
  id: string;
  date: string;
  name: string;
  duration: number;
  type: 'Cardio' | 'Strength' | 'Flexibility' | 'Sports' | 'Other';
  calories_burned: number;
  notes?: string;
  created_at: string;
}

interface AppDataContextType {
  goals: Goal[];
  weightLogs: WeightLog[];
  meals: Meal[];
  workouts: Workout[];
  addGoal: (goal: Omit<Goal, 'id' | 'created_at' | 'updated_at'>) => Promise<boolean>;
  updateGoal: (id: string, updates: Partial<Goal>) => Promise<boolean>;
  deleteGoal: (id: string) => Promise<boolean>;
  addWeightLog: (log: Omit<WeightLog, 'id' | 'created_at'>) => Promise<boolean>;
  addMeal: (meal: Omit<Meal, 'id' | 'created_at'>) => Promise<boolean>;
  addWorkout: (workout: Omit<Workout, 'id' | 'created_at'>) => Promise<boolean>;
  deleteMeal: (id: string) => Promise<boolean>;
  deleteWorkout: (id: string) => Promise<boolean>;
  deleteWeightLog: (id: string) => Promise<boolean>;
  getTodayStats: () => { calories: number; workouts: number; weight?: number };
  getCaloriesFromAI: (foodName: string, quantity?: string) => Promise<number>;
  isLoading: boolean;
  refreshData: () => Promise<void>;
  clearAllData: () => void;
}

const AppDataContext = createContext<AppDataContextType | undefined>(undefined);

interface AppDataProviderProps {
  children: ReactNode;
}

export const AppDataProvider: React.FC<AppDataProviderProps> = ({ children }) => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [weightLogs, setWeightLogs] = useState<WeightLog[]>([]);
  const [meals, setMeals] = useState<Meal[]>([]);
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { user, isSupabaseConnected } = useAuth();

  // Ensure user profile exists in profiles table
  const ensureProfileExists = async (): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot ensure profile: no user or Supabase not connected');
      return false;
    }

    try {
      console.log('👤 Checking if profile exists for user:', user.id);
      
      // First check if profile already exists
      const { data: existingProfile, error: checkError } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', user.id)
        .single();

      if (checkError && checkError.code !== 'PGRST116') { // PGRST116 = no rows returned
        console.error('❌ Error checking profile:', checkError);
        return false;
      }

      if (existingProfile) {
        console.log('✅ Profile already exists');
        return true;
      }

      // Profile doesn't exist, create it
      console.log('➕ Creating profile for user:', user.id);
      const { error: insertError } = await supabase
        .from('profiles')
        .insert({
          id: user.id,
          email: user.email || '',
          name: user.user_metadata?.full_name || user.email?.split('@')[0] || 'User'
        });

      if (insertError) {
        console.error('❌ Error creating profile:', insertError);
        return false;
      }

      console.log('✅ Profile created successfully');
      return true;
    } catch (error) {
      console.error('💥 Profile ensure exception:', error);
      return false;
    }
  };

  // Clear all data function
  const clearAllData = () => {
    console.log('🧹 Clearing all app data...');
    setGoals([]);
    setWeightLogs([]);
    setMeals([]);
    setWorkouts([]);
    setIsLoading(false);
    
    try {
      localStorage.removeItem('fittracker_cache');
      sessionStorage.clear();
    } catch (error) {
      console.error('Error clearing cache:', error);
    }
  };

  const fetchAllData = async () => {
    if (!user || !isSupabaseConnected) {
      console.log('🚫 No user or Supabase not connected, clearing data');
      clearAllData();
      return;
    }

    console.log('📊 Fetching all data for user:', user.id);
    setIsLoading(true);

    try {
      // Fetch all data in parallel with individual error handling
      const [goalsResult, weightLogsResult, mealsResult, workoutsResult] = await Promise.allSettled([
        fetchGoals(user.id),
        fetchWeightLogs(user.id),
        fetchMeals(user.id),
        fetchWorkouts(user.id)
      ]);

      // Process results
      if (goalsResult.status === 'fulfilled') {
        setGoals(goalsResult.value);
        console.log('✅ Goals loaded:', goalsResult.value.length);
      } else {
        console.error('❌ Goals fetch failed:', goalsResult.reason);
        setGoals([]);
      }

      if (weightLogsResult.status === 'fulfilled') {
        setWeightLogs(weightLogsResult.value);
        console.log('✅ Weight logs loaded:', weightLogsResult.value.length);
      } else {
        console.error('❌ Weight logs fetch failed:', weightLogsResult.reason);
        setWeightLogs([]);
      }

      if (mealsResult.status === 'fulfilled') {
        setMeals(mealsResult.value);
        console.log('✅ Meals loaded:', mealsResult.value.length);
      } else {
        console.error('❌ Meals fetch failed:', mealsResult.reason);
        setMeals([]);
      }

      if (workoutsResult.status === 'fulfilled') {
        setWorkouts(workoutsResult.value);
        console.log('✅ Workouts loaded:', workoutsResult.value.length);
      } else {
        console.error('❌ Workouts fetch failed:', workoutsResult.reason);
        setWorkouts([]);
      }

      console.log('✅ Data fetch complete');
    } catch (error) {
      console.error('💥 Data fetch error:', error);
      clearAllData();
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!user || !isSupabaseConnected) {
      clearAllData();
      return;
    }
    
    fetchAllData();
  }, [user, isSupabaseConnected]);

  const fetchGoals = async (userId: string): Promise<Goal[]> => {
    try {
      console.log('🎯 Fetching goals for user:', userId);
      
      const { data, error } = await supabase
        .from('goals')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('❌ Goals fetch error:', error);
        throw error;
      }

      console.log('✅ Goals fetched successfully:', data?.length || 0);
      return data || [];
    } catch (error) {
      console.error('💥 Goals fetch exception:', error);
      throw error;
    }
  };

  const fetchWeightLogs = async (userId: string): Promise<WeightLog[]> => {
    try {
      console.log('⚖️ Fetching weight logs for user:', userId);
      
      const { data, error } = await supabase
        .from('weight_logs')
        .select('*')
        .eq('user_id', userId)
        .order('date', { ascending: true });

      if (error) {
        console.error('❌ Weight logs fetch error:', error);
        throw error;
      }

      console.log('✅ Weight logs fetched successfully:', data?.length || 0);
      return data || [];
    } catch (error) {
      console.error('💥 Weight logs fetch exception:', error);
      throw error;
    }
  };

  const fetchMeals = async (userId: string): Promise<Meal[]> => {
    try {
      console.log('🍽️ Fetching meals for user:', userId);
      
      const { data, error } = await supabase
        .from('meals')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('❌ Meals fetch error:', error);
        throw error;
      }

      console.log('✅ Meals fetched successfully:', data?.length || 0);
      return data || [];
    } catch (error) {
      console.error('💥 Meals fetch exception:', error);
      throw error;
    }
  };

  const fetchWorkouts = async (userId: string): Promise<Workout[]> => {
    try {
      console.log('💪 Fetching workouts for user:', userId);
      
      const { data, error } = await supabase
        .from('workouts')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('❌ Workouts fetch error:', error);
        throw error;
      }

      console.log('✅ Workouts fetched successfully:', data?.length || 0);
      return data || [];
    } catch (error) {
      console.error('💥 Workouts fetch exception:', error);
      throw error;
    }
  };

  const addGoal = async (goalData: Omit<Goal, 'id' | 'created_at' | 'updated_at'>): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot add goal: no user or Supabase not connected');
      alert('Please ensure you are logged in and Supabase is configured properly.');
      return false;
    }

    // Ensure profile exists before adding goal
    const profileExists = await ensureProfileExists();
    if (!profileExists) {
      console.error('❌ Cannot add goal: profile does not exist');
      alert('Unable to create user profile. Please try again.');
      return false;
    }

    try {
      console.log('➕ Adding goal:', goalData.title);
      
      // Validate required fields
      if (!goalData.title || !goalData.description || !goalData.target_date) {
        throw new Error('Missing required fields');
      }
      
      const insertData = {
        ...goalData,
        user_id: user.id,
      };

      console.log('📤 Inserting goal data:', insertData);
      
      const { data, error } = await supabase
        .from('goals')
        .insert(insertData)
        .select()
        .single();

      if (error) {
        console.error('❌ Goal insert error:', error);
        console.error('Error details:', {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code
        });
        return false;
      }

      if (!data) {
        console.error('❌ No data returned from goal insert');
        return false;
      }

      console.log('✅ Goal added successfully:', data.id);
      setGoals(prev => [data, ...prev]);
      return true;
    } catch (error) {
      console.error('💥 Goal add exception:', error);
      return false;
    }
  };

  const updateGoal = async (id: string, updates: Partial<Goal>): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot update goal: no user or Supabase not connected');
      return false;
    }

    try {
      console.log('📝 Updating goal:', id, updates);
      
      const { error } = await supabase
        .from('goals')
        .update(updates)
        .eq('id', id)
        .eq('user_id', user.id); // Ensure user can only update their own goals

      if (error) {
        console.error('❌ Goal update error:', error);
        return false;
      }

      console.log('✅ Goal updated successfully');
      setGoals(prev => prev.map(goal => 
        goal.id === id ? { ...goal, ...updates } : goal
      ));
      return true;
    } catch (error) {
      console.error('💥 Goal update exception:', error);
      return false;
    }
  };

  const deleteGoal = async (id: string): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot delete goal: no user or Supabase not connected');
      return false;
    }

    try {
      console.log('🗑️ Deleting goal:', id);
      
      const { error } = await supabase
        .from('goals')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id); // Ensure user can only delete their own goals

      if (error) {
        console.error('❌ Goal delete error:', error);
        return false;
      }

      console.log('✅ Goal deleted successfully');
      setGoals(prev => prev.filter(goal => goal.id !== id));
      return true;
    } catch (error) {
      console.error('💥 Goal delete exception:', error);
      return false;
    }
  };

  const addWeightLog = async (logData: Omit<WeightLog, 'id' | 'created_at'>): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot add weight log: no user or Supabase not connected');
      return false;
    }

    // Ensure profile exists before adding weight log
    const profileExists = await ensureProfileExists();
    if (!profileExists) {
      console.error('❌ Cannot add weight log: profile does not exist');
      return false;
    }

    try {
      console.log('⚖️ Adding weight log:', logData.weight, 'kg on', logData.date);
      
      // Validate required fields
      if (!logData.weight || !logData.date) {
        console.error('❌ Missing required weight log fields');
        return false;
      }
      
      const insertData = {
        ...logData,
        user_id: user.id,
      };

      console.log('📤 Inserting weight log data:', insertData);
      
      const { data, error } = await supabase
        .from('weight_logs')
        .insert(insertData)
        .select()
        .single();

      if (error) {
        console.error('❌ Weight log insert error:', error);
        console.error('Error details:', {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code
        });
        return false;
      }

      if (!data) {
        console.error('❌ No data returned from weight log insert');
        return false;
      }

      console.log('✅ Weight log added successfully:', data.id);
      setWeightLogs(prev => [...prev, data].sort((a, b) => 
        new Date(a.date).getTime() - new Date(b.date).getTime()
      ));
      return true;
    } catch (error) {
      console.error('💥 Weight log add exception:', error);
      return false;
    }
  };

  const addMeal = async (mealData: Omit<Meal, 'id' | 'created_at'>): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot add meal: no user or Supabase not connected');
      return false;
    }

    // Ensure profile exists before adding meal
    const profileExists = await ensureProfileExists();
    if (!profileExists) {
      console.error('❌ Cannot add meal: profile does not exist');
      return false;
    }

    try {
      console.log('🍽️ Adding meal:', mealData.food_name, mealData.calories, 'kcal');
      
      // Validate required fields
      if (!mealData.food_name || !mealData.calories || !mealData.date || !mealData.meal_type) {
        console.error('❌ Missing required meal fields');
        return false;
      }
      
      const insertData = {
        ...mealData,
        user_id: user.id,
      };

      console.log('📤 Inserting meal data:', insertData);
      
      const { data, error } = await supabase
        .from('meals')
        .insert(insertData)
        .select()
        .single();

      if (error) {
        console.error('❌ Meal insert error:', error);
        console.error('Error details:', {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code
        });
        return false;
      }

      if (!data) {
        console.error('❌ No data returned from meal insert');
        return false;
      }

      console.log('✅ Meal added successfully:', data.id);
      setMeals(prev => [data, ...prev]);
      return true;
    } catch (error) {
      console.error('💥 Meal add exception:', error);
      return false;
    }
  };

  const addWorkout = async (workoutData: Omit<Workout, 'id' | 'created_at'>): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot add workout: no user or Supabase not connected');
      return false;
    }

    // Ensure profile exists before adding workout
    const profileExists = await ensureProfileExists();
    if (!profileExists) {
      console.error('❌ Cannot add workout: profile does not exist');
      return false;
    }

    try {
      console.log('💪 Adding workout:', workoutData.name, workoutData.duration, 'min');
      
      // Validate required fields
      if (!workoutData.name || !workoutData.duration || !workoutData.date || !workoutData.type) {
        console.error('❌ Missing required workout fields');
        return false;
      }
      
      const insertData = {
        ...workoutData,
        user_id: user.id,
      };

      console.log('📤 Inserting workout data:', insertData);
      
      const { data, error } = await supabase
        .from('workouts')
        .insert(insertData)
        .select()
        .single();

      if (error) {
        console.error('❌ Workout insert error:', error);
        console.error('Error details:', {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code
        });
        return false;
      }

      if (!data) {
        console.error('❌ No data returned from workout insert');
        return false;
      }

      console.log('✅ Workout added successfully:', data.id);
      setWorkouts(prev => [data, ...prev]);
      return true;
    } catch (error) {
      console.error('💥 Workout add exception:', error);
      return false;
    }
  };

  const deleteMeal = async (id: string): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot delete meal: no user or Supabase not connected');
      return false;
    }

    try {
      console.log('🗑️ Deleting meal:', id);
      
      const { error } = await supabase
        .from('meals')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('❌ Meal delete error:', error);
        return false;
      }

      console.log('✅ Meal deleted successfully');
      setMeals(prev => prev.filter(meal => meal.id !== id));
      return true;
    } catch (error) {
      console.error('💥 Meal delete exception:', error);
      return false;
    }
  };

  const deleteWorkout = async (id: string): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot delete workout: no user or Supabase not connected');
      return false;
    }

    try {
      console.log('🗑️ Deleting workout:', id);
      
      const { error } = await supabase
        .from('workouts')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('❌ Workout delete error:', error);
        return false;
      }

      console.log('✅ Workout deleted successfully');
      setWorkouts(prev => prev.filter(workout => workout.id !== id));
      return true;
    } catch (error) {
      console.error('💥 Workout delete exception:', error);
      return false;
    }
  };

  const deleteWeightLog = async (id: string): Promise<boolean> => {
    if (!user || !isSupabaseConnected) {
      console.error('❌ Cannot delete weight log: no user or Supabase not connected');
      return false;
    }

    try {
      console.log('🗑️ Deleting weight log:', id);
      
      const { error } = await supabase
        .from('weight_logs')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('❌ Weight log delete error:', error);
        return false;
      }

      console.log('✅ Weight log deleted successfully');
      setWeightLogs(prev => prev.filter(log => log.id !== id));
      return true;
    } catch (error) {
      console.error('💥 Weight log delete exception:', error);
      return false;
    }
  };

  const getCaloriesFromAI = async (foodName: string, quantity: string = '1 serving'): Promise<number> => {
    try {
      console.log('🤖 Getting AI calories for:', foodName, quantity);
      
      const { data, error } = await supabase.functions.invoke('get-food-calories', {
        body: { foodName, quantity }
      });

      if (error) {
        console.error('❌ AI calories error:', error);
        return 0;
      }

      const calories = data?.calories || 0;
      console.log('✅ AI calories result:', calories);
      return calories;
    } catch (error) {
      console.error('💥 AI calories exception:', error);
      return 0;
    }
  };

  const getTodayStats = () => {
    const today = new Date().toISOString().split('T')[0];
    const todayMeals = meals.filter(meal => meal.date === today);
    const todayWorkouts = workouts.filter(workout => workout.date === today);
    const latestWeight = weightLogs.length > 0 ? weightLogs[weightLogs.length - 1].weight : undefined;

    const stats = {
      calories: todayMeals.reduce((sum, meal) => sum + meal.calories, 0),
      workouts: todayWorkouts.length,
      weight: latestWeight
    };

    console.log('📊 Today stats:', stats);
    return stats;
  };

  const refreshData = async () => {
    console.log('🔄 Refreshing all data...');
    await fetchAllData();
  };

  return (
    <AppDataContext.Provider value={{
      goals,
      weightLogs,
      meals,
      workouts,
      addGoal,
      updateGoal,
      deleteGoal,
      addWeightLog,
      addMeal,
      addWorkout,
      deleteMeal,
      deleteWorkout,
      deleteWeightLog,
      getTodayStats,
      getCaloriesFromAI,
      isLoading,
      refreshData,
      clearAllData
    }}>
      {children}
    </AppDataContext.Provider>
  );
};

export const useAppData = () => {
  const context = useContext(AppDataContext);
  if (context === undefined) {
    throw new Error('useAppData must be used within an AppDataProvider');
  }
  return context;
};