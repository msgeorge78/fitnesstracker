import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

interface Profile {
  id: string;
  email: string;
  name: string;
  height?: number;
  created_at: string;
  updated_at: string;
}

interface AuthResult {
  success: boolean;
  error?: string;
}

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  login: (email: string, password: string) => Promise<AuthResult>;
  register: (email: string, password: string, name: string) => Promise<AuthResult>;
  resetPassword: (email: string) => Promise<AuthResult>;
  logout: () => Promise<void>;
  updateProfile: (profileData: Partial<Profile>) => Promise<boolean>;
  isLoading: boolean;
  isSupabaseConnected: boolean;
  uid: () => string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSupabaseConnected, setIsSupabaseConnected] = useState(false);

  useEffect(() => {
    let mounted = true;
    let authSubscription: any = null;

    const initializeAuth = async () => {
      try {
        console.log('🔄 Initializing authentication system...');
        
        // Check Supabase configuration
        setIsSupabaseConnected(isSupabaseConfigured);
        
        if (!isSupabaseConfigured) {
          console.error('❌ Supabase connection failed');
          console.log('⚠️ Supabase not configured - running in demo mode');
          if (mounted) {
            setUser(null);
            setProfile(null);
            setIsLoading(false);
          }
          return;
        }

        console.log('🔗 Getting current session...');
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('❌ Session error:', error);
          if (mounted) {
            setUser(null);
            setProfile(null);
            setIsLoading(false);
          }
          return;
        }

        console.log('✅ Session check complete:', session ? 'User found' : 'No session');

        if (mounted) {
          setUser(session?.user ?? null);
          
          if (session?.user) {
            console.log('👤 Loading user profile...');
            await fetchProfile(session.user.id);
          } else {
            setProfile(null);
            setIsLoading(false);
          }
        }

        // Set up auth state listener only if Supabase is configured
        if (isSupabaseConfigured && supabase) {
          console.log('🔄 Setting up auth state listener...');
          const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
            console.log('🔄 Auth state changed:', event);
            
            if (!mounted) return;

            setUser(session?.user ?? null);
            
            if (session?.user) {
              await fetchProfile(session.user.id);
            } else {
              setProfile(null);
              setIsLoading(false);
            }
          });
          
          authSubscription = subscription;
        }
      } catch (error) {
        console.error('💥 Auth initialization error:', error);
        if (mounted) {
          setUser(null);
          setProfile(null);
          setIsLoading(false);
        }
      }
    };

    // Initialize with timeout
    const timeoutId = setTimeout(() => {
      if (mounted && isLoading) {
        console.log('⏰ Auth initialization timeout');
        setIsLoading(false);
      }
    }, 10000);

    initializeAuth();

    return () => {
      mounted = false;
      clearTimeout(timeoutId);
      if (authSubscription) {
        authSubscription.unsubscribe();
      }
    };
  }, []);

  const fetchProfile = async (userId: string) => {
    if (!isSupabaseConfigured || !supabase) {
      console.error('❌ Cannot fetch profile: Supabase not configured');
      setProfile(null);
      setIsLoading(false);
      return;
    }

    try {
      console.log('📋 Fetching profile for user:', userId);
      
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.error('❌ Profile fetch error:', error);
        setProfile(null);
        setIsLoading(false);
        return;
      }

      console.log('✅ Profile loaded:', data ? 'Success' : 'No profile found');
      setProfile(data);
      setIsLoading(false);
    } catch (error) {
      console.error('💥 Profile fetch exception:', error);
      setProfile(null);
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<AuthResult> => {
    try {
      console.log('🔐 Attempting login for:', email);
      
      if (!isSupabaseConfigured || !supabase) {
        throw new Error('Supabase is not configured')
      }
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        console.error('❌ Login error:', error);
        return {
          success: false,
          error: error.message
        };
      }

      if (data.user) {
        console.log('✅ Login successful for user:', data.user.id);
        return { success: true };
      }

      return {
        success: false,
        error: 'Login failed - no user returned'
      };
    } catch (error) {
      console.error('💥 Login exception:', error);
      return {
        success: false,
        error: 'An unexpected error occurred. Please try again.'
      };
    }
  };

  const register = async (email: string, password: string, name: string): Promise<AuthResult> => {
    try {
      console.log('📝 Attempting registration for:', email);
      
      if (!isSupabaseConfigured || !supabase) {
        throw new Error('Supabase is not configured')
      }
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: name,
            display_name: name
          }
        }
      });

      if (error) {
        console.error('❌ Registration error:', error);
        return {
          success: false,
          error: error.message
        };
      }

      if (data.user) {
        console.log('👤 User created, setting up profile...');
        
        // Create profile with retry logic
        let profileCreated = false;
        let attempts = 0;
        const maxAttempts = 3;

        while (!profileCreated && attempts < maxAttempts) {
          attempts++;
          console.log(`📋 Profile creation attempt ${attempts}/${maxAttempts}`);
          
          const { error: profileError } = await supabase
            .from('profiles')
            .insert({
              id: data.user.id,
              email,
              name,
            });

          if (profileError) {
            console.error(`❌ Profile creation attempt ${attempts} failed:`, profileError);
            if (attempts === maxAttempts) {
              return {
                success: false,
                error: 'Failed to create user profile. Please try again.'
              };
            }
            // Wait before retry
            await new Promise(resolve => setTimeout(resolve, 1000));
          } else {
            profileCreated = true;
            console.log('✅ Profile created successfully');
          }
        }
      }

      return { success: true };
    } catch (error) {
      console.error('💥 Registration exception:', error);
      return {
        success: false,
        error: 'An unexpected error occurred. Please try again.'
      };
    }
  };

  const resetPassword = async (email: string): Promise<AuthResult> => {
    try {
      console.log('🔐 Attempting password reset for:', email);
      
      if (!isSupabaseConfigured || !supabase) {
        throw new Error('Supabase is not configured')
      }
      
      // Use the current origin (works for both local and production)
      const redirectUrl = `${window.location.origin}/reset-password`;
      console.log('🔗 Reset redirect URL:', redirectUrl);
      
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: redirectUrl,
        captchaToken: undefined
      });

      if (error) {
        console.error('❌ Password reset error:', error);
        return {
          success: false,
          error: error.message
        };
      }

      console.log('✅ Password reset email sent successfully');
      return { success: true };
    } catch (error) {
      console.error('💥 Password reset exception:', error);
      return {
        success: false,
        error: 'An unexpected error occurred. Please try again.'
      };
    }
  };

  const logout = async () => {
    try {
      console.log('🚪 Logging out...');
      
      // Clear local state first
      setUser(null);
      setProfile(null);
      setIsLoading(false);
      
      // Clear storage
      try {
        localStorage.clear();
        sessionStorage.clear();
      } catch (error) {
        console.error('Error clearing storage:', error);
      }
      
      if (!isSupabaseConfigured || !supabase) {
        throw new Error('Supabase is not configured')
      }
      
      // Sign out from Supabase
      const { error } = await supabase.auth.signOut({ scope: 'global' });
      
      if (error) {
        console.error('❌ Logout error:', error);
      } else {
        console.log('✅ Logout successful');
      }
    } catch (error) {
      console.error('💥 Logout exception:', error);
    }
  };

  const updateProfile = async (profileData: Partial<Profile>): Promise<boolean> => {
    if (!user || !isSupabaseConfigured || !supabase) {
      console.error('❌ Cannot update profile: no user or Supabase not configured');
      return false;
    }

    try {
      console.log('📝 Updating profile for user:', user.id);
      
      const { error } = await supabase
        .from('profiles')
        .update(profileData)
        .eq('id', user.id);

      if (error) {
        console.error('❌ Profile update error:', error);
        return false;
      }

      console.log('✅ Profile updated successfully');
      setProfile(prev => prev ? { ...prev, ...profileData } : null);
      return true;
    } catch (error) {
      console.error('💥 Profile update exception:', error);
      return false;
    }
  };

  const uid = (): string | null => {
    return user?.id || null;
  };

  return (
    <AuthContext.Provider value={{
      user,
      profile,
      login,
      register,
      resetPassword,
      logout,
      updateProfile,
      isLoading,
      isSupabaseConnected,
      uid
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};