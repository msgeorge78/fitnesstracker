export interface User {
  id: string;
  email: string;
  name: string;
  height?: number;
  profilePicture?: string;
  createdAt: string;
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  category: 'Fitness' | 'Weight' | 'Nutrition' | 'Wellness';
  targetDate: string;
  progress: number;
  completed: boolean;
  createdAt: string;
}

export interface WeightLog {
  id: string;
  date: string;
  weight: number;
  bmi?: number;
  userId: string;
}

export interface Meal {
  id: string;
  date: string;
  mealType: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
  foodName: string;
  calories: number;
  userId: string;
}

export interface Workout {
  id: string;
  date: string;
  name: string;
  duration: number;
  type: 'Cardio' | 'Strength' | 'Flexibility' | 'Sports' | 'Other';
  caloriesBurned: number;
  notes?: string;
  userId: string;
}

export interface AppData {
  user: User | null;
  goals: Goal[];
  weightLogs: WeightLog[];
  meals: Meal[];
  workouts: Workout[];
}