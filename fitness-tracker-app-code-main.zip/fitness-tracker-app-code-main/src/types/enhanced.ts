export interface EnhancedUser {
  id: string;
  email: string;
  name: string;
  height?: number;
  profilePicture?: string;
  achievements: Achievement[];
  streaks: UserStreaks;
  nutritionTargets: NutritionTargets;
  createdAt: string;
  updatedAt: string;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  category: 'consistency' | 'goals' | 'activity' | 'nutrition';
  icon: string;
  dateEarned?: string;
  progress: number;
  target: number;
  unlocked: boolean;
}

export interface UserStreaks {
  currentWorkoutStreak: number;
  longestWorkoutStreak: number;
  currentNutritionStreak: number;
  longestNutritionStreak: number;
  lastWorkoutDate?: string;
  lastNutritionDate?: string;
}

export interface NutritionTargets {
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
}

export interface Food {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  servingSize: string;
  category: string;
}

export interface MealFood {
  foodId: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  quantity: number;
  servingSize: string;
}

export interface EnhancedMeal {
  id: string;
  date: string;
  meal_type: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
  foods: MealFood[];
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFats: number;
  created_at: string;
}

export interface Exercise {
  id: string;
  name: string;
  category: 'Cardio' | 'Strength' | 'Flexibility' | 'Sports' | 'Other';
  muscleGroups: string[];
  caloriesPerMinute: number;
  instructions?: string;
}

export interface WorkoutExercise {
  exerciseId: string;
  name: string;
  sets?: number;
  reps?: number;
  weight?: number;
  duration: number;
  calories: number;
  restTime?: number;
}

export interface EnhancedWorkout {
  id: string;
  date: string;
  name: string;
  exercises: WorkoutExercise[];
  totalDuration: number;
  totalCalories: number;
  notes?: string;
  created_at: string;
}

export interface ProgressPhoto {
  id: string;
  date: string;
  imageUrl: string;
  notes?: string;
  weight?: number;
  created_at: string;
}

export interface ChartDataPoint {
  date: string;
  value: number;
  label?: string;
}

export interface DashboardStats {
  weeklyCaloriesIn: number;
  weeklyCaloriesOut: number;
  weeklyWorkouts: number;
  currentStreak: number;
  completedGoals: number;
  recentAchievements: Achievement[];
}