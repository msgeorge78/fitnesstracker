import React, { useState, useEffect } from 'react';
import { Trophy, Target, Activity, Utensils, Calendar, Filter } from 'lucide-react';
import AchievementBadge from '../components/achievements/AchievementBadge';
import { Achievement } from '../types/enhanced';
import { generateAchievements, checkAchievements } from '../data/achievements';
import { useAppData } from '../contexts/AppDataContext';

const Achievements: React.FC = () => {
  const { goals, workouts, meals } = useAppData();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [filter, setFilter] = useState<'all' | 'unlocked' | 'locked'>('all');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'consistency' | 'goals' | 'activity' | 'nutrition'>('all');

  // Initialize and update achievements
  useEffect(() => {
    const savedAchievements = localStorage.getItem('user_achievements');
    let currentAchievements: Achievement[];
    
    if (savedAchievements) {
      currentAchievements = JSON.parse(savedAchievements);
    } else {
      currentAchievements = generateAchievements();
    }

    // Update achievements based on current data
    const completedGoals = goals.filter(goal => goal.completed).length;
    const totalCaloriesBurned = workouts.reduce((sum, workout) => sum + workout.calories_burned, 0);

    // Calculate streaks
    const workoutDates = [...new Set(workouts.map(w => w.date))].sort();
    const mealDates = [...new Set(meals.map(m => m.date))].sort();

    const calculateStreak = (dates: string[]) => {
      if (dates.length === 0) return 0;
      
      let streak = 0;
      const today = new Date();
      let currentDate = new Date(today);
      
      for (let i = 0; i < 365; i++) {
        const dateStr = currentDate.toISOString().split('T')[0];
        if (dates.includes(dateStr)) {
          streak++;
        } else if (streak > 0) {
          break;
        }
        currentDate.setDate(currentDate.getDate() - 1);
      }
      
      return streak;
    };

    const workoutStreak = calculateStreak(workoutDates);
    const nutritionStreak = calculateStreak(mealDates);

    const stats = {
      totalWorkouts: workouts.length,
      totalMeals: meals.length,
      completedGoals,
      totalCaloriesBurned,
      workoutStreak,
      nutritionStreak,
      proteinGoalDays: 0,
      macroGoalDays: 0
    };

    const updatedAchievements = checkAchievements(currentAchievements, stats);
    setAchievements(updatedAchievements);
    localStorage.setItem('user_achievements', JSON.stringify(updatedAchievements));
  }, [goals, workouts, meals]);

  const filteredAchievements = achievements.filter(achievement => {
    const statusMatch = filter === 'all' || 
                       (filter === 'unlocked' && achievement.unlocked) ||
                       (filter === 'locked' && !achievement.unlocked);
    
    const categoryMatch = categoryFilter === 'all' || achievement.category === categoryFilter;
    
    return statusMatch && categoryMatch;
  });

  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalCount = achievements.length;
  const completionPercentage = Math.round((unlockedCount / totalCount) * 100);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'consistency':
        return Calendar;
      case 'goals':
        return Target;
      case 'activity':
        return Activity;
      case 'nutrition':
        return Utensils;
      default:
        return Trophy;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'consistency':
        return 'bg-blue-100 text-blue-800';
      case 'goals':
        return 'bg-purple-100 text-purple-800';
      case 'activity':
        return 'bg-green-100 text-green-800';
      case 'nutrition':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Achievements</h1>
          <p className="text-gray-600 mt-1">Track your fitness milestones and unlock rewards</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-gray-900">{unlockedCount}/{totalCount}</p>
          <p className="text-sm text-gray-600">Achievements Unlocked</p>
        </div>
      </div>

      {/* Progress Overview */}
      <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">Achievement Progress</h2>
            <p className="text-yellow-100 text-lg">{completionPercentage}% Complete</p>
            <div className="w-64 bg-yellow-300 rounded-full h-3 mt-3">
              <div
                className="bg-white h-3 rounded-full transition-all duration-300"
                style={{ width: `${completionPercentage}%` }}
              />
            </div>
          </div>
          <Trophy className="h-16 w-16 text-white opacity-20" />
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-gray-500" />
            <span className="text-sm font-medium text-gray-700">Filter by:</span>
          </div>
          
          <div className="flex space-x-2">
            {['all', 'unlocked', 'locked'].map((status) => (
              <button
                key={status}
                onClick={() => setFilter(status as any)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filter === status
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {status.charAt(0).toUpperCase() + status.slice(1)}
              </button>
            ))}
          </div>

          <div className="flex space-x-2">
            {['all', 'consistency', 'goals', 'activity', 'nutrition'].map((category) => (
              <button
                key={category}
                onClick={() => setCategoryFilter(category as any)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  categoryFilter === category
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Achievement Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {['consistency', 'goals', 'activity', 'nutrition'].map((category) => {
          const categoryAchievements = achievements.filter(a => a.category === category);
          const unlockedInCategory = categoryAchievements.filter(a => a.unlocked).length;
          const Icon = getCategoryIcon(category);
          
          return (
            <div key={category} className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center space-x-3 mb-4">
                <div className={`p-2 rounded-lg ${getCategoryColor(category)}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 capitalize">{category}</h3>
                  <p className="text-sm text-gray-600">
                    {unlockedInCategory}/{categoryAchievements.length} unlocked
                  </p>
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ 
                    width: `${categoryAchievements.length > 0 ? (unlockedInCategory / categoryAchievements.length) * 100 : 0}%` 
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Achievements Grid */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">
          {filter === 'all' ? 'All Achievements' : 
           filter === 'unlocked' ? 'Unlocked Achievements' : 'Locked Achievements'}
          {categoryFilter !== 'all' && ` - ${categoryFilter.charAt(0).toUpperCase() + categoryFilter.slice(1)}`}
        </h2>
        
        {filteredAchievements.length === 0 ? (
          <div className="text-center py-12">
            <Trophy className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No achievements found</h3>
            <p className="text-gray-600">Try adjusting your filters or keep working towards your goals!</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
            {filteredAchievements.map((achievement) => (
              <AchievementBadge
                key={achievement.id}
                achievement={achievement}
                size="medium"
                showProgress={true}
              />
            ))}
          </div>
        )}
      </div>

      {/* Recent Achievements */}
      {achievements.filter(a => a.unlocked && a.dateEarned).length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Recently Unlocked</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {achievements
              .filter(a => a.unlocked && a.dateEarned)
              .sort((a, b) => new Date(b.dateEarned!).getTime() - new Date(a.dateEarned!).getTime())
              .slice(0, 6)
              .map((achievement) => (
                <AchievementBadge
                  key={achievement.id}
                  achievement={achievement}
                  size="medium"
                  showProgress={false}
                />
              ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Achievements;