import React, { useState } from 'react';
import { useAppData } from '../contexts/AppDataContext';
import ReminderSystem from '../components/reminders/ReminderSystem';
import NotificationManager from '../components/notifications/NotificationManager';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'reminder' | 'achievement' | 'goal' | 'hydration';
  timestamp: Date;
  read: boolean;
}

const SmartReminders: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const handleCreateNotification = (title: string, message: string, type: string) => {
    const newNotification: Notification = {
      id: Date.now().toString(),
      title,
      message,
      type: type as any,
      timestamp: new Date(),
      read: false
    };

    setNotifications(prev => [newNotification, ...prev]);
  };

  const handleMarkAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const handleClearAll = () => {
    setNotifications([]);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Smart Reminders & Notifications</h1>
          <p className="text-gray-600 mt-1">Stay on track with personalized reminders and real-time notifications</p>
        </div>
        <NotificationManager
          notifications={notifications}
          onMarkAsRead={handleMarkAsRead}
          onClearAll={handleClearAll}
        />
      </div>

      <ReminderSystem onCreateNotification={handleCreateNotification} />
    </div>
  );
};

export default SmartReminders;