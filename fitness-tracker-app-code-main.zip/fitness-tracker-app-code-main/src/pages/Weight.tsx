import React, { useState } from 'react';
import { useAppData } from '../contexts/AppDataContext';
import { useAuth } from '../contexts/AuthContext';
import { Scale, Plus, TrendingUp, Calendar, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';

const Weight: React.FC = () => {
  const { profile, updateProfile } = useAuth();
  const { weightLogs, addWeightLog } = useAppData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [weight, setWeight] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [height, setHeight] = useState(profile?.height?.toString() || '');
  const [showHeightInput, setShowHeightInput] = useState(!profile?.height);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const calculateBMI = (height: number, weight: number): number => {
    const heightInMeters = height / 100;
    return Number((weight / (heightInMeters * heightInMeters)).toFixed(1));
  };

  const getBMICategory = (bmi: number): string => {
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal weight';
    if (bmi < 30) return 'Overweight';
    return 'Obese';
  };

  const formatDate = (date: string): string => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const weightNum = parseFloat(weight);
      const heightNum = parseFloat(height);

      // Validate inputs
      if (isNaN(weightNum) || weightNum <= 0) {
        setSubmitStatus('error');
        setIsSubmitting(false);
        return;
      }

      if (!profile?.height && heightNum > 0) {
        await updateProfile({ height: heightNum });
      }

      const bmi = heightNum > 0 ? calculateBMI(heightNum, weightNum) : undefined;

      const success = await addWeightLog({
        date,
        weight: weightNum,
        bmi
      });

      if (success) {
        setSubmitStatus('success');
        setWeight('');
        setDate(new Date().toISOString().split('T')[0]);
        
        // Close modal after short delay
        setTimeout(() => {
          setIsModalOpen(false);
          setSubmitStatus('idle');
        }, 1500);
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Error submitting weight log:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const latestEntry = weightLogs.length > 0 ? weightLogs[weightLogs.length - 1] : null;
  const previousEntry = weightLogs.length > 1 ? weightLogs[weightLogs.length - 2] : null;
  const weightChange = latestEntry && previousEntry ? latestEntry.weight - previousEntry.weight : 0;

  const calculateBMIForDisplay = () => {
    if (!latestEntry || !profile?.height) return null;
    return calculateBMI(profile.height, latestEntry.weight);
  };

  const bmiValue = calculateBMIForDisplay();

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Weight Tracking</h1>
          <p className="text-gray-600 mt-1">Monitor your weight progress and BMI</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-green-700 transition-all duration-200 transform hover:scale-105"
        >
          <Plus className="h-5 w-5" />
          <span>Log Weight</span>
        </button>
      </div>

      {/* Current Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-100 rounded-xl">
              <Scale className="h-6 w-6 text-blue-600" />
            </div>
            {weightChange !== 0 && (
              <div className={`flex items-center space-x-1 ${weightChange > 0 ? 'text-red-600' : 'text-green-600'}`}>
                <TrendingUp className={`h-4 w-4 ${weightChange < 0 ? 'transform rotate-180' : ''}`} />
                <span className="text-sm font-medium">{Math.abs(weightChange).toFixed(1)} kg</span>
              </div>
            )}
          </div>
          <h3 className="text-lg font-semibold text-gray-900">Current Weight</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">
            {latestEntry ? `${latestEntry.weight} kg` : 'No data'}
          </p>
          {latestEntry && (
            <p className="text-sm text-gray-600 mt-1">
              Last updated: {formatDate(latestEntry.date)}
            </p>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-100 rounded-xl">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-lg font-semibold text-gray-900">BMI</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">
            {bmiValue ? bmiValue.toFixed(1) : 'N/A'}
          </p>
          {bmiValue && (
            <p className="text-sm text-gray-600 mt-1">
              {getBMICategory(bmiValue)}
            </p>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-purple-100 rounded-xl">
              <Calendar className="h-6 w-6 text-purple-600" />
            </div>
          </div>
          <h3 className="text-lg font-semibold text-gray-900">Total Entries</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">{weightLogs.length}</p>
          <p className="text-sm text-gray-600 mt-1">Weight logs recorded</p>
        </div>
      </div>

      {/* BMI Calculator */}
      {!profile?.height && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-yellow-800 mb-2">Set Your Height</h3>
          <p className="text-yellow-700 mb-4">
            To calculate your BMI, please enter your height in the next weight entry.
          </p>
        </div>
      )}

      {/* Weight History */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Weight History</h2>
        {weightLogs.length === 0 ? (
          <div className="text-center py-12">
            <Scale className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No weight entries</h3>
            <p className="text-gray-600 mb-4">Start tracking your weight to see your progress</p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Log First Entry
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {weightLogs.slice().reverse().map((entry) => (
              <div key={entry.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Scale className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{entry.weight} kg</p>
                    <p className="text-sm text-gray-600">{formatDate(entry.date)}</p>
                  </div>
                </div>
                <div className="text-right">
                  {entry.bmi && (
                    <>
                      <p className="font-medium text-gray-900">BMI: {entry.bmi}</p>
                      <p className="text-sm text-gray-600">{getBMICategory(entry.bmi)}</p>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Log Weight Entry</h2>
            
            {submitStatus === 'success' && (
              <div className="mb-4 p-3 bg-green-100 border border-green-200 rounded-lg flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="text-green-800">Weight logged successfully!</span>
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="mb-4 p-3 bg-red-100 border border-red-200 rounded-lg flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <span className="text-red-800">Failed to log weight. Please try again.</span>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Weight (kg)</label>
                <input
                  type="number"
                  step="0.1"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              {(!profile?.height || showHeightInput) && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Height (cm)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required={!profile?.height}
                  />
                  {profile?.height && (
                    <p className="text-sm text-gray-600 mt-1">
                      Current height: {profile.height} cm
                    </p>
                  )}
                </div>
              )}

              {profile?.height && !showHeightInput && (
                <button
                  type="button"
                  onClick={() => setShowHeightInput(true)}
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  Update height
                </button>
              )}

              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setSubmitStatus('idle');
                    setWeight('');
                    setDate(new Date().toISOString().split('T')[0]);
                    setShowHeightInput(!profile?.height);
                  }}
                  className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Logging...
                    </>
                  ) : (
                    'Log Entry'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Weight;