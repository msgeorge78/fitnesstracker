import React, { useState } from 'react';
import { Camera, Plus, Calendar, Trash2, Eye } from 'lucide-react';
import ProgressPhotoUpload from '../components/photos/ProgressPhotoUpload';
import { ProgressPhoto } from '../types/enhanced';

const ProgressPhotos: React.FC = () => {
  const [photos, setPhotos] = useState<ProgressPhoto[]>([]);
  const [showUpload, setShowUpload] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<ProgressPhoto | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'timeline'>('grid');

  const handlePhotoUpload = (file: File, notes?: string) => {
    // In a real app, you'd upload to a cloud storage service
    const reader = new FileReader();
    reader.onload = () => {
      const newPhoto: ProgressPhoto = {
        id: Date.now().toString(),
        date: new Date().toISOString().split('T')[0],
        imageUrl: reader.result as string,
        notes,
        created_at: new Date().toISOString()
      };
      
      setPhotos(prev => [newPhoto, ...prev]);
      
      // Save to localStorage for demo
      const savedPhotos = [...photos, newPhoto];
      localStorage.setItem('progress_photos', JSON.stringify(savedPhotos));
    };
    reader.readAsDataURL(file);
  };

  const handleDeletePhoto = (id: string) => {
    if (confirm('Are you sure you want to delete this photo?')) {
      const updatedPhotos = photos.filter(photo => photo.id !== id);
      setPhotos(updatedPhotos);
      localStorage.setItem('progress_photos', JSON.stringify(updatedPhotos));
    }
  };

  // Load photos from localStorage on component mount
  React.useEffect(() => {
    const savedPhotos = localStorage.getItem('progress_photos');
    if (savedPhotos) {
      setPhotos(JSON.parse(savedPhotos));
    }
  }, []);

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const groupedPhotos = photos.reduce((acc, photo) => {
    const month = new Date(photo.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
    if (!acc[month]) {
      acc[month] = [];
    }
    acc[month].push(photo);
    return acc;
  }, {} as Record<string, ProgressPhoto[]>);

  const sortedMonths = Object.keys(groupedPhotos).sort((a, b) => 
    new Date(b).getTime() - new Date(a).getTime()
  );

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Progress Photos</h1>
          <p className="text-gray-600 mt-1">Track your transformation with visual progress</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'grid'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Grid
            </button>
            <button
              onClick={() => setViewMode('timeline')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'timeline'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Timeline
            </button>
          </div>
          <button
            onClick={() => setShowUpload(true)}
            className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-green-700 transition-all duration-200 transform hover:scale-105"
          >
            <Plus className="h-5 w-5" />
            <span>Add Photo</span>
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-blue-100 rounded-xl">
              <Camera className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Total Photos</p>
              <p className="text-2xl font-bold text-gray-900">{photos.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-green-100 rounded-xl">
              <Calendar className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">First Photo</p>
              <p className="text-lg font-bold text-gray-900">
                {photos.length > 0 
                  ? formatDate(photos[photos.length - 1].date)
                  : 'No photos yet'
                }
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-purple-100 rounded-xl">
              <Eye className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Latest Photo</p>
              <p className="text-lg font-bold text-gray-900">
                {photos.length > 0 
                  ? formatDate(photos[0].date)
                  : 'No photos yet'
                }
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Photos Display */}
      {photos.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-12">
          <div className="text-center">
            <Camera className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No progress photos yet</h3>
            <p className="text-gray-600 mb-6">Start documenting your fitness journey with progress photos</p>
            <button
              onClick={() => setShowUpload(true)}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Add Your First Photo
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {photos.map((photo) => (
                <div key={photo.id} className="group relative">
                  <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
                    <img
                      src={photo.imageUrl}
                      alt={`Progress photo from ${formatDate(photo.date)}`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    />
                  </div>
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-200 rounded-lg flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex space-x-2">
                      <button
                        onClick={() => setSelectedPhoto(photo)}
                        className="bg-white text-gray-900 p-2 rounded-full hover:bg-gray-100 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeletePhoto(photo.id)}
                        className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="mt-2">
                    <p className="text-sm font-medium text-gray-900">{formatDate(photo.date)}</p>
                    {photo.notes && (
                      <p className="text-xs text-gray-600 mt-1 line-clamp-2">{photo.notes}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-8">
              {sortedMonths.map((month) => (
                <div key={month}>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">{month}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    {groupedPhotos[month].map((photo) => (
                      <div key={photo.id} className="group relative">
                        <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
                          <img
                            src={photo.imageUrl}
                            alt={`Progress photo from ${formatDate(photo.date)}`}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                          />
                        </div>
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-200 rounded-lg flex items-center justify-center">
                          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex space-x-2">
                            <button
                              onClick={() => setSelectedPhoto(photo)}
                              className="bg-white text-gray-900 p-2 rounded-full hover:bg-gray-100 transition-colors"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeletePhoto(photo.id)}
                              className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                        <p className="text-xs text-gray-600 mt-1 text-center">
                          {new Date(photo.date).getDate()}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Photo Upload Modal */}
      {showUpload && (
        <ProgressPhotoUpload
          onUpload={handlePhotoUpload}
          onClose={() => setShowUpload(false)}
        />
      )}

      {/* Photo View Modal */}
      {selectedPhoto && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                Progress Photo - {formatDate(selectedPhoto.date)}
              </h3>
              <button
                onClick={() => setSelectedPhoto(null)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                ✕
              </button>
            </div>
            
            <div className="mb-4">
              <img
                src={selectedPhoto.imageUrl}
                alt={`Progress photo from ${formatDate(selectedPhoto.date)}`}
                className="w-full rounded-lg"
              />
            </div>
            
            {selectedPhoto.notes && (
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Notes</h4>
                <p className="text-gray-700">{selectedPhoto.notes}</p>
              </div>
            )}
            
            <div className="flex justify-end space-x-4 mt-6">
              <button
                onClick={() => handleDeletePhoto(selectedPhoto.id)}
                className="flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete</span>
              </button>
              <button
                onClick={() => setSelectedPhoto(null)}
                className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProgressPhotos;