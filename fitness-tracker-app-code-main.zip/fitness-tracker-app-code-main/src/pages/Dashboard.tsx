import React, { useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useAppData } from '../contexts/AppDataContext';
import { Target, Scale, Utensils, Activity, TrendingUp, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const { profile } = useAuth();
  const { goals, getTodayStats, isLoading } = useAppData();

  console.log('📊 Dashboard render - isLoading:', isLoading, 'goals:', goals.length);

  // Force show content after 3 seconds even if still loading
  const [forceShow, setForceShow] = React.useState(false);
  
  React.useEffect(() => {
    const timer = setTimeout(() => {
      setForceShow(true);
    }, 3000);
    
    return () => clearTimeout(timer);
  }, []);

  if (isLoading && !forceShow) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
          <p className="text-sm text-gray-500 mt-2">This should only take a moment...</p>
        </div>
      </div>
    );
  }

  const todayStats = getTodayStats();
  const activeGoals = goals.filter(goal => !goal.completed);
  const completedGoals = goals.filter(goal => goal.completed);
  
  console.log('📈 Dashboard stats:', {
    totalGoals: goals.length,
    activeGoals: activeGoals.length,
    completedGoals: completedGoals.length,
    todayStats
  });

  const quickStats = [
    {
      label: 'Today\'s Calories',
      value: todayStats.calories,
      unit: 'kcal',
      icon: Utensils,
      color: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-50'
    },
    {
      label: 'Workouts Today',
      value: todayStats.workouts,
      unit: 'sessions',
      icon: Activity,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      label: 'Active Goals',
      value: activeGoals.length,
      unit: 'goals',
      icon: Target,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      label: 'Current Weight',
      value: todayStats.weight || 0,
      unit: 'kg',
      icon: Scale,
      color: 'from-orange-500 to-red-500',
      bgColor: 'bg-orange-50'
    }
  ];

  const quickActions = [
    { name: 'Log Food', href: '/nutrition', icon: Utensils, color: 'bg-green-500' },
    { name: 'Add Workout', href: '/workouts', icon: Activity, color: 'bg-blue-500' },
    { name: 'Set Goal', href: '/goals', icon: Target, color: 'bg-purple-500' },
    { name: 'Track Weight', href: '/weight', icon: Scale, color: 'bg-orange-500' }
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Welcome back, {profile?.name}!</h1>
            <p className="text-blue-100 text-lg">
              {new Date().toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </p>
          </div>
          <TrendingUp className="h-16 w-16 text-white opacity-20" />
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {quickStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className={`${stat.bgColor} rounded-2xl p-6 border border-gray-100`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">
                    {stat.value} <span className="text-lg font-medium text-gray-600">{stat.unit}</span>
                  </p>
                </div>
                <div className={`p-3 rounded-xl bg-gradient-to-r ${stat.color}`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Link
                key={index}
                to={action.href}
                className="flex flex-col items-center p-4 rounded-xl hover:bg-gray-50 transition-colors group"
              >
                <div className={`p-3 rounded-xl ${action.color} group-hover:scale-110 transition-transform`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <span className="text-sm font-medium text-gray-700 mt-2">{action.name}</span>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Goals Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Active Goals</h2>
            <Link to="/goals" className="text-blue-600 hover:text-blue-800 text-sm font-medium">
              View All
            </Link>
          </div>
          {activeGoals.length === 0 ? (
            <div className="text-center py-8">
              <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No active goals yet</p>
              <Link to="/goals" className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                Create your first goal
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {activeGoals.slice(0, 3).map((goal) => (
                <div key={goal.id} className="border-l-4 border-blue-500 pl-4 py-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">{goal.title}</h3>
                      <p className="text-sm text-gray-600">{goal.category}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">{goal.progress}%</p>
                      <div className="w-20 bg-gray-200 rounded-full h-2 mt-1">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${goal.progress}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {completedGoals.length > 0 && (
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Target className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">Goal Completed</p>
                  <p className="text-xs text-gray-600">{completedGoals[0].title}</p>
                </div>
              </div>
            )}
            {todayStats.calories > 0 && (
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Utensils className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">Calories Logged</p>
                  <p className="text-xs text-gray-600">{todayStats.calories} kcal today</p>
                </div>
              </div>
            )}
            {todayStats.workouts > 0 && (
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Activity className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">Workout Completed</p>
                  <p className="text-xs text-gray-600">{todayStats.workouts} session(s) today</p>
                </div>
              </div>
            )}
            {completedGoals.length === 0 && todayStats.calories === 0 && todayStats.workouts === 0 && (
              <div className="text-center py-8">
                <div className="text-center">
                  <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No recent activity</p>
                  <p className="text-sm text-gray-400">Start logging your fitness journey!</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;