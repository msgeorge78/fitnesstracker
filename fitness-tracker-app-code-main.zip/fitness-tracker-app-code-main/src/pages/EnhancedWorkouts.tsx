import React, { useState } from 'react';
import { useAppData } from '../contexts/AppDataContext';
import { Plus, Activity, Heart, Dumbbell, Zap, Clock, CheckCircle, AlertCircle, Loader2, Search, Trash2, Play, Pause } from 'lucide-react';
import ExerciseSearch from '../components/workouts/ExerciseSearch';
import VoiceInput from '../components/voice/VoiceInput';
import { WorkoutExercise, EnhancedWorkout } from '../types/enhanced';

const EnhancedWorkouts: React.FC = () => {
  const { workouts, addWorkout } = useAppData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showExerciseSearch, setShowExerciseSearch] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [restTimer, setRestTimer] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    name: '',
    exercises: [] as WorkoutExercise[],
    notes: ''
  });

  // Rest timer effect
  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && restTimer > 0) {
      interval = setInterval(() => {
        setRestTimer(prev => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            // Could add notification sound here
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, restTimer]);

  const handleAddExercise = (exercise: WorkoutExercise) => {
    setFormData(prev => ({
      ...prev,
      exercises: [...prev.exercises, exercise]
    }));
  };

  const handleRemoveExercise = (index: number) => {
    setFormData(prev => ({
      ...prev,
      exercises: prev.exercises.filter((_, i) => i !== index)
    }));
  };

  const startRestTimer = (seconds: number) => {
    setRestTimer(seconds);
    setIsTimerRunning(true);
  };

  const toggleTimer = () => {
    setIsTimerRunning(!isTimerRunning);
  };

  const resetTimer = () => {
    setIsTimerRunning(false);
    setRestTimer(0);
  };

  const handleVoiceInput = (text: string) => {
    // Simple voice parsing for workout logging
    const lowerText = text.toLowerCase();
    console.log('🎤 Voice input received:', text);
    
    // Extract duration with better parsing
    const durationMatch = text.match(/(\d+)\s*(minute|min|hour|hr)/i);
    if (durationMatch) {
      const duration = parseInt(durationMatch[1]);
      const unit = durationMatch[2].toLowerCase();
      const finalDuration = unit.includes('hour') || unit.includes('hr') ? duration * 60 : duration;
      
      console.log('⏱️ Extracted duration:', finalDuration, 'minutes');
      
      // Create a simple exercise from voice input
      const exerciseName = extractExerciseName(text, durationMatch[0]);
      const estimatedCalories = Math.round(finalDuration * 6); // Rough estimate
      
      const newExercise: WorkoutExercise = {
        exerciseId: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        name: exerciseName || 'Voice Exercise',
        duration: finalDuration,
        calories: estimatedCalories
      };
      
      console.log('🏃‍♂️ Adding exercise from voice:', newExercise);
      
      setFormData(prev => ({
        ...prev,
        exercises: [...prev.exercises, newExercise],
        name: prev.name || exerciseName || 'Voice Workout'
      }));
      
      console.log('✅ Exercise added to form data');
    }
  };

  const extractExerciseName = (text: string, durationText: string): string => {
    let exerciseName = text.replace(durationText, '').trim();
    
    // Remove common prefixes
    const prefixes = ['i did', 'i completed', 'i finished', 'did', 'completed', 'finished'];
    for (const prefix of prefixes) {
      if (exerciseName.toLowerCase().startsWith(prefix)) {
        exerciseName = exerciseName.substring(prefix.length).trim();
        break;
      }
    }
    
    // Clean up common words
    exerciseName = exerciseName.replace(/\b(of|a|an|the|for)\b/gi, '').trim();
    
    // Capitalize first letter
    if (exerciseName) {
      exerciseName = exerciseName.charAt(0).toUpperCase() + exerciseName.slice(1);
    }
    
    return exerciseName || 'Exercise';
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('📝 Submitting workout with exercises:', formData.exercises);
    
    if (formData.exercises.length === 0) {
      console.log('❌ No exercises in form data');
      setSubmitStatus('error');
      return;
    }
    
    setIsSubmitting(true);
    setSubmitStatus('idle');
    
    try {
      const totalDuration = formData.exercises.reduce((sum, exercise) => sum + exercise.duration, 0);
      const totalCalories = formData.exercises.reduce((sum, exercise) => sum + exercise.calories, 0);
      
      console.log('📊 Workout totals:', { totalDuration, totalCalories });
      
      // For now, we'll create a simple workout name if none provided
      const workoutName = formData.name || `${formData.exercises[0]?.name} Workout`;
      
      console.log('🏋️‍♂️ Adding workout:', workoutName);
      
      const success = await addWorkout({
        date: formData.date,
        name: workoutName,
        duration: totalDuration,
        type: formData.exercises[0]?.name.includes('Cardio') ? 'Cardio' : 'Strength',
        calories_burned: totalCalories,
        notes: formData.notes || undefined
      });

      if (success) {
        console.log('✅ Workout added successfully');
        setSubmitStatus('success');
        setFormData({
          date: new Date().toISOString().split('T')[0],
          name: '',
          exercises: [],
          notes: ''
        });
        
        setTimeout(() => {
          setIsModalOpen(false);
          setSubmitStatus('idle');
        }, 1500);
      } else {
        console.error('❌ Failed to add workout');
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Error submitting workout:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getWorkoutIcon = (type: string) => {
    switch (type) {
      case 'Cardio':
        return Heart;
      case 'Strength':
        return Dumbbell;
      case 'Flexibility':
        return Zap;
      case 'Sports':
        return Activity;
      default:
        return Activity;
    }
  };

  const getWorkoutColor = (type: string) => {
    switch (type) {
      case 'Cardio':
        return 'bg-red-100 text-red-800';
      case 'Strength':
        return 'bg-blue-100 text-blue-800';
      case 'Flexibility':
        return 'bg-green-100 text-green-800';
      case 'Sports':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const today = new Date().toISOString().split('T')[0];
  const todayWorkouts = workouts.filter(workout => workout.date === today);
  const todayCalories = todayWorkouts.reduce((sum, workout) => sum + workout.calories_burned, 0);
  const todayDuration = todayWorkouts.reduce((sum, workout) => sum + workout.duration, 0);

  const groupedWorkouts = workouts.reduce((acc, workout) => {
    const date = workout.date;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(workout);
    return acc;
  }, {} as Record<string, typeof workouts>);

  const sortedDates = Object.keys(groupedWorkouts).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const totalExerciseDuration = formData.exercises.reduce((sum, exercise) => sum + exercise.duration, 0);
  const totalExerciseCalories = formData.exercises.reduce((sum, exercise) => sum + exercise.calories, 0);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Enhanced Workout Tracking</h1>
          <p className="text-gray-600 mt-1">Track detailed workouts with exercise library and rest timer</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-green-700 transition-all duration-200 transform hover:scale-105"
        >
          <Plus className="h-5 w-5" />
          <span>Log Workout</span>
        </button>
      </div>

      {/* Rest Timer Widget */}
      {(restTimer > 0 || isTimerRunning) && (
        <div className="fixed bottom-4 right-4 bg-white rounded-2xl shadow-lg border border-gray-200 p-4 z-40">
          <div className="text-center">
            <p className="text-sm font-medium text-gray-700 mb-2">Rest Timer</p>
            <p className="text-2xl font-bold text-blue-600 mb-3">{formatTime(restTimer)}</p>
            <div className="flex space-x-2">
              <button
                onClick={toggleTimer}
                className="flex items-center justify-center w-10 h-10 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
              >
                {isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
              <button
                onClick={resetTimer}
                className="flex items-center justify-center w-10 h-10 bg-gray-600 text-white rounded-full hover:bg-gray-700 transition-colors"
              >
                ⏹
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Today's Summary */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">Today's Activity</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-blue-100 text-sm">Duration</p>
                <p className="text-2xl font-bold">{todayDuration} min</p>
              </div>
              <div>
                <p className="text-blue-100 text-sm">Calories Burned</p>
                <p className="text-2xl font-bold">{todayCalories} kcal</p>
              </div>
            </div>
            <p className="text-blue-100 mt-2">{todayWorkouts.length} workouts completed</p>
          </div>
          <Activity className="h-16 w-16 text-white opacity-20" />
        </div>
      </div>

      {/* Quick Rest Timer Buttons */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Rest Timer</h2>
        <div className="grid grid-cols-4 gap-3">
          {[30, 60, 90, 120].map((seconds) => (
            <button
              key={seconds}
              onClick={() => startRestTimer(seconds)}
              className="flex items-center justify-center space-x-2 bg-blue-100 text-blue-700 px-4 py-3 rounded-lg hover:bg-blue-200 transition-colors"
            >
              <Clock className="w-4 h-4" />
              <span>{seconds}s</span>
            </button>
          ))}
        </div>
      </div>

      {/* Today's Workouts */}
      {todayWorkouts.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Today's Workouts</h2>
          <div className="space-y-4">
            {todayWorkouts.map((workout) => {
              const Icon = getWorkoutIcon(workout.type);
              return (
                <div key={workout.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Icon className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{workout.name}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getWorkoutColor(workout.type)}`}>
                          {workout.type}
                        </span>
                        <span className="flex items-center space-x-1">
                          <Clock className="h-3 w-3" />
                          <span>{workout.duration} min</span>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{workout.calories_burned} kcal</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Workout History */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Workout History</h2>
        {workouts.length === 0 ? (
          <div className="text-center py-12">
            <Activity className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No workouts logged</h3>
            <p className="text-gray-600 mb-4">Start tracking your fitness activities to see your progress</p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Log First Workout
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {sortedDates.slice(0, 7).map((date) => {
              const dayWorkouts = groupedWorkouts[date];
              const dayCalories = dayWorkouts.reduce((sum, workout) => sum + workout.calories_burned, 0);
              const dayDuration = dayWorkouts.reduce((sum, workout) => sum + workout.duration, 0);
              
              return (
                <div key={date} className="border-l-4 border-blue-500 pl-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {formatDate(date)}
                    </h3>
                    <div className="text-sm font-medium text-gray-600 text-right">
                      <p>{dayDuration} min total</p>
                      <p>{dayCalories} kcal burned</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    {dayWorkouts.map((workout) => {
                      const Icon = getWorkoutIcon(workout.type);
                      return (
                        <div key={workout.id} className="p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-3">
                              <div className="p-2 bg-blue-100 rounded-lg">
                                <Icon className="h-4 w-4 text-blue-600" />
                              </div>
                              <div>
                                <p className="font-medium text-gray-900">{workout.name}</p>
                                <div className="flex items-center space-x-4 text-sm text-gray-600">
                                  <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getWorkoutColor(workout.type)}`}>
                                    {workout.type}
                                  </span>
                                  <span className="flex items-center space-x-1">
                                    <Clock className="h-3 w-3" />
                                    <span>{workout.duration} min</span>
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-gray-900">{workout.calories_burned} kcal</p>
                            </div>
                          </div>
                          {workout.notes && (
                            <p className="text-sm text-gray-600 mt-2 pl-10">{workout.notes}</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Enhanced Workout Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl p-6 w-full max-w-2xl my-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Log Enhanced Workout</h2>
            
            {submitStatus === 'success' && (
              <div className="mb-4 p-3 bg-green-100 border border-green-200 rounded-lg flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="text-green-800">Workout logged successfully!</span>
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="mb-4 p-3 bg-red-100 border border-red-200 rounded-lg flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <span className="text-red-800">
                  {formData.exercises.length === 0 
                    ? 'Please add exercises to your workout before logging.' 
                    : 'Failed to log workout. Please try again.'
                  }
                </span>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Workout Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., Upper Body Strength"
                  />
                </div>
              </div>

              {/* Voice Input */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Voice Input</label>
                <VoiceInput
                  onResult={handleVoiceInput}
                  placeholder="Say your workout, e.g., 'I did 30 minutes of cycling' or 'I completed 45 minutes of strength training'"
                  isActive={isVoiceActive}
                  onToggle={setIsVoiceActive}
                />
                <p className="text-xs text-gray-500 mt-2">
                  Try saying: "I did 30 minutes of cycling" or "I completed 45 minutes of strength training"
                </p>
              </div>

              {/* Exercises List */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <label className="block text-sm font-medium text-gray-700">Exercises</label>
                  <button
                    type="button"
                    onClick={() => setShowExerciseSearch(true)}
                    className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Search className="w-4 h-4" />
                    <span>Add Exercise</span>
                  </button>
                </div>

                {formData.exercises.length === 0 ? (
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No exercises added yet</p>
                    <p className="text-sm text-gray-400">Use voice input or click "Add Exercise" to add exercises</p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-48 overflow-y-auto">
                    {formData.exercises.map((exercise, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{exercise.name}</h4>
                            <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                              <span className="flex items-center space-x-1">
                                <Clock className="w-3 h-3" />
                                <span>{exercise.duration} min</span>
                              </span>
                              {exercise.sets && (
                                <span>{exercise.sets} sets × {exercise.reps} reps</span>
                              )}
                              {exercise.weight && (
                                <span>{exercise.weight} kg</span>
                              )}
                              <span>{exercise.calories} kcal</span>
                            </div>
                            {exercise.restTime && (
                              <button
                                type="button"
                                onClick={() => startRestTimer(exercise.restTime!)}
                                className="mt-2 text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded hover:bg-blue-200 transition-colors"
                              >
                                Start {exercise.restTime}s rest timer
                              </button>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveExercise(index)}
                            className="text-red-500 hover:text-red-700 transition-colors ml-4"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                    
                    {/* Totals */}
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-medium text-gray-900 mb-2">Workout Totals</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Duration:</span>
                          <p className="font-medium">{totalExerciseDuration} minutes</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Calories:</span>
                          <p className="font-medium">{totalExerciseCalories} kcal</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes (optional)</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  placeholder="Add notes about your workout..."
                />
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setSubmitStatus('idle');
                    setFormData({
                      date: new Date().toISOString().split('T')[0],
                      name: '',
                      exercises: [],
                      notes: ''
                    });
                  }}
                  className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || formData.exercises.length === 0}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Logging...
                    </>
                  ) : (
                    'Log Workout'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Exercise Search Modal */}
      {showExerciseSearch && (
        <ExerciseSearch
          onAddExercise={handleAddExercise}
          onClose={() => setShowExerciseSearch(false)}
        />
      )}
    </div>
  );
};

export default EnhancedWorkouts;