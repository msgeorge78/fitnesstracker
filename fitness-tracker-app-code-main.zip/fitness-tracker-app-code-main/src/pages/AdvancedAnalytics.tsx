import React from 'react';
import { useAppData } from '../contexts/AppDataContext';
import AdvancedAnalytics from '../components/analytics/AdvancedAnalytics';

const AdvancedAnalyticsPage: React.FC = () => {
  const { goals, workouts, meals, weightLogs } = useAppData();

  const analyticsData = {
    goals,
    workouts,
    meals,
    weightLogs
  };

  return <AdvancedAnalytics data={analyticsData} />;
};

export default AdvancedAnalyticsPage;