import React, { useState } from 'react';
import { useAppData } from '../contexts/AppDataContext';
import { useAuth } from '../contexts/AuthContext';
import { Plus, Utensils, Coffee, Sunset, Moon, Loader2, CheckCircle, AlertCircle } from 'lucide-react';

const Nutrition: React.FC = () => {
  const { meals, addMeal, getCaloriesFromAI } = useAppData();
  const { user, isSupabaseConnected } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoadingCalories, setIsLoadingCalories] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    meal_type: 'Breakfast' as const,
    food_name: '',
    calories: ''
  });

  // Simple local calorie estimation for common foods
  const getQuickCalorieEstimate = (foodName: string): number => {
    const normalizedFood = foodName.toLowerCase().trim();
    
    const quickEstimates: Record<string, number> = {
      // Fruits
      'apple': 80, 'banana': 105, 'orange': 60, 'grapes': 60,
      // Vegetables
      'broccoli': 25, 'carrot': 25, 'spinach': 7, 'tomato': 20,
      // Proteins
      'chicken breast': 165, 'salmon': 200, 'egg': 70, 'tuna': 150,
      // Grains
      'rice': 200, 'pasta': 220, 'bread': 80, 'oats': 150,
      // Common foods
      'pizza': 285, 'hamburger': 540, 'sandwich': 300,
      // Dairy
      'milk': 150, 'yogurt': 100, 'cheese': 110,
    };

    // Try exact match first
    if (quickEstimates[normalizedFood]) {
      return quickEstimates[normalizedFood];
    }

    // Try partial matches
    for (const [key, value] of Object.entries(quickEstimates)) {
      if (normalizedFood.includes(key) || key.includes(normalizedFood)) {
        return value;
      }
    }

    // Default estimate based on food type keywords
    if (normalizedFood.includes('salad')) return 150;
    if (normalizedFood.includes('soup')) return 120;
    if (normalizedFood.includes('smoothie')) return 200;
    if (normalizedFood.includes('cake') || normalizedFood.includes('dessert')) return 350;
    
    return 200; // Default reasonable estimate
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check authentication first
    if (!user) {
      setSubmitStatus('error');
      return;
    }
    
    if (!isSupabaseConnected) {
      setSubmitStatus('error');
      return;
    }
    
    setIsSubmitting(true);
    setSubmitStatus('idle');
    
    try {
      let finalCalories = parseInt(formData.calories);
      
      // If no calories entered, use quick estimate
      if (!finalCalories || finalCalories === 0) {
        finalCalories = getQuickCalorieEstimate(formData.food_name);
      }
      
      const success = await addMeal({
        date: formData.date,
        meal_type: formData.meal_type,
        food_name: formData.food_name,
        calories: finalCalories
      });

      if (success) {
        setSubmitStatus('success');
        // Reset form
        setFormData({
          date: new Date().toISOString().split('T')[0],
          meal_type: 'Breakfast',
          food_name: '',
          calories: ''
        });
        
        // Close modal after short delay
        setTimeout(() => {
          setIsModalOpen(false);
          setSubmitStatus('idle');
        }, 1500);
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Error submitting meal:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFoodNameChange = (foodName: string) => {
    setFormData({ ...formData, food_name: foodName });
    
    // Immediately provide quick estimate
    if (foodName.trim().length > 2) {
      const quickEstimate = getQuickCalorieEstimate(foodName);
      setFormData(prev => ({ ...prev, calories: quickEstimate.toString() }));
    }
  };

  const handleGetAICalories = async () => {
    if (!formData.food_name.trim()) return;
    
    setIsLoadingCalories(true);
    try {
      const aiCalories = await getCaloriesFromAI(formData.food_name);
      if (aiCalories > 0) {
        setFormData(prev => ({ ...prev, calories: aiCalories.toString() }));
      }
    } catch (error) {
      console.error('Error getting AI calories:', error);
    } finally {
      setIsLoadingCalories(false);
    }
  };

  const getMealIcon = (mealType: string) => {
    switch (mealType) {
      case 'Breakfast':
        return Coffee;
      case 'Lunch':
        return Utensils;
      case 'Dinner':
        return Sunset;
      case 'Snack':
        return Moon;
      default:
        return Utensils;
    }
  };

  const getMealColor = (mealType: string) => {
    switch (mealType) {
      case 'Breakfast':
        return 'bg-yellow-100 text-yellow-800';
      case 'Lunch':
        return 'bg-blue-100 text-blue-800';
      case 'Dinner':
        return 'bg-orange-100 text-orange-800';
      case 'Snack':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const today = new Date().toISOString().split('T')[0];
  const todayMeals = meals.filter(meal => meal.date === today);
  const todayCalories = todayMeals.reduce((sum, meal) => sum + meal.calories, 0);

  const groupedMeals = meals.reduce((acc, meal) => {
    const date = meal.date;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(meal);
    return acc;
  }, {} as Record<string, typeof meals>);

  const sortedDates = Object.keys(groupedMeals).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Nutrition Tracking</h1>
          <p className="text-gray-600 mt-1">Log your meals and track your daily calories</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          disabled={!user || !isSupabaseConnected}
          className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-green-700 transition-all duration-200 transform hover:scale-105"
        >
          <Plus className="h-5 w-5" />
          <span>Log Meal</span>
        </button>
      </div>

      {/* Today's Summary */}
      <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">Today's Calories</h2>
            <p className="text-3xl font-bold">{todayCalories} kcal</p>
            <p className="text-green-100 mt-1">{todayMeals.length} meals logged</p>
          </div>
          <Utensils className="h-16 w-16 text-white opacity-20" />
        </div>
      </div>

      {/* Today's Meals */}
      {todayMeals.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Today's Meals</h2>
          <div className="space-y-4">
            {todayMeals.map((meal) => {
              const Icon = getMealIcon(meal.meal_type);
              return (
                <div key={meal.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-green-100 rounded-lg">
                      <Icon className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{meal.food_name}</p>
                      <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getMealColor(meal.meal_type)}`}>
                        {meal.meal_type}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{meal.calories} kcal</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Meal History */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Meal History</h2>
        {meals.length === 0 ? (
          <div className="text-center py-12">
            <Utensils className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No meals logged</h3>
            <p className="text-gray-600 mb-4">Start tracking your nutrition to see your progress</p>
            <button
              onClick={() => setIsModalOpen(true)}
              disabled={!user || !isSupabaseConnected}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Log First Meal
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {sortedDates.map((date) => {
              const dayMeals = groupedMeals[date];
              const dayCalories = dayMeals.reduce((sum, meal) => sum + meal.calories, 0);
              
              return (
                <div key={date} className="border-l-4 border-green-500 pl-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {formatDate(date)}
                    </h3>
                    <span className="text-sm font-medium text-gray-600">
                      {dayCalories} kcal total
                    </span>
                  </div>
                  <div className="space-y-3">
                    {dayMeals.map((meal) => {
                      const Icon = getMealIcon(meal.meal_type);
                      return (
                        <div key={meal.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-green-100 rounded-lg">
                              <Icon className="h-4 w-4 text-green-600" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{meal.food_name}</p>
                              <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getMealColor(meal.meal_type)}`}>
                                {meal.meal_type}
                              </span>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-gray-900">{meal.calories} kcal</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Log Meal</h2>
            
            {submitStatus === 'success' && (
              <div className="mb-4 p-3 bg-green-100 border border-green-200 rounded-lg flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="text-green-800">Meal logged successfully!</span>
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="mb-4 p-3 bg-red-100 border border-red-200 rounded-lg flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <span className="text-red-800">Failed to log meal. Please try again.</span>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Meal Type</label>
                <select
                  value={formData.meal_type}
                  onChange={(e) => setFormData({ ...formData, meal_type: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Breakfast">Breakfast</option>
                  <option value="Lunch">Lunch</option>
                  <option value="Dinner">Dinner</option>
                  <option value="Snack">Snack</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Food Name</label>
                <input
                  type="text"
                  value={formData.food_name}
                  onChange={(e) => handleFoodNameChange(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Grilled chicken with vegetables"
                  required
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-sm font-medium text-gray-700">
                    Calories (auto-estimated)
                  </label>
                  <button
                    type="button"
                    onClick={handleGetAICalories}
                    disabled={isLoadingCalories || !formData.food_name.trim()}
                    className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded hover:bg-blue-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoadingCalories ? (
                      <span className="flex items-center">
                        <Loader2 className="h-3 w-3 animate-spin mr-1" />
                        AI Refining...
                      </span>
                    ) : (
                      'Refine with AI'
                    )}
                  </button>
                </div>
                <input
                  type="number"
                  value={formData.calories}
                  onChange={(e) => setFormData({ ...formData, calories: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Auto-calculated"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  Calories are estimated automatically. You can edit or use AI for more accuracy.
                </p>
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setSubmitStatus('idle');
                    setFormData({
                      date: new Date().toISOString().split('T')[0],
                      meal_type: 'Breakfast',
                      food_name: '',
                      calories: ''
                    });
                  }}
                  className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || !user || !isSupabaseConnected}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Logging...
                    </>
                  ) : (
                    'Log Meal'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Nutrition;