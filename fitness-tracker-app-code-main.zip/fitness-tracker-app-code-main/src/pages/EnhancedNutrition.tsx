import React, { useState } from 'react';
import { useAppData } from '../contexts/AppDataContext';
import { useAuth } from '../contexts/AuthContext';
import { Plus, Utensils, Coffee, Sunset, Moon, Loader2, CheckCircle, AlertCircle, Search, Trash2 } from 'lucide-react';
import MacroChart from '../components/charts/MacroChart';
import FoodSearch from '../components/nutrition/FoodSearch';
import VoiceInput from '../components/voice/VoiceInput';
import DeleteButton from '../components/common/DeleteButton';
import { MealFood, EnhancedMeal } from '../types/enhanced';

const EnhancedNutrition: React.FC = () => {
  const { meals, addMeal, deleteMeal } = useAppData();
  const { user, isSupabaseConnected } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showFoodSearch, setShowFoodSearch] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    meal_type: 'Breakfast' as const,
    foods: [] as MealFood[]
  });

  const handleAddFood = (food: MealFood) => {
    setFormData(prev => ({
      ...prev,
      foods: [...prev.foods, food]
    }));
  };

  const handleRemoveFood = (index: number) => {
    setFormData(prev => ({
      ...prev,
      foods: prev.foods.filter((_, i) => i !== index)
    }));
  };

  const handleVoiceInput = (text: string) => {
    // Simple voice parsing for meal logging
    const lowerText = text.toLowerCase();
    console.log('🎤 Voice input received:', text);
    
    // Extract meal type
    if (lowerText.includes('breakfast')) {
      setFormData(prev => ({ ...prev, meal_type: 'Breakfast' }));
    } else if (lowerText.includes('lunch')) {
      setFormData(prev => ({ ...prev, meal_type: 'Lunch' }));
    } else if (lowerText.includes('dinner')) {
      setFormData(prev => ({ ...prev, meal_type: 'Dinner' }));
    } else if (lowerText.includes('snack')) {
      setFormData(prev => ({ ...prev, meal_type: 'Snack' }));
    }
    
    // Extract food items with better parsing
    const foodKeywords = ['ate', 'had', 'consumed', 'eating', 'for'];
    let foodText = text.trim();
    
    // Remove meal type words from food text
    foodText = foodText.replace(/\b(breakfast|lunch|dinner|snack)\b/gi, '').trim();
    
    // Try to extract food after keywords
    for (const keyword of foodKeywords) {
      const index = lowerText.indexOf(keyword);
      if (index !== -1) {
        const afterKeyword = text.substring(index + keyword.length).trim();
        if (afterKeyword.length > 0) {
          foodText = afterKeyword;
        }
        break;
      }
    }
    
    // Clean up common words that aren't food
    foodText = foodText.replace(/\b(a|an|the|some|for|in|at|on)\b/gi, '').trim();
    
    console.log('🍽️ Extracted food text:', foodText);
    
    // Split multiple foods by common separators
    const foodItems = foodText.split(/\s+and\s+|\s*,\s*|\s+with\s+/i).filter(item => item.trim().length > 0);
    
    console.log('📝 Food items to add:', foodItems);
    
    // Add each food item
    foodItems.forEach(foodItem => {
      const cleanFoodItem = foodItem.trim();
      if (cleanFoodItem.length > 2) { // Only add if meaningful length
        const estimatedCalories = getQuickCalorieEstimate(cleanFoodItem);
        console.log(`🥘 Adding food: ${cleanFoodItem} (${estimatedCalories} kcal)`);
        
        const newFood: MealFood = {
          foodId: Date.now().toString() + Math.random().toString(36).substr(2, 9),
          name: cleanFoodItem,
          calories: estimatedCalories,
          protein: Math.round(estimatedCalories * 0.15 / 4 * 10) / 10, // Rough estimate
          carbs: Math.round(estimatedCalories * 0.55 / 4 * 10) / 10,
          fats: Math.round(estimatedCalories * 0.30 / 9 * 10) / 10,
          quantity: 1,
          servingSize: '1 serving'
        };
        
        setFormData(prev => ({
          ...prev,
          foods: [...prev.foods, newFood]
        }));
        
        console.log('✅ Food added to form data');
      }
    });
  };

  const getQuickCalorieEstimate = (foodName: string): number => {
    // Enhanced calorie estimation with more foods
    const normalizedFood = foodName.toLowerCase().trim();
    
    const quickEstimates: Record<string, number> = {
      // Proteins
      'chicken': 165, 'beef': 250, 'pork': 242, 'fish': 150, 'salmon': 200,
      'tuna': 144, 'egg': 70, 'eggs': 140, 'tofu': 76,
      
      // Grains & Carbs
      'rice': 130, 'pasta': 131, 'bread': 80, 'noodles': 138,
      'potato': 77, 'sweet potato': 86, 'quinoa': 120,
      
      // Fruits
      'apple': 52, 'banana': 89, 'orange': 47, 'grapes': 62,
      'strawberry': 32, 'blueberry': 57, 'mango': 60,
      
      // Vegetables
      'broccoli': 34, 'carrot': 41, 'spinach': 23, 'tomato': 18,
      'lettuce': 15, 'cucumber': 16, 'onion': 40,
      
      // Dairy
      'milk': 42, 'cheese': 113, 'yogurt': 59, 'butter': 717,
      
      // Common dishes
      'salad': 150, 'soup': 120, 'sandwich': 300, 'pizza': 266,
      'burger': 295, 'pasta': 220, 'stir fry': 200,
      
      // Snacks
      'nuts': 600, 'chips': 536, 'crackers': 502, 'cookie': 50,
      'chocolate': 546
    };

    // Try exact match first
    if (quickEstimates[normalizedFood]) {
      return quickEstimates[normalizedFood];
    }

    // Try partial matches
    for (const [key, value] of Object.entries(quickEstimates)) {
      if (normalizedFood.includes(key) || key.includes(normalizedFood)) {
        return value;
      }
    }
    
    // Default estimate based on food type keywords
    if (normalizedFood.includes('salad')) return 150;
    if (normalizedFood.includes('soup')) return 120;
    if (normalizedFood.includes('smoothie')) return 200;
    if (normalizedFood.includes('cake') || normalizedFood.includes('dessert')) return 350;
    if (normalizedFood.includes('meat') || normalizedFood.includes('protein')) return 200;
    if (normalizedFood.includes('vegetable') || normalizedFood.includes('veggie')) return 30;
    if (normalizedFood.includes('fruit')) return 60;
    
    return 150; // Default reasonable estimate
  };

  const getQuickCalorieEstimateOld = (foodName: string): number => {
    const normalizedFood = foodName.toLowerCase().trim();
    
    const quickEstimates: Record<string, number> = {
    };
    return 150; // Default estimate
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.foods.length === 0) {
      console.log('❌ No foods in form data:', formData.foods);
      setSubmitStatus('error');
      return;
    }
    
    if (!user || !isSupabaseConnected) {
      console.log('❌ User or Supabase not available:', { user: !!user, isSupabaseConnected });
      setSubmitStatus('error');
      return;
    }
    
    setIsSubmitting(true);
    setSubmitStatus('idle');
    
    try {
      console.log('📝 Submitting foods:', formData.foods);
      
      // For now, we'll add each food as a separate meal entry
      // In a real app, you'd want to modify the backend to support multiple foods per meal
      let allSuccess = true;
      
      for (const food of formData.foods) {
        console.log('🍽️ Adding meal:', food);
        
        const success = await addMeal({
          date: formData.date,
          meal_type: formData.meal_type,
          food_name: `${food.name} (${food.quantity}x ${food.servingSize})`,
          calories: food.calories
        });
        
        if (!success) {
          console.error('❌ Failed to add meal:', food.name);
          allSuccess = false;
          break;
        }
      }

      if (allSuccess) {
        console.log('✅ All meals added successfully');
        setSubmitStatus('success');
        // Reset form
        setFormData({
          date: new Date().toISOString().split('T')[0],
          meal_type: 'Breakfast',
          foods: []
        });
        
        // Close modal after short delay
        setTimeout(() => {
          setIsModalOpen(false);
          setSubmitStatus('idle');
        }, 1500);
      } else {
        console.error('❌ Some meals failed to add');
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Error submitting meal:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getMealIcon = (mealType: string) => {
    switch (mealType) {
      case 'Breakfast':
        return Coffee;
      case 'Lunch':
        return Utensils;
      case 'Dinner':
        return Sunset;
      case 'Snack':
        return Moon;
      default:
        return Utensils;
    }
  };

  const getMealColor = (mealType: string) => {
    switch (mealType) {
      case 'Breakfast':
        return 'bg-yellow-100 text-yellow-800';
      case 'Lunch':
        return 'bg-blue-100 text-blue-800';
      case 'Dinner':
        return 'bg-orange-100 text-orange-800';
      case 'Snack':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const today = new Date().toISOString().split('T')[0];
  const todayMeals = meals.filter(meal => meal.date === today);
  const todayCalories = todayMeals.reduce((sum, meal) => sum + meal.calories, 0);

  // Calculate today's macros (mock data for demo)
  const todayMacros = {
    protein: Math.round(todayCalories * 0.25 / 4), // 25% of calories from protein
    carbs: Math.round(todayCalories * 0.50 / 4),   // 50% of calories from carbs
    fats: Math.round(todayCalories * 0.25 / 9)     // 25% of calories from fats
  };

  const nutritionTargets = {
    calories: 2000,
    protein: 125,
    carbs: 250,
    fats: 55
  };

  const groupedMeals = meals.reduce((acc, meal) => {
    const date = meal.date;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(meal);
    return acc;
  }, {} as Record<string, typeof meals>);

  const sortedDates = Object.keys(groupedMeals).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const totalFoodCalories = formData.foods.reduce((sum, food) => sum + food.calories, 0);
  const totalFoodProtein = formData.foods.reduce((sum, food) => sum + food.protein, 0);
  const totalFoodCarbs = formData.foods.reduce((sum, food) => sum + food.carbs, 0);
  const totalFoodFats = formData.foods.reduce((sum, food) => sum + food.fats, 0);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Enhanced Nutrition Tracking</h1>
          <p className="text-gray-600 mt-1">Track your meals with detailed macro breakdown</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          disabled={!user || !isSupabaseConnected}
          className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-green-700 transition-all duration-200 transform hover:scale-105"
        >
          <Plus className="h-5 w-5" />
          <span>Log Meal</span>
        </button>
      </div>

      {/* Today's Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-2">Today's Nutrition</h2>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Calories:</span>
                  <span className="font-bold">{todayCalories} / {nutritionTargets.calories}</span>
                </div>
                <div className="flex justify-between">
                  <span>Protein:</span>
                  <span className="font-bold">{todayMacros.protein}g / {nutritionTargets.protein}g</span>
                </div>
                <div className="flex justify-between">
                  <span>Carbs:</span>
                  <span className="font-bold">{todayMacros.carbs}g / {nutritionTargets.carbs}g</span>
                </div>
                <div className="flex justify-between">
                  <span>Fats:</span>
                  <span className="font-bold">{todayMacros.fats}g / {nutritionTargets.fats}g</span>
                </div>
              </div>
              <p className="text-green-100 mt-2">{todayMeals.length} meals logged</p>
            </div>
            <Utensils className="h-16 w-16 text-white opacity-20" />
          </div>
        </div>

        <MacroChart
          protein={todayMacros.protein}
          carbs={todayMacros.carbs}
          fats={todayMacros.fats}
          title="Today's Macro Breakdown"
        />
      </div>

      {/* Progress Bars */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Daily Progress</h2>
        <div className="space-y-4">
          {[
            { label: 'Calories', current: todayCalories, target: nutritionTargets.calories, unit: 'kcal', color: 'bg-blue-500' },
            { label: 'Protein', current: todayMacros.protein, target: nutritionTargets.protein, unit: 'g', color: 'bg-red-500' },
            { label: 'Carbs', current: todayMacros.carbs, target: nutritionTargets.carbs, unit: 'g', color: 'bg-green-500' },
            { label: 'Fats', current: todayMacros.fats, target: nutritionTargets.fats, unit: 'g', color: 'bg-yellow-500' }
          ].map((item) => {
            const percentage = Math.min((item.current / item.target) * 100, 100);
            return (
              <div key={item.label}>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700">{item.label}</span>
                  <span className="text-sm text-gray-600">
                    {item.current} / {item.target} {item.unit} ({Math.round(percentage)}%)
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`${item.color} h-2 rounded-full transition-all duration-300`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Today's Meals */}
      {todayMeals.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Today's Meals</h2>
          <div className="space-y-4">
            {todayMeals.map((meal) => {
              const Icon = getMealIcon(meal.meal_type);
              return (
                <div key={meal.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-green-100 rounded-lg">
                      <Icon className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{meal.food_name}</p>
                      <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getMealColor(meal.meal_type)}`}>
                        {meal.meal_type}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{meal.calories} kcal</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Meal History */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Meal History</h2>
        {meals.length === 0 ? (
          <div className="text-center py-12">
            <Utensils className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No meals logged</h3>
            <p className="text-gray-600 mb-4">Start tracking your nutrition to see your progress</p>
            <button
              onClick={() => setIsModalOpen(true)}
              disabled={!user || !isSupabaseConnected}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Log First Meal
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {sortedDates.slice(0, 7).map((date) => {
              const dayMeals = groupedMeals[date];
              const dayCalories = dayMeals.reduce((sum, meal) => sum + meal.calories, 0);
              
              return (
                <div key={date} className="border-l-4 border-green-500 pl-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {formatDate(date)}
                    </h3>
                    <span className="text-sm font-medium text-gray-600">
                      {dayCalories} kcal total
                    </span>
                  </div>
                  <div className="space-y-3">
                    {dayMeals.map((meal) => {
                      const Icon = getMealIcon(meal.meal_type);
                      return (
                        <div key={meal.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-green-100 rounded-lg">
                              <Icon className="h-4 w-4 text-green-600" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{meal.food_name}</p>
                              <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getMealColor(meal.meal_type)}`}>
                                {meal.meal_type}
                              </span>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-gray-900">{meal.calories} kcal</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Enhanced Meal Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Log Enhanced Meal</h2>
            
            {submitStatus === 'success' && (
              <div className="mb-4 p-3 bg-green-100 border border-green-200 rounded-lg flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="text-green-800">Meal logged successfully!</span>
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="mb-4 p-3 bg-red-100 border border-red-200 rounded-lg flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <span className="text-red-800">
                  {formData.foods.length === 0 
                    ? 'Please add foods to your meal before logging.' 
                    : 'Failed to log meal. Please try again.'
                  }
                </span>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Meal Type</label>
                  <select
                    value={formData.meal_type}
                    onChange={(e) => setFormData({ ...formData, meal_type: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Breakfast">Breakfast</option>
                    <option value="Lunch">Lunch</option>
                    <option value="Dinner">Dinner</option>
                    <option value="Snack">Snack</option>
                  </select>
                </div>
              </div>

              {/* Voice Input */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Voice Input</label>
                <VoiceInput
                  onResult={handleVoiceInput}
                  placeholder="Say what you ate, e.g., 'I had a banana and yogurt for breakfast'"
                  isActive={isVoiceActive}
                  onToggle={setIsVoiceActive}
                />
                <p className="text-xs text-gray-500 mt-2">
                  Try saying: "I ate chicken and rice for lunch" or "I had an apple as a snack"
                </p>
              </div>

              {/* Foods List */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <label className="block text-sm font-medium text-gray-700">Foods</label>
                  <button
                    type="button"
                    onClick={() => setShowFoodSearch(true)}
                    className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Search className="w-4 h-4" />
                    <span>Add Food</span>
                  </button>
                </div>

                {formData.foods.length === 0 ? (
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Utensils className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No foods added yet</p>
                    <p className="text-sm text-gray-400">Click "Add Food" to search and add foods</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {formData.foods.map((food, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{food.name}</p>
                          <p className="text-sm text-gray-600">
                            {food.quantity}x {food.servingSize}
                          </p>
                          <div className="flex space-x-4 text-xs text-gray-500 mt-1">
                            <span>P: {food.protein}g</span>
                            <span>C: {food.carbs}g</span>
                            <span>F: {food.fats}g</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <span className="font-medium text-gray-900">{food.calories} kcal</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveFood(index)}
                            className="text-red-500 hover:text-red-700 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                    
                    {/* Totals */}
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-medium text-gray-900 mb-2">Meal Totals</h4>
                      <div className="grid grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Calories:</span>
                          <p className="font-medium">{totalFoodCalories} kcal</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Protein:</span>
                          <p className="font-medium">{totalFoodProtein.toFixed(1)}g</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Carbs:</span>
                          <p className="font-medium">{totalFoodCarbs.toFixed(1)}g</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Fats:</span>
                          <p className="font-medium">{totalFoodFats.toFixed(1)}g</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setSubmitStatus('idle');
                    setFormData({
                      date: new Date().toISOString().split('T')[0],
                      meal_type: 'Breakfast',
                      foods: []
                    });
                  }}
                  className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || !user || !isSupabaseConnected || formData.foods.length === 0}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Logging...
                    </>
                  ) : (
                    'Log Meal'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Food Search Modal */}
      {showFoodSearch && (
        <FoodSearch
          onAddFood={handleAddFood}
          onClose={() => setShowFoodSearch(false)}
        />
      )}
    </div>
  );
};

export default EnhancedNutrition;