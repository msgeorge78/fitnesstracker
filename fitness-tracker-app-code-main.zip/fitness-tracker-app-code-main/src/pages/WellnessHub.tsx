import React, { useState } from 'react';
import { Heart, Brain, Droplets, Moon, Target, TrendingUp } from 'lucide-react';
import MeditationTimer from '../components/wellness/MeditationTimer';
import WaterTracker from '../components/hydration/WaterTracker';
import SleepTracker from '../components/sleep/SleepTracker';

const WellnessHub: React.FC = () => {
  const [activeTab, setActiveTab] = useState('meditation');
  const [wellnessData, setWellnessData] = useState({
    meditations: [],
    waterIntake: [],
    sleepEntries: [],
    moodEntries: []
  });

  const handleMeditationComplete = (duration: number, type: string) => {
    const newSession = {
      id: Date.now().toString(),
      duration,
      type,
      date: new Date().toISOString().split('T')[0],
      timestamp: new Date().toISOString()
    };
    
    setWellnessData(prev => ({
      ...prev,
      meditations: [...prev.meditations, newSession]
    }));

    // Show completion notification
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('Meditation Complete! 🧘‍♀️', {
        body: `Great job! You completed a ${duration}-minute ${type} session.`,
        icon: '/meditation-icon.png'
      });
    }
  };

  const handleWaterLog = (amount: number) => {
    const newEntry = {
      id: Date.now().toString(),
      amount,
      timestamp: new Date().toISOString()
    };
    
    setWellnessData(prev => ({
      ...prev,
      waterIntake: [...prev.waterIntake, newEntry]
    }));
  };

  const handleSleepLog = (entry: any) => {
    setWellnessData(prev => ({
      ...prev,
      sleepEntries: [...prev.sleepEntries, { ...entry, id: Date.now().toString() }]
    }));
  };

  const tabs = [
    { id: 'meditation', name: 'Meditation', icon: Brain, color: 'purple' },
    { id: 'hydration', name: 'Hydration', icon: Droplets, color: 'blue' },
    { id: 'sleep', name: 'Sleep', icon: Moon, color: 'indigo' },
    { id: 'mood', name: 'Mood', icon: Heart, color: 'pink' }
  ];

  const getTabColor = (color: string, isActive: boolean) => {
    const colors = {
      purple: isActive ? 'bg-purple-600 text-white' : 'text-purple-600 hover:bg-purple-50',
      blue: isActive ? 'bg-blue-600 text-white' : 'text-blue-600 hover:bg-blue-50',
      indigo: isActive ? 'bg-indigo-600 text-white' : 'text-indigo-600 hover:bg-indigo-50',
      pink: isActive ? 'bg-pink-600 text-white' : 'text-pink-600 hover:bg-pink-50'
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Wellness Hub</h1>
          <p className="text-gray-600 mt-1">Nurture your mind, body, and spirit</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <p className="text-sm text-gray-600">Today's Wellness Score</p>
            <p className="text-2xl font-bold text-green-600">85%</p>
          </div>
          <div className="p-3 bg-green-100 rounded-xl">
            <TrendingUp className="h-6 w-6 text-green-600" />
          </div>
        </div>
      </div>

      {/* Wellness Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-purple-100 rounded-xl">
              <Brain className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Meditation</p>
              <p className="text-2xl font-bold text-gray-900">{wellnessData.meditations.length}</p>
              <p className="text-xs text-gray-500">sessions</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-blue-100 rounded-xl">
              <Droplets className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Water Today</p>
              <p className="text-2xl font-bold text-gray-900">
                {wellnessData.waterIntake.reduce((sum, entry) => sum + entry.amount, 0)}ml
              </p>
              <p className="text-xs text-gray-500">of 2000ml</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-indigo-100 rounded-xl">
              <Moon className="h-6 w-6 text-indigo-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Sleep Quality</p>
              <p className="text-2xl font-bold text-gray-900">
                {wellnessData.sleepEntries.length > 0 
                  ? `${wellnessData.sleepEntries[wellnessData.sleepEntries.length - 1]?.quality || 0}/5`
                  : 'N/A'
                }
              </p>
              <p className="text-xs text-gray-500">last night</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-pink-100 rounded-xl">
              <Heart className="h-6 w-6 text-pink-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Mood</p>
              <p className="text-2xl font-bold text-gray-900">😊</p>
              <p className="text-xs text-gray-500">feeling good</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-2">
        <div className="flex space-x-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-xl font-medium transition-all duration-200 ${getTabColor(tab.color, isActive)}`}
              >
                <Icon className="w-5 h-5" />
                <span>{tab.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div className="min-h-96">
        {activeTab === 'meditation' && (
          <MeditationTimer onSessionComplete={handleMeditationComplete} />
        )}
        
        {activeTab === 'hydration' && (
          <WaterTracker onLogWater={handleWaterLog} />
        )}
        
        {activeTab === 'sleep' && (
          <SleepTracker onLogSleep={handleSleepLog} />
        )}
        
        {activeTab === 'mood' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Mood Tracking</h2>
              <p className="text-gray-600 mb-8">Track your daily mood and emotional well-being</p>
              
              <div className="grid grid-cols-5 gap-4 mb-8">
                {[
                  { emoji: '😢', label: 'Very Sad', value: 1 },
                  { emoji: '😕', label: 'Sad', value: 2 },
                  { emoji: '😐', label: 'Neutral', value: 3 },
                  { emoji: '😊', label: 'Happy', value: 4 },
                  { emoji: '😄', label: 'Very Happy', value: 5 }
                ].map((mood) => (
                  <button
                    key={mood.value}
                    className="flex flex-col items-center p-4 rounded-xl border-2 border-gray-200 hover:border-pink-300 hover:bg-pink-50 transition-all duration-200"
                  >
                    <span className="text-4xl mb-2">{mood.emoji}</span>
                    <span className="text-sm font-medium text-gray-700">{mood.label}</span>
                  </button>
                ))}
              </div>
              
              <div className="max-w-md mx-auto">
                <textarea
                  placeholder="How are you feeling today? What's on your mind?"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500"
                  rows={4}
                />
                <button className="w-full mt-4 bg-pink-600 text-white py-3 px-6 rounded-xl font-semibold hover:bg-pink-700 transition-colors">
                  Save Mood Entry
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WellnessHub;