import React, { useState } from 'react';
import { useAppData } from '../contexts/AppDataContext';
import { Plus, Activity, Heart, Dumbbell, Zap, Clock, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';

const Workouts: React.FC = () => {
  const { workouts, addWorkout } = useAppData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    name: '',
    duration: '',
    type: 'Cardio' as const,
    notes: ''
  });

  const getTodayString = (): string => {
    return new Date().toISOString().split('T')[0];
  };

  const formatDate = (date: string): string => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');
    
    try {
      const duration = parseInt(formData.duration);
      const calories_burned = calculateCalories(formData.type, duration);
      
      const success = await addWorkout({
        date: formData.date,
        name: formData.name,
        duration,
        type: formData.type,
        calories_burned,
        notes: formData.notes || undefined
      });

      if (success) {
        setSubmitStatus('success');
        setFormData({
          date: getTodayString(),
          name: '',
          duration: '',
          type: 'Cardio',
          notes: ''
        });
        
        // Close modal after short delay
        setTimeout(() => {
          setIsModalOpen(false);
          setSubmitStatus('idle');
        }, 1500);
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Error submitting workout:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    setIsModalOpen(false);
    setSubmitStatus('idle');
    setFormData({
      date: getTodayString(),
      name: '',
      duration: '',
      type: 'Cardio',
      notes: ''
    });
  };

  const calculateCalories = (type: string, duration: number): number => {
    const rates = {
      Cardio: 8,
      Strength: 6,
      Flexibility: 3,
      Sports: 7,
      Other: 5
    };
    return Math.round(duration * (rates[type as keyof typeof rates] || 5));
  };

  const getWorkoutIcon = (type: string) => {
    switch (type) {
      case 'Cardio':
        return Heart;
      case 'Strength':
        return Dumbbell;
      case 'Flexibility':
        return Zap;
      case 'Sports':
        return Activity;
      default:
        return Activity;
    }
  };

  const getWorkoutColor = (type: string) => {
    switch (type) {
      case 'Cardio':
        return 'bg-red-100 text-red-800';
      case 'Strength':
        return 'bg-blue-100 text-blue-800';
      case 'Flexibility':
        return 'bg-green-100 text-green-800';
      case 'Sports':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const today = getTodayString();
  const todayWorkouts = workouts.filter(workout => workout.date === today);
  const todayCalories = todayWorkouts.reduce((sum, workout) => sum + workout.calories_burned, 0);
  const todayDuration = todayWorkouts.reduce((sum, workout) => sum + workout.duration, 0);

  const groupedWorkouts = workouts.reduce((acc, workout) => {
    const date = workout.date;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(workout);
    return acc;
  }, {} as Record<string, typeof workouts>);

  const sortedDates = Object.keys(groupedWorkouts).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Workout Tracking</h1>
          <p className="text-gray-600 mt-1">Log your workouts and track your fitness progress</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-green-700 transition-all duration-200 transform hover:scale-105"
        >
          <Plus className="h-5 w-5" />
          <span>Log Workout</span>
        </button>
      </div>

      {/* Today's Summary */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">Today's Activity</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-blue-100 text-sm">Duration</p>
                <p className="text-2xl font-bold">{todayDuration} min</p>
              </div>
              <div>
                <p className="text-blue-100 text-sm">Calories Burned</p>
                <p className="text-2xl font-bold">{todayCalories} kcal</p>
              </div>
            </div>
            <p className="text-blue-100 mt-2">{todayWorkouts.length} workouts completed</p>
          </div>
          <Activity className="h-16 w-16 text-white opacity-20" />
        </div>
      </div>

      {/* Today's Workouts */}
      {todayWorkouts.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Today's Workouts</h2>
          <div className="space-y-4">
            {todayWorkouts.map((workout) => {
              const Icon = getWorkoutIcon(workout.type);
              return (
                <div key={workout.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Icon className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{workout.name}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getWorkoutColor(workout.type)}`}>
                          {workout.type}
                        </span>
                        <span className="flex items-center space-x-1">
                          <Clock className="h-3 w-3" />
                          <span>{workout.duration} min</span>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{workout.calories_burned} kcal</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Workout History */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Workout History</h2>
        {workouts.length === 0 ? (
          <div className="text-center py-12">
            <Activity className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No workouts logged</h3>
            <p className="text-gray-600 mb-4">Start tracking your fitness activities to see your progress</p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Log First Workout
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {sortedDates.map((date) => {
              const dayWorkouts = groupedWorkouts[date];
              const dayCalories = dayWorkouts.reduce((sum, workout) => sum + workout.calories_burned, 0);
              const dayDuration = dayWorkouts.reduce((sum, workout) => sum + workout.duration, 0);
              
              return (
                <div key={date} className="border-l-4 border-blue-500 pl-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {formatDate(date)}
                    </h3>
                    <div className="text-sm font-medium text-gray-600 text-right">
                      <p>{dayDuration} min total</p>
                      <p>{dayCalories} kcal burned</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    {dayWorkouts.map((workout) => {
                      const Icon = getWorkoutIcon(workout.type);
                      return (
                        <div key={workout.id} className="p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-3">
                              <div className="p-2 bg-blue-100 rounded-lg">
                                <Icon className="h-4 w-4 text-blue-600" />
                              </div>
                              <div>
                                <p className="font-medium text-gray-900">{workout.name}</p>
                                <div className="flex items-center space-x-4 text-sm text-gray-600">
                                  <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getWorkoutColor(workout.type)}`}>
                                    {workout.type}
                                  </span>
                                  <span className="flex items-center space-x-1">
                                    <Clock className="h-3 w-3" />
                                    <span>{workout.duration} min</span>
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-gray-900">{workout.calories_burned} kcal</p>
                            </div>
                          </div>
                          {workout.notes && (
                            <p className="text-sm text-gray-600 mt-2 pl-10">{workout.notes}</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Log Workout</h2>
            
            {submitStatus === 'success' && (
              <div className="mb-4 p-3 bg-green-100 border border-green-200 rounded-lg flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="text-green-800">Workout logged successfully!</span>
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="mb-4 p-3 bg-red-100 border border-red-200 rounded-lg flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <span className="text-red-800">Failed to log workout. Please try again.</span>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Workout Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Morning Run, Chest and Triceps"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Workout Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Cardio">Cardio</option>
                  <option value="Strength">Strength Training</option>
                  <option value="Flexibility">Flexibility/Yoga</option>
                  <option value="Sports">Sports</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Duration (minutes)</label>
                <input
                  type="number"
                  value={formData.duration}
                  onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., 30"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes (optional)</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  placeholder="Add any notes about your workout..."
                />
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Logging...
                    </>
                  ) : (
                    'Log Workout'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Workouts;