import React, { useState } from 'react';
import { useAppData } from '../contexts/AppDataContext';
import { Plus, Target, Calendar, Edit2, Trash2, Check, CheckCircle, AlertCircle, Loader2, Award } from 'lucide-react';
import SmartGoals from '../components/goals/SmartGoals';

interface Goal {
  id: string;
  title: string;
  description: string;
  category: 'Fitness' | 'Weight' | 'Nutrition' | 'Wellness';
  target_date: string;
  progress: number;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

const Goals: React.FC = () => {
  const { goals, addGoal, updateGoal, deleteGoal } = useAppData();
  const [viewMode, setViewMode] = useState<'simple' | 'smart'>('simple');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Fitness' as Goal['category'],
    targetDate: '',
    progress: 0
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      if (editingGoal) {
        await updateGoal(editingGoal.id, {
          title: formData.title,
          description: formData.description,
          category: formData.category,
          target_date: formData.targetDate,
          progress: formData.progress
        });
        setSubmitStatus('success');
      } else {
        const success = await addGoal({
          title: formData.title,
          description: formData.description,
          category: formData.category,
          target_date: formData.targetDate,
          progress: formData.progress,
          completed: false
        });
        
        if (success) {
          setSubmitStatus('success');
        } else {
          setSubmitStatus('error');
          setIsSubmitting(false);
          return;
        }
      }

      // Reset form
      setFormData({
        title: '',
        description: '',
        category: 'Fitness',
        targetDate: '',
        progress: 0
      });
      
      // Close modal after short delay
      setTimeout(() => {
        setIsModalOpen(false);
        setEditingGoal(null);
        setSubmitStatus('idle');
      }, 1500);
    } catch (error) {
      console.error('Error submitting goal:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (goal: Goal) => {
    setEditingGoal(goal);
    setFormData({
      title: goal.title,
      description: goal.description,
      category: goal.category,
      targetDate: goal.target_date,
      progress: goal.progress
    });
    setIsModalOpen(true);
  };

  const handleComplete = (goal: Goal) => {
    updateGoal(goal.id, { completed: true, progress: 100 });
  };

  const getCategoryColor = (category: Goal['category']) => {
    const colors = {
      Fitness: 'bg-blue-100 text-blue-800',
      Weight: 'bg-green-100 text-green-800',
      Nutrition: 'bg-yellow-100 text-yellow-800',
      Wellness: 'bg-purple-100 text-purple-800'
    };
    return colors[category];
  };

  const activeGoals = goals.filter(goal => !goal.completed);
  const completedGoals = goals.filter(goal => goal.completed);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Goals</h1>
          <p className="text-gray-600 mt-1">Track your fitness journey with personalized goals</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('simple')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'simple'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Simple Goals
            </button>
            <button
              onClick={() => setViewMode('smart')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'smart'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Award className="w-4 h-4 mr-1 inline" />
              SMART Goals
            </button>
          </div>
          {viewMode === 'simple' && (
            <button
              onClick={() => setIsModalOpen(true)}
              className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-green-700 transition-all duration-200 transform hover:scale-105"
            >
              <Plus className="h-5 w-5" />
              <span>Add Goal</span>
            </button>
          )}
        </div>
      </div>

      {viewMode === 'smart' ? (
        <SmartGoals
          goals={goals}
          onAddGoal={addGoal}
          onUpdateGoal={updateGoal}
          onDeleteGoal={deleteGoal}
        />
      ) : (
        <>
      {/* Active Goals */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Active Goals</h2>
        {activeGoals.length === 0 ? (
          <div className="text-center py-12">
            <Target className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No active goals</h3>
            <p className="text-gray-600 mb-4">Start your fitness journey by setting your first goal</p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Create Goal
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeGoals.map((goal) => (
              <div key={goal.id} className="border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(goal.category)}`}>
                    {goal.category}
                  </span>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleEdit(goal)}
                      className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => deleteGoal(goal.id)}
                      className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{goal.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{goal.description}</p>
                
                <div className="flex items-center space-x-2 text-sm text-gray-500 mb-4">
                  <Calendar className="h-4 w-4" />
                  <span>Target: {new Date(goal.target_date).toLocaleDateString()}</span>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">Progress</span>
                    <span className="text-sm font-medium text-gray-900">{goal.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-blue-600 to-green-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${goal.progress}%` }}
                    />
                  </div>
                </div>
                
                <button
                  onClick={() => handleComplete(goal)}
                  className="w-full flex items-center justify-center space-x-2 bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 transition-colors"
                >
                  <Check className="h-4 w-4" />
                  <span>Mark Complete</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
        </>
      )}

      {/* Completed Goals */}
      {completedGoals.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Completed Goals</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {completedGoals.map((goal) => (
              <div key={goal.id} className="border border-green-200 rounded-xl p-6 bg-green-50">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(goal.category)}`}>
                    {goal.category}
                  </span>
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                </div>
                
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{goal.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{goal.description}</p>
                
                <div className="w-full bg-green-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full w-full" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal */}
      {isModalOpen && viewMode === 'simple' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              {editingGoal ? 'Edit Goal' : 'Create New Goal'}
            </h2>
            
            {submitStatus === 'success' && (
              <div className="mb-4 p-3 bg-green-100 border border-green-200 rounded-lg flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="text-green-800">Goal {editingGoal ? 'updated' : 'created'} successfully!</span>
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="mb-4 p-3 bg-red-100 border border-red-200 rounded-lg flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <span className="text-red-800">Failed to {editingGoal ? 'update' : 'create'} goal. Please try again.</span>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value as Goal['category'] })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Fitness">Fitness</option>
                  <option value="Weight">Weight</option>
                  <option value="Nutrition">Nutrition</option>
                  <option value="Wellness">Wellness</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Date</label>
                <input
                  type="date"
                  value={formData.targetDate}
                  onChange={(e) => setFormData({ ...formData, targetDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Progress ({formData.progress}%)
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={formData.progress}
                  onChange={(e) => setFormData({ ...formData, progress: parseInt(e.target.value) })}
                  className="w-full"
                />
              </div>
              
              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingGoal(null);
                    setSubmitStatus('idle');
                    setFormData({
                      title: '',
                      description: '',
                      category: 'Fitness',
                      targetDate: '',
                      progress: 0
                    });
                  }}
                  className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      {editingGoal ? 'Updating...' : 'Creating...'}
                    </>
                  ) : (
                    editingGoal ? 'Update' : 'Create'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Goals;