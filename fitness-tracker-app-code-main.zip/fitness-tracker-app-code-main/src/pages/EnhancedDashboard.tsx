import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useAppData } from '../contexts/AppDataContext';
import { Target, Scale, Utensils, Activity, TrendingUp, Calendar, Trophy, Flame } from 'lucide-react';
import { Link } from 'react-router-dom';
import ProgressChart from '../components/charts/ProgressChart';
import CalorieChart from '../components/charts/CalorieChart';
import MacroChart from '../components/charts/MacroChart';
import AchievementBadge from '../components/achievements/AchievementBadge';
import AchievementNotification from '../components/achievements/AchievementNotification';
import { ChartDataPoint } from '../types/enhanced';
import { Achievement } from '../types/enhanced';
import { generateAchievements, checkAchievements } from '../data/achievements';

const EnhancedDashboard: React.FC = () => {
  const { profile } = useAuth();
  const { goals, weightLogs, meals, workouts, getTodayStats, isLoading } = useAppData();
  const [viewMode, setViewMode] = useState<'week' | 'month'>('week');
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [newAchievement, setNewAchievement] = useState<Achievement | null>(null);
  const [userStreaks, setUserStreaks] = useState({
    currentWorkoutStreak: 0,
    longestWorkoutStreak: 0,
    currentNutritionStreak: 0,
    longestNutritionStreak: 0
  });

  // Initialize achievements
  useEffect(() => {
    const savedAchievements = localStorage.getItem('user_achievements');
    if (savedAchievements) {
      setAchievements(JSON.parse(savedAchievements));
    } else {
      const initialAchievements = generateAchievements();
      setAchievements(initialAchievements);
      localStorage.setItem('user_achievements', JSON.stringify(initialAchievements));
    }
  }, []);

  // Update achievements when data changes
  useEffect(() => {
    if (achievements.length === 0) return;

    const completedGoals = goals.filter(goal => goal.completed).length;
    const totalCaloriesBurned = workouts.reduce((sum, workout) => sum + workout.calories_burned, 0);

    // Calculate streaks
    const today = new Date().toISOString().split('T')[0];
    const workoutDates = [...new Set(workouts.map(w => w.date))].sort();
    const mealDates = [...new Set(meals.map(m => m.date))].sort();

    const calculateStreak = (dates: string[]) => {
      if (dates.length === 0) return 0;
      
      let streak = 0;
      const today = new Date();
      let currentDate = new Date(today);
      
      for (let i = 0; i < 365; i++) { // Check up to a year
        const dateStr = currentDate.toISOString().split('T')[0];
        if (dates.includes(dateStr)) {
          streak++;
        } else if (streak > 0) {
          break;
        }
        currentDate.setDate(currentDate.getDate() - 1);
      }
      
      return streak;
    };

    const workoutStreak = calculateStreak(workoutDates);
    const nutritionStreak = calculateStreak(mealDates);

    setUserStreaks(prev => ({
      ...prev,
      currentWorkoutStreak: workoutStreak,
      currentNutritionStreak: nutritionStreak
    }));

    const stats = {
      totalWorkouts: workouts.length,
      totalMeals: meals.length,
      completedGoals,
      totalCaloriesBurned,
      workoutStreak,
      nutritionStreak,
      proteinGoalDays: 0, // Would need to implement protein goal tracking
      macroGoalDays: 0    // Would need to implement macro goal tracking
    };

    const updatedAchievements = checkAchievements(achievements, stats);
    
    // Check for newly unlocked achievements
    const newlyUnlocked = updatedAchievements.find(
      (achievement, index) => achievement.unlocked && !achievements[index]?.unlocked
    );

    if (newlyUnlocked) {
      setNewAchievement(newlyUnlocked);
    }

    setAchievements(updatedAchievements);
    localStorage.setItem('user_achievements', JSON.stringify(updatedAchievements));
  }, [goals, workouts, meals, achievements.length]);

  // Force show content after 3 seconds even if still loading
  const [forceShow, setForceShow] = React.useState(false);
  
  React.useEffect(() => {
    const timer = setTimeout(() => {
      setForceShow(true);
    }, 3000);
    
    return () => clearTimeout(timer);
  }, []);

  if (isLoading && !forceShow) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
          <p className="text-sm text-gray-500 mt-2">This should only take a moment...</p>
        </div>
      </div>
    );
  }

  const todayStats = getTodayStats();
  const activeGoals = goals.filter(goal => !goal.completed);
  const completedGoals = goals.filter(goal => goal.completed);
  const recentAchievements = achievements.filter(a => a.unlocked).slice(-3);

  // Generate chart data
  const generateWeightChartData = (): ChartDataPoint[] => {
    const days = viewMode === 'week' ? 7 : 30;
    const endDate = new Date();
    const startDate = new Date(endDate);
    startDate.setDate(startDate.getDate() - days);

    return weightLogs
      .filter(log => {
        const logDate = new Date(log.date);
        return logDate >= startDate && logDate <= endDate;
      })
      .map(log => ({
        date: log.date,
        value: log.weight
      }));
  };

  const generateCalorieChartData = () => {
    const days = viewMode === 'week' ? 7 : 30;
    const data = [];
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dayMeals = meals.filter(meal => meal.date === dateStr);
      const dayWorkouts = workouts.filter(workout => workout.date === dateStr);
      
      const consumed = dayMeals.reduce((sum, meal) => sum + meal.calories, 0);
      const burned = dayWorkouts.reduce((sum, workout) => sum + workout.calories_burned, 0);
      
      data.push({
        date: dateStr,
        consumed,
        burned,
        net: consumed - burned
      });
    }
    
    return data;
  };

  // Calculate today's macros
  const todayMeals = meals.filter(meal => meal.date === new Date().toISOString().split('T')[0]);
  const todayMacros = todayMeals.reduce(
    (acc, meal) => ({
      protein: acc.protein + (meal.food_name ? 0 : 0), // Would need enhanced meal structure
      carbs: acc.carbs + (meal.food_name ? 0 : 0),
      fats: acc.fats + (meal.food_name ? 0 : 0)
    }),
    { protein: 25, carbs: 150, fats: 60 } // Mock data for demo
  );

  const quickStats = [
    {
      label: 'Today\'s Calories',
      value: todayStats.calories,
      unit: 'kcal',
      icon: Utensils,
      color: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-50'
    },
    {
      label: 'Workouts Today',
      value: todayStats.workouts,
      unit: 'sessions',
      icon: Activity,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      label: 'Active Goals',
      value: activeGoals.length,
      unit: 'goals',
      icon: Target,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      label: 'Workout Streak',
      value: userStreaks.currentWorkoutStreak,
      unit: 'days',
      icon: Flame,
      color: 'from-orange-500 to-red-500',
      bgColor: 'bg-orange-50'
    }
  ];

  const quickActions = [
    { name: 'Log Food', href: '/nutrition', icon: Utensils, color: 'bg-green-500' },
    { name: 'Add Workout', href: '/workouts', icon: Activity, color: 'bg-blue-500' },
    { name: 'Set Goal', href: '/goals', icon: Target, color: 'bg-purple-500' },
    { name: 'Track Weight', href: '/weight', icon: Scale, color: 'bg-orange-500' }
  ];

  return (
    <div className="space-y-8">
      <AchievementNotification 
        achievement={newAchievement}
        onClose={() => setNewAchievement(null)}
      />

      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Welcome back, {profile?.name}!</h1>
            <p className="text-blue-100 text-lg">
              {new Date().toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </p>
            <div className="flex items-center space-x-4 mt-4">
              <div className="flex items-center space-x-2">
                <Flame className="w-5 h-5 text-orange-300" />
                <span className="text-blue-100">
                  {userStreaks.currentWorkoutStreak} day workout streak
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-yellow-300" />
                <span className="text-blue-100">
                  {achievements.filter(a => a.unlocked).length} achievements
                </span>
              </div>
            </div>
          </div>
          <TrendingUp className="h-16 w-16 text-white opacity-20" />
        </div>
      </div>

      {/* View Toggle */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Your Progress</h2>
        <div className="flex bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => setViewMode('week')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              viewMode === 'week'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Week
          </button>
          <button
            onClick={() => setViewMode('month')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              viewMode === 'month'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Month
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {quickStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className={`${stat.bgColor} rounded-2xl p-6 border border-gray-100`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">
                    {stat.value} <span className="text-lg font-medium text-gray-600">{stat.unit}</span>
                  </p>
                </div>
                <div className={`p-3 rounded-xl bg-gradient-to-r ${stat.color}`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ProgressChart
          data={generateWeightChartData()}
          title={`Weight Progress (${viewMode === 'week' ? 'Last 7 Days' : 'Last 30 Days'})`}
          color="#3B82F6"
          unit="kg"
        />
        <MacroChart
          protein={todayMacros.protein}
          carbs={todayMacros.carbs}
          fats={todayMacros.fats}
          title="Today's Macros"
        />
      </div>

      <CalorieChart
        data={generateCalorieChartData()}
        title={`Calorie Balance (${viewMode === 'week' ? 'Last 7 Days' : 'Last 30 Days'})`}
      />

      {/* Quick Actions */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Link
                key={index}
                to={action.href}
                className="flex flex-col items-center p-4 rounded-xl hover:bg-gray-50 transition-colors group"
              >
                <div className={`p-3 rounded-xl ${action.color} group-hover:scale-110 transition-transform`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <span className="text-sm font-medium text-gray-700 mt-2">{action.name}</span>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Achievements & Goals */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Achievements */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Achievements</h2>
            <Link to="/achievements" className="text-blue-600 hover:text-blue-800 text-sm font-medium">
              View All
            </Link>
          </div>
          {recentAchievements.length === 0 ? (
            <div className="text-center py-8">
              <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No achievements yet</p>
              <p className="text-sm text-gray-400">Keep working towards your goals!</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-4">
              {recentAchievements.map((achievement) => (
                <AchievementBadge
                  key={achievement.id}
                  achievement={achievement}
                  size="small"
                  showProgress={false}
                />
              ))}
            </div>
          )}
        </div>

        {/* Active Goals */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Active Goals</h2>
            <Link to="/goals" className="text-blue-600 hover:text-blue-800 text-sm font-medium">
              View All
            </Link>
          </div>
          {activeGoals.length === 0 ? (
            <div className="text-center py-8">
              <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No active goals</p>
              <Link to="/goals" className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                Create your first goal
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {activeGoals.slice(0, 3).map((goal) => (
                <div key={goal.id} className="border-l-4 border-blue-500 pl-4 py-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">{goal.title}</h3>
                      <p className="text-sm text-gray-600">{goal.category}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">{goal.progress}%</p>
                      <div className="w-20 bg-gray-200 rounded-full h-2 mt-1">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${goal.progress}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EnhancedDashboard;