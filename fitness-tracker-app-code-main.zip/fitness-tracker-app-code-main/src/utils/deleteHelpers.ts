// Helper functions for deleting entries across the application

export const deleteWorkoutEntry = (workouts: any[], workoutId: string, updateWorkouts: (workouts: any[]) => void) => {
  if (confirm('Are you sure you want to delete this workout entry?')) {
    const updatedWorkouts = workouts.filter(workout => workout.id !== workoutId);
    updateWorkouts(updatedWorkouts);
    return true;
  }
  return false;
};

export const deleteMealEntry = (meals: any[], mealId: string, updateMeals: (meals: any[]) => void) => {
  if (confirm('Are you sure you want to delete this meal entry?')) {
    const updatedMeals = meals.filter(meal => meal.id !== mealId);
    updateMeals(updatedMeals);
    return true;
  }
  return false;
};

export const deleteWeightEntry = (weightLogs: any[], entryId: string, updateWeightLogs: (logs: any[]) => void) => {
  if (confirm('Are you sure you want to delete this weight entry?')) {
    const updatedLogs = weightLogs.filter(log => log.id !== entryId);
    updateWeightLogs(updatedLogs);
    return true;
  }
  return false;
};

export const deleteGoalEntry = (goals: any[], goalId: string, updateGoals: (goals: any[]) => void) => {
  if (confirm('Are you sure you want to delete this goal? This action cannot be undone.')) {
    const updatedGoals = goals.filter(goal => goal.id !== goalId);
    updateGoals(updatedGoals);
    return true;
  }
  return false;
};

export const deleteProgressPhoto = (photos: any[], photoId: string, updatePhotos: (photos: any[]) => void) => {
  if (confirm('Are you sure you want to delete this progress photo?')) {
    const updatedPhotos = photos.filter(photo => photo.id !== photoId);
    updatePhotos(updatedPhotos);
    return true;
  }
  return false;
};

// Bulk delete functions
export const bulkDeleteEntries = (entries: any[], selectedIds: string[], updateEntries: (entries: any[]) => void, entryType: string) => {
  if (selectedIds.length === 0) {
    alert('Please select entries to delete.');
    return false;
  }

  if (confirm(`Are you sure you want to delete ${selectedIds.length} ${entryType} entries? This action cannot be undone.`)) {
    const updatedEntries = entries.filter(entry => !selectedIds.includes(entry.id));
    updateEntries(updatedEntries);
    return true;
  }
  return false;
};

// Undo delete functionality
export const createUndoDeleteSystem = () => {
  const deletedEntries: { [key: string]: { data: any, timestamp: number } } = {};
  const UNDO_TIMEOUT = 10000; // 10 seconds

  const softDelete = (entryId: string, entryData: any, entryType: string) => {
    deletedEntries[entryId] = {
      data: entryData,
      timestamp: Date.now()
    };

    // Auto-cleanup after timeout
    setTimeout(() => {
      delete deletedEntries[entryId];
    }, UNDO_TIMEOUT);

    return {
      canUndo: true,
      undoTimeLeft: UNDO_TIMEOUT,
      undo: () => {
        if (deletedEntries[entryId]) {
          const data = deletedEntries[entryId].data;
          delete deletedEntries[entryId];
          return data;
        }
        return null;
      }
    };
  };

  return { softDelete };
};