import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Activity, Mail, Lock, User } from 'lucide-react';

const AuthForm: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, register, resetPassword, isSupabaseConnected } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isSupabaseConnected) {
      setError('Demo mode: Please configure Supabase environment variables to enable authentication.');
      return;
    }
    
    setError('');
    setSuccessMessage('');
    setLoading(true);

    try {
      let result;
      if (isLogin) {
        result = await login(email, password);
      } else {
        if (!name.trim()) {
          setError('Name is required');
          setLoading(false);
          return;
        }
        result = await register(email, password, name);
      }

      if (!result.success) {
        setError(result.error || 'Authentication failed. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isSupabaseConnected) {
      setError('Demo mode: Please configure Supabase environment variables to enable password reset.');
      return;
    }
    
    if (!email.trim()) {
      setError('Please enter your email address');
      return;
    }
    
    setError('');
    setSuccessMessage('');
    setLoading(true);

    try {
      const result = await resetPassword(email);
      
      if (result.success) {
        setSuccessMessage('Password reset email sent! Please check your inbox and follow the instructions. The link will expire in 1 hour.');
        setShowForgotPassword(false);
      } else {
        setError(result.error || 'Failed to send password reset email. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setEmail('');
    setPassword('');
    setName('');
    setError('');
    setSuccessMessage('');
    setLoading(false);
  };

  if (showForgotPassword) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-green-50 px-4">
        <div className="max-w-md w-full">
          <div className="bg-white rounded-2xl shadow-2xl p-8">
            <div className="text-center mb-8">
              <div className="flex items-center justify-center mb-4">
                <Activity className="h-12 w-12 text-blue-600" />
              </div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
                Reset Password
              </h1>
              <p className="text-gray-600 mt-2">
                Enter your email to receive reset instructions
              </p>
            </div>

            <form onSubmit={handleForgotPassword} className="space-y-6">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="email"
                  placeholder="Email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                  required
                />
              </div>

              {error && (
                <div className="text-red-600 text-sm text-center bg-red-50 py-2 px-3 rounded-lg">
                  {error}
                </div>
              )}

              {successMessage && (
                <div className="text-green-600 text-sm text-center bg-green-50 py-2 px-3 rounded-lg">
                  {successMessage}
                  <div className="mt-2 text-xs text-green-700">
                    <p><strong>Important:</strong> Check your spam folder if you don't see the email.</p>
                    <p>The reset link expires in 1 hour for security.</p>
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading || !isSupabaseConnected}
                className={`w-full py-3 px-4 rounded-xl font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 ${
                  !isSupabaseConnected 
                    ? 'bg-yellow-500 text-white cursor-not-allowed hover:bg-yellow-600' 
                    : 'bg-gradient-to-r from-blue-600 to-green-600 text-white hover:from-blue-700 hover:to-green-700 transform hover:scale-105'
                }`}
              >
                {!isSupabaseConnected ? '⚙️ Setup Required' : (loading ? 'Sending...' : 'Send Reset Email')}
              </button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => {
                  setShowForgotPassword(false);
                  resetForm();
                }}
                className="text-blue-600 hover:text-blue-800 font-medium transition-colors"
              >
                ← Back to Sign In
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-green-50 px-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <>
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <Activity className="h-12 w-12 text-blue-600" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
              FitTracker Pro
            </h1>
            <p className="text-gray-600 mt-2">
              {isLogin ? 'Welcome back!' : 'Start your fitness journey'}
            </p>
            {!isSupabaseConnected && (
              <div className="mt-4 p-3 bg-yellow-100 border border-yellow-300 rounded-lg">
                <p className="text-yellow-800 text-sm text-center">
                  <strong>⚠️ Demo Mode</strong><br/>
                  Supabase not configured. To enable full functionality:
                </p>
                <div className="mt-2 text-xs text-yellow-700">
                  <p>1. Create a Supabase project at <a href="https://supabase.com" target="_blank" rel="noopener noreferrer" className="underline">supabase.com</a></p>
                  <p>2. Copy your project URL and anon key</p>
                  <p>3. Create a <code>.env</code> file with:</p>
                  <div className="bg-yellow-50 p-2 mt-1 rounded font-mono text-xs">
                    <div>VITE_SUPABASE_URL=your_project_url</div>
                    <div>VITE_SUPABASE_ANON_KEY=your_anon_key</div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {!isLogin && (
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Full Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                  required={!isLogin}
                />
              </div>
            )}

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                required
              />
            </div>

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                required
              />
            </div>

            {error && (
              <div className="text-red-600 text-sm text-center bg-red-50 py-2 px-3 rounded-lg">
                {error}
                {!isSupabaseConnected && (
                  <div className="mt-2 text-xs">
                    <p><strong>Need help?</strong></p>
                    <p>Check the console for detailed setup instructions</p>
                  </div>
                )}
              </div>
            )}

            {successMessage && (
              <div className="text-green-600 text-sm text-center bg-green-50 py-2 px-3 rounded-lg">
                {successMessage}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className={`w-full py-3 px-4 rounded-xl font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 ${
                !isSupabaseConnected 
                  ? 'bg-yellow-500 text-white cursor-not-allowed hover:bg-yellow-600' 
                  : 'bg-gradient-to-r from-blue-600 to-green-600 text-white hover:from-blue-700 hover:to-green-700 transform hover:scale-105'
              }`}
            >
              {!isSupabaseConnected ? '⚙️ Setup Required' : (loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Create Account'))}
            </button>
          </form>

          <div className="mt-6 text-center">
            {isLogin && isSupabaseConnected && (
              <div className="mb-4">
                <button
                  onClick={() => {
                    setShowForgotPassword(true);
                    setError('');
                    setSuccessMessage('');
                  }}
                  className="text-blue-600 hover:text-blue-800 font-medium transition-colors text-sm"
                >
                  Forgot your password?
                </button>
              </div>
            )}
            {isSupabaseConnected && (
              <button
                onClick={() => {
                  setIsLogin(!isLogin);
                  resetForm();
                }}
                className="text-blue-600 hover:text-blue-800 font-medium transition-colors"
              >
                {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
              </button>
            )}
            {!isSupabaseConnected && (
              <div className="text-sm text-gray-600">
                <p>Running in demo mode</p>
                <p className="text-xs mt-1">Configure Supabase to enable authentication</p>
              </div>
            )}
          </div>
          </>
        </div>
      </div>
    </div>
  );
};

export default AuthForm;