import React, { useState, useEffect } from 'react';
import { Droplets, Plus, Minus, Target } from 'lucide-react';

interface WaterEntry {
  id: string;
  amount: number;
  timestamp: Date;
}

interface WaterTrackerProps {
  onLogWater: (amount: number) => void;
  dailyGoal?: number;
}

const WaterTracker: React.FC<WaterTrackerProps> = ({ onLogWater, dailyGoal = 2000 }) => {
  const [todayIntake, setTodayIntake] = useState(0);
  const [waterEntries, setWaterEntries] = useState<WaterEntry[]>([]);
  const [customAmount, setCustomAmount] = useState(250);

  const quickAmounts = [100, 250, 500, 750];

  useEffect(() => {
    // Load today's water intake from localStorage
    const today = new Date().toDateString();
    const savedEntries = localStorage.getItem(`water_entries_${today}`);
    if (savedEntries) {
      const entries = JSON.parse(savedEntries);
      setWaterEntries(entries);
      const total = entries.reduce((sum: number, entry: WaterEntry) => sum + entry.amount, 0);
      setTodayIntake(total);
    }
  }, []);

  const addWater = (amount: number) => {
    const newEntry: WaterEntry = {
      id: Date.now().toString(),
      amount,
      timestamp: new Date()
    };

    const updatedEntries = [...waterEntries, newEntry];
    setWaterEntries(updatedEntries);
    
    const newTotal = todayIntake + amount;
    setTodayIntake(newTotal);
    
    // Save to localStorage
    const today = new Date().toDateString();
    localStorage.setItem(`water_entries_${today}`, JSON.stringify(updatedEntries));
    
    onLogWater(amount);
  };

  const removeLastEntry = () => {
    if (waterEntries.length === 0) return;

    const lastEntry = waterEntries[waterEntries.length - 1];
    const updatedEntries = waterEntries.slice(0, -1);
    setWaterEntries(updatedEntries);
    
    const newTotal = todayIntake - lastEntry.amount;
    setTodayIntake(Math.max(0, newTotal));
    
    // Save to localStorage
    const today = new Date().toDateString();
    localStorage.setItem(`water_entries_${today}`, JSON.stringify(updatedEntries));
  };

  const progressPercentage = Math.min((todayIntake / dailyGoal) * 100, 100);
  const glassesCount = Math.floor(todayIntake / 250); // Assuming 250ml per glass

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-blue-100 rounded-xl">
            <Droplets className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Water Intake</h3>
            <p className="text-sm text-gray-600">Stay hydrated throughout the day</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-blue-600">{todayIntake}ml</p>
          <p className="text-sm text-gray-600">of {dailyGoal}ml</p>
        </div>
      </div>

      {/* Water Bottle Visualization */}
      <div className="flex items-center justify-center mb-6">
        <div className="relative">
          <div className="w-20 h-32 border-4 border-blue-300 rounded-b-lg rounded-t-sm bg-gradient-to-t from-blue-100 to-transparent">
            <div 
              className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-blue-400 to-blue-300 rounded-b-lg transition-all duration-500 ease-out"
              style={{ height: `${progressPercentage}%` }}
            />
          </div>
          <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-8 h-4 border-2 border-blue-300 rounded-t-lg bg-white" />
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-gray-700">Daily Progress</span>
          <span className="text-sm text-gray-600">{Math.round(progressPercentage)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-3">
          <div
            className="bg-gradient-to-r from-blue-400 to-blue-600 h-3 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>0ml</span>
          <span>{dailyGoal}ml</span>
        </div>
      </div>

      {/* Quick Add Buttons */}
      <div className="mb-6">
        <p className="text-sm font-medium text-gray-700 mb-3">Quick Add</p>
        <div className="grid grid-cols-4 gap-2">
          {quickAmounts.map((amount) => (
            <button
              key={amount}
              onClick={() => addWater(amount)}
              className="flex flex-col items-center p-3 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
            >
              <Droplets className="w-4 h-4 text-blue-600 mb-1" />
              <span className="text-xs font-medium text-blue-900">{amount}ml</span>
            </button>
          ))}
        </div>
      </div>

      {/* Custom Amount */}
      <div className="mb-6">
        <p className="text-sm font-medium text-gray-700 mb-3">Custom Amount</p>
        <div className="flex items-center space-x-3">
          <input
            type="number"
            value={customAmount}
            onChange={(e) => setCustomAmount(parseInt(e.target.value) || 0)}
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Amount in ml"
            min="1"
            max="2000"
          />
          <button
            onClick={() => addWater(customAmount)}
            className="flex items-center justify-center w-10 h-10 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <p className="text-2xl font-bold text-gray-900">{glassesCount}</p>
          <p className="text-sm text-gray-600">Glasses</p>
        </div>
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <p className="text-2xl font-bold text-gray-900">{waterEntries.length}</p>
          <p className="text-sm text-gray-600">Entries</p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex space-x-3">
        <button
          onClick={removeLastEntry}
          disabled={waterEntries.length === 0}
          className="flex-1 flex items-center justify-center space-x-2 py-2 px-4 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Minus className="w-4 h-4" />
          <span>Undo Last</span>
        </button>
        <button
          onClick={() => {
            const remaining = Math.max(0, dailyGoal - todayIntake);
            if (remaining > 0) {
              addWater(remaining);
            }
          }}
          disabled={todayIntake >= dailyGoal}
          className="flex-1 flex items-center justify-center space-x-2 py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Target className="w-4 h-4" />
          <span>Complete Goal</span>
        </button>
      </div>

      {/* Recent Entries */}
      {waterEntries.length > 0 && (
        <div className="mt-6">
          <p className="text-sm font-medium text-gray-700 mb-3">Recent Entries</p>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {waterEntries.slice(-5).reverse().map((entry) => (
              <div key={entry.id} className="flex justify-between items-center text-sm">
                <span className="text-gray-600">
                  {entry.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
                <span className="font-medium text-blue-600">{entry.amount}ml</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default WaterTracker;