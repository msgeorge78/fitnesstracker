import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX, Video, VideoOff } from 'lucide-react';

interface MeditationTimerProps {
  onSessionComplete: (duration: number, type: string) => void;
}

const MeditationTimer: React.FC<MeditationTimerProps> = ({ onSessionComplete }) => {
  const [duration, setDuration] = useState(10); // minutes
  const [timeLeft, setTimeLeft] = useState(duration * 60); // seconds
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [meditationType, setMeditationType] = useState('mindfulness');
  const [ambientSound, setAmbientSound] = useState('none');
  const [isSoundEnabled, setIsSoundEnabled] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState('meditation');
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const ambientSounds = [
    { id: 'none', name: 'Silence', url: null },
    { id: 'rain', name: 'Rain', url: '/sounds/rain.mp3' },
    { id: 'ocean', name: 'Ocean Waves', url: '/sounds/ocean.mp3' },
    { id: 'forest', name: 'Forest', url: '/sounds/forest.mp3' },
    { id: 'bells', name: 'Tibetan Bells', url: '/sounds/bells.mp3' }
  ];

  const meditationTypes = [
    { id: 'mindfulness', name: 'Mindfulness', description: 'Focus on breath and present moment' },
    { id: 'body-scan', name: 'Body Scan', description: 'Progressive relaxation technique' },
    { id: 'loving-kindness', name: 'Loving Kindness', description: 'Cultivate compassion and love' },
    { id: 'breathing', name: 'Breathing', description: 'Focused breathing exercises' }
  ];

  const meditationVideos = [
    { id: 'meditation', name: 'Meditation Video', url: './videos/meditation-video.mp4' }
  ];

  useEffect(() => {
    setTimeLeft(duration * 60);
  }, [duration]);

  useEffect(() => {
    if (isActive && !isPaused) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((time) => {
          if (time <= 1) {
            setIsActive(false);
            setIsPaused(false);
            onSessionComplete(duration, meditationType);
            playCompletionSound();
            return 0;
          }
          return time - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isActive, isPaused, duration, meditationType, onSessionComplete]);

  useEffect(() => {
    // Handle audio
    if (isSoundEnabled && ambientSound !== 'none') {
      const sound = ambientSounds.find(s => s.id === ambientSound);
      if (sound?.url) {
        audioRef.current = new Audio(sound.url);
        audioRef.current.loop = true;
        audioRef.current.volume = 0.3;
      }
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [ambientSound, isSoundEnabled]);

  // Separate effect for controlling audio/video playback
  useEffect(() => {
    // Handle audio playback
    if (audioRef.current) {
      if (isActive && !isPaused) {
        audioRef.current.play().catch(console.error);
      } else {
        audioRef.current.pause();
      }
    }

    // Handle video playback
    if (isVideoEnabled && videoRef.current) {
      const video = videoRef.current;
      
      if (isActive && !isPaused) {
        console.log('🎬 Starting video playback');
        video.play().catch((error) => {
          console.error('Video play failed:', error);
          // If autoplay fails, try with muted
          video.muted = true;
          video.play().catch(console.error);
        });
      } else {
        console.log('⏸️ Pausing video playback');
        video.pause();
      }
    }
  }, [isActive, isPaused, isVideoEnabled]);

  const playCompletionSound = () => {
    const audio = new Audio('/sounds/meditation-bell.mp3');
    audio.play().catch(console.error);
  };

  const toggleTimer = () => {
    if (!isActive) {
      console.log('▶️ Starting meditation timer');
      setIsActive(true);
      setIsPaused(false);
    } else {
      console.log(isPaused ? '▶️ Resuming meditation' : '⏸️ Pausing meditation');
      setIsPaused(!isPaused);
    }
  };

  const resetTimer = () => {
    console.log('🔄 Resetting meditation timer');
    setIsActive(false);
    setIsPaused(false);
    setTimeLeft(duration * 60);
    if (audioRef.current) {
      audioRef.current.pause();
    }
    if (videoRef.current) {
      videoRef.current.pause();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = ((duration * 60 - timeLeft) / (duration * 60)) * 100;

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
      {/* Video Background */}
      {isVideoEnabled && (
        <div className="relative mb-6 rounded-xl overflow-hidden bg-black shadow-lg">
          <video
            ref={videoRef}
            className="w-full h-80 object-cover"
            controls={false}
            loop
            playsInline
            preload="metadata"
            onError={(e) => {
              console.error('Video failed to load:', e);
              console.log('Video source:', meditationVideos.find(v => v.id === selectedVideo)?.url);
            }}
            onLoadedData={() => {
              console.log('Video loaded successfully');
              // Set video properties when loaded
              if (videoRef.current) {
                videoRef.current.muted = false;
                videoRef.current.loop = true;
                videoRef.current.volume = 0.3;
              }
            }}
            onCanPlay={() => {
              console.log('Video can play');
            }}
          >
            <source src={meditationVideos.find(v => v.id === selectedVideo)?.url} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          
          {/* Fallback message if video fails to load */}
          <div className="absolute inset-0 bg-gray-800 text-white flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300">
            <div className="text-center p-4">
              <p className="text-sm">🎥 Meditation Video</p>
              <p className="text-xs mt-1 opacity-75">mindfulness.mp4 loaded</p>
            </div>
          </div>
          
          <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
            <div className="text-white text-center">
              <div className="text-6xl font-bold mb-2 drop-shadow-lg">{formatTime(timeLeft)}</div>
              <div className="text-lg opacity-90 drop-shadow-md">{meditationTypes.find(t => t.id === meditationType)?.name}</div>
              <div className="mt-4">
                <div className="w-32 bg-white bg-opacity-30 rounded-full h-2 mx-auto">
                  <div 
                    className="bg-white h-2 rounded-full transition-all duration-1000 ease-linear"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Meditation Timer</h2>
        <p className="text-gray-600">Find your inner peace with guided meditation</p>
      </div>

      {/* Meditation Type Selection */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-3">Meditation Type</label>
        <div className="grid grid-cols-2 gap-3">
          {meditationTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => setMeditationType(type.id)}
              disabled={isActive}
              className={`p-3 rounded-lg border text-left transition-colors ${
                meditationType === type.id
                  ? 'border-blue-500 bg-blue-50 text-blue-900'
                  : 'border-gray-200 hover:bg-gray-50'
              } ${isActive ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <p className="font-medium text-sm">{type.name}</p>
              <p className="text-xs text-gray-600 mt-1">{type.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Duration Selection */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-3">Duration</label>
        <div className="flex space-x-2">
          {[5, 10, 15, 20, 30].map((mins) => (
            <button
              key={mins}
              onClick={() => setDuration(mins)}
              disabled={isActive}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                duration === mins
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              } ${isActive ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {mins}m
            </button>
          ))}
        </div>
      </div>

      {/* Video Selection */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <label className="block text-sm font-medium text-gray-700">
            Meditation Video {!isVideoEnabled && '(Disabled)'}
          </label>
          <button
            onClick={() => setIsVideoEnabled(!isVideoEnabled)}
            disabled={isActive}
            className={`p-2 rounded-lg transition-colors cursor-pointer hover:bg-gray-100 ${
              isVideoEnabled ? 'text-blue-600' : 'text-gray-400'
            } ${isActive ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={isVideoEnabled ? 'Disable video meditation' : 'Enable video meditation'}
          >
            {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
          </button>
        </div>
        
        <div 
          className={`p-4 border rounded-lg cursor-pointer transition-all duration-200 ${
            isVideoEnabled 
              ? 'border-blue-200 bg-blue-50 hover:bg-blue-100' 
              : 'border-gray-200 bg-gray-50 hover:bg-gray-100'
          } ${isActive ? 'cursor-not-allowed opacity-75' : ''}`}
          onClick={() => !isActive && setIsVideoEnabled(!isVideoEnabled)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Video className={`w-5 h-5 ${isVideoEnabled ? 'text-blue-600' : 'text-gray-400'}`} />
              <div>
                <p className={`font-medium ${isVideoEnabled ? 'text-blue-900' : 'text-gray-600'}`}>
                  Mindfulness Video
                </p>
                <p className="text-sm text-gray-600">
                  {isVideoEnabled 
                    ? '🎬 Your mindfulness video will play during meditation' 
                    : 'Click to enable visual meditation experience'
                  }
                </p>
              </div>
            </div>
            <div className={`p-2 rounded-full ${isVideoEnabled ? 'bg-blue-200' : 'bg-gray-200'}`}>
              {isVideoEnabled ? (
                <Video className="w-4 h-4 text-blue-600" />
              ) : (
                <VideoOff className="w-4 h-4 text-gray-500" />
              )}
            </div>
          </div>
        </div>
        
        <div className="mt-2 flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${isVideoEnabled ? 'bg-green-500' : 'bg-gray-400'}`}></div>
          <p className="text-xs text-gray-500">
            {isVideoEnabled 
              ? '✅ Video mode enabled - mindfulness.mp4 ready' 
              : '📹 Video available - click above to enable immersive meditation'
            }
          </p>
        </div>
      </div>

      {/* Video Preview (when enabled but not active) */}
      {isVideoEnabled && !isActive && (
        <div className="mb-6">
          <div className="relative rounded-xl overflow-hidden bg-black shadow-lg">
            <video
              ref={videoRef}
              className="w-full h-40 object-cover"
              controls={false}
              loop
              muted
              playsInline
              preload="metadata"
              onLoadedData={() => {
                // Set properties for preview video too
                if (videoRef.current) {
                  videoRef.current.loop = true;
                }
              }}
            >
              <source src={meditationVideos.find(v => v.id === selectedVideo)?.url} type="video/mp4" />
            </video>
            <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
              <div className="text-white text-center">
                <Play className="w-12 h-12 mx-auto mb-2 opacity-75" />
                <p className="text-sm">Preview: mindfulness.mp4</p>
                <p className="text-xs opacity-75">Will play during meditation</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Ambient Sound Selection */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-3">
          <label className="block text-sm font-medium text-gray-700">Ambient Sound</label>
          <button
            onClick={() => setIsSoundEnabled(!isSoundEnabled)}
            className={`p-1 rounded transition-colors ${
              isSoundEnabled ? 'text-blue-600' : 'text-gray-400'
            }`}
          >
            {isSoundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
        <select
          value={ambientSound}
          onChange={(e) => setAmbientSound(e.target.value)}
          disabled={isActive || !isSoundEnabled}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
        >
          {ambientSounds.map((sound) => (
            <option key={sound.id} value={sound.id}>
              {sound.name}
            </option>
          ))}
        </select>
      </div>

      {/* Timer Display */}
      <div className={`text-center mb-8 ${isVideoEnabled ? 'hidden' : ''}`}>
        <div className="relative w-48 h-48 mx-auto mb-6">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="#e5e7eb"
              strokeWidth="8"
              fill="none"
            />
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="#3b82f6"
              strokeWidth="8"
              fill="none"
              strokeDasharray={`${2 * Math.PI * 45}`}
              strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
              className="transition-all duration-1000 ease-linear"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-4xl font-bold text-gray-900">{formatTime(timeLeft)}</span>
          </div>
        </div>

      </div>

      {/* Universal Timer Controls */}
      <div className="text-center mb-8">
        <div className="flex justify-center space-x-4">
          <button
            onClick={toggleTimer}
            className={`flex items-center justify-center w-16 h-16 rounded-full text-white transition-all duration-200 transform hover:scale-105 ${
              isActive && !isPaused
                ? 'bg-orange-500 hover:bg-orange-600'
                : 'bg-green-500 hover:bg-green-600'
            }`}
          >
            {isActive && !isPaused ? (
              <Pause className="w-6 h-6" />
            ) : (
              <Play className="w-6 h-6 ml-1" />
            )}
          </button>

          <button
            onClick={resetTimer}
            className="flex items-center justify-center w-16 h-16 rounded-full bg-gray-500 text-white hover:bg-gray-600 transition-all duration-200 transform hover:scale-105"
          >
            <RotateCcw className="w-6 h-6" />
          </button>
        </div>
        
        {!isActive && (
          <p className="text-sm text-gray-600 mt-4">
            Ready to start your {meditationTypes.find(t => t.id === meditationType)?.name.toLowerCase()} meditation
            {isVideoEnabled ? ' with video' : ''}
          </p>
        )}
      </div>

      {/* Session Status */}
      {isActive && (
        <div className="text-center">
          {isVideoEnabled && (
            <div className="mb-2">
              <p className="text-xs text-gray-500">
                🎥 Immersive video meditation active
              </p>
            </div>
          )}
          <p className="text-sm text-gray-600">
            {isPaused ? 'Meditation paused' : `${meditationTypes.find(t => t.id === meditationType)?.name} meditation in progress`}
          </p>
        </div>
      )}
    </div>
  );
};

export default MeditationTimer;