import React, { useState, useEffect } from 'react';
import { Moon, Sun, Clock, TrendingUp, Calendar } from 'lucide-react';

interface SleepEntry {
  id: string;
  date: string;
  bedtime: string;
  wakeTime: string;
  duration: number;
  quality: number;
  notes?: string;
  created_at: string;
}

interface SleepTrackerProps {
  onLogSleep: (entry: Omit<SleepEntry, 'id' | 'created_at'>) => void;
}

const SleepTracker: React.FC<SleepTrackerProps> = ({ onLogSleep }) => {
  const [sleepEntries, setSleepEntries] = useState<SleepEntry[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    bedtime: '22:00',
    wakeTime: '07:00',
    quality: 3,
    notes: ''
  });

  useEffect(() => {
    // Load sleep entries from localStorage
    const savedEntries = localStorage.getItem('sleep_entries');
    if (savedEntries) {
      setSleepEntries(JSON.parse(savedEntries));
    }
  }, []);

  const calculateDuration = (bedtime: string, wakeTime: string): number => {
    const bed = new Date(`2000-01-01T${bedtime}`);
    let wake = new Date(`2000-01-01T${wakeTime}`);
    
    // If wake time is earlier than bedtime, assume it's the next day
    if (wake < bed) {
      wake = new Date(`2000-01-02T${wakeTime}`);
    }
    
    const diffMs = wake.getTime() - bed.getTime();
    return Math.round(diffMs / (1000 * 60 * 60) * 10) / 10; // Hours with 1 decimal
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const duration = calculateDuration(formData.bedtime, formData.wakeTime);
    
    const newEntry: SleepEntry = {
      id: Date.now().toString(),
      date: formData.date,
      bedtime: formData.bedtime,
      wakeTime: formData.wakeTime,
      duration,
      quality: formData.quality,
      notes: formData.notes,
      created_at: new Date().toISOString()
    };

    const updatedEntries = [...sleepEntries, newEntry];
    setSleepEntries(updatedEntries);
    localStorage.setItem('sleep_entries', JSON.stringify(updatedEntries));
    
    onLogSleep({
      date: newEntry.date,
      bedtime: newEntry.bedtime,
      wakeTime: newEntry.wakeTime,
      duration: newEntry.duration,
      quality: newEntry.quality,
      notes: newEntry.notes
    });

    setIsModalOpen(false);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      bedtime: '22:00',
      wakeTime: '07:00',
      quality: 3,
      notes: ''
    });
  };

  const getAverageSleep = () => {
    if (sleepEntries.length === 0) return 0;
    const total = sleepEntries.reduce((sum, entry) => sum + entry.duration, 0);
    return Math.round((total / sleepEntries.length) * 10) / 10;
  };

  const getAverageQuality = () => {
    if (sleepEntries.length === 0) return 0;
    const total = sleepEntries.reduce((sum, entry) => sum + entry.quality, 0);
    return Math.round((total / sleepEntries.length) * 10) / 10;
  };

  const getQualityColor = (quality: number) => {
    if (quality >= 4) return 'text-green-600';
    if (quality >= 3) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getQualityLabel = (quality: number) => {
    const labels = ['Very Poor', 'Poor', 'Fair', 'Good', 'Excellent'];
    return labels[quality - 1] || 'Unknown';
  };

  const recentEntries = sleepEntries.slice(-7).reverse();
  const averageSleep = getAverageSleep();
  const averageQuality = getAverageQuality();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Sleep Tracking</h2>
          <p className="text-gray-600 mt-1">Monitor your sleep patterns and quality</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <Moon className="w-4 h-4" />
          <span>Log Sleep</span>
        </button>
      </div>

      {/* Sleep Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-indigo-100 rounded-xl">
              <Clock className="h-6 w-6 text-indigo-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Average Sleep</p>
              <p className="text-2xl font-bold text-gray-900">{averageSleep}h</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-yellow-100 rounded-xl">
              <TrendingUp className="h-6 w-6 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Average Quality</p>
              <p className={`text-2xl font-bold ${getQualityColor(averageQuality)}`}>
                {averageQuality}/5
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-blue-100 rounded-xl">
              <Calendar className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Total Entries</p>
              <p className="text-2xl font-bold text-gray-900">{sleepEntries.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Sleep Entries */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Recent Sleep</h3>
        {recentEntries.length === 0 ? (
          <div className="text-center py-12">
            <Moon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No sleep entries</h3>
            <p className="text-gray-600 mb-4">Start tracking your sleep to see patterns</p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
            >
              Log First Entry
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {recentEntries.map((entry) => (
              <div key={entry.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-indigo-100 rounded-lg">
                    <Moon className="h-4 w-4 text-indigo-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">
                      {new Date(entry.date).toLocaleDateString()}
                    </p>
                    <p className="text-sm text-gray-600">
                      {entry.bedtime} - {entry.wakeTime}
                    </p>
                    {entry.notes && (
                      <p className="text-xs text-gray-500 mt-1">{entry.notes}</p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">{entry.duration}h</p>
                  <p className={`text-sm ${getQualityColor(entry.quality)}`}>
                    {getQualityLabel(entry.quality)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Sleep Log Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Log Sleep Entry</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Bedtime</label>
                  <input
                    type="time"
                    value={formData.bedtime}
                    onChange={(e) => setFormData({ ...formData, bedtime: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Wake Time</label>
                  <input
                    type="time"
                    value={formData.wakeTime}
                    onChange={(e) => setFormData({ ...formData, wakeTime: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Sleep Quality ({formData.quality}/5)
                </label>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={formData.quality}
                  onChange={(e) => setFormData({ ...formData, quality: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Very Poor</span>
                  <span>Poor</span>
                  <span>Fair</span>
                  <span>Good</span>
                  <span>Excellent</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes (optional)</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  rows={3}
                  placeholder="How did you sleep? Any factors affecting your sleep?"
                />
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  Log Sleep
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default SleepTracker;