import React, { useState, useEffect } from 'react';
import { Bell, Plus, Edit2, Trash2, Clock, Repeat } from 'lucide-react';

interface Reminder {
  id: string;
  title: string;
  message: string;
  time: string;
  days: string[];
  type: 'workout' | 'meal' | 'water' | 'meditation' | 'sleep';
  enabled: boolean;
  created_at: string;
}

interface ReminderSystemProps {
  onCreateNotification: (title: string, message: string, type: string) => void;
}

const ReminderSystem: React.FC<ReminderSystemProps> = ({ onCreateNotification }) => {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingReminder, setEditingReminder] = useState<Reminder | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    message: '',
    time: '09:00',
    days: [] as string[],
    type: 'workout' as Reminder['type']
  });

  const daysOfWeek = [
    { id: 'monday', label: 'Mon' },
    { id: 'tuesday', label: 'Tue' },
    { id: 'wednesday', label: 'Wed' },
    { id: 'thursday', label: 'Thu' },
    { id: 'friday', label: 'Fri' },
    { id: 'saturday', label: 'Sat' },
    { id: 'sunday', label: 'Sun' }
  ];

  const reminderTypes = [
    { id: 'workout', label: 'Workout', icon: '💪', color: 'blue' },
    { id: 'meal', label: 'Meal', icon: '🍽️', color: 'green' },
    { id: 'water', label: 'Water', icon: '💧', color: 'cyan' },
    { id: 'meditation', label: 'Meditation', icon: '🧘‍♀️', color: 'purple' },
    { id: 'sleep', label: 'Sleep', icon: '😴', color: 'indigo' }
  ];

  useEffect(() => {
    // Load reminders from localStorage
    const savedReminders = localStorage.getItem('fitness_reminders');
    if (savedReminders) {
      setReminders(JSON.parse(savedReminders));
    }
  }, []);

  useEffect(() => {
    // Set up reminder checking
    const checkReminders = () => {
      const now = new Date();
      const currentTime = now.toTimeString().slice(0, 5);
      const currentDay = now.toLocaleDateString('en-US', { weekday: 'lowercase' });

      reminders.forEach(reminder => {
        if (
          reminder.enabled &&
          reminder.time === currentTime &&
          reminder.days.includes(currentDay)
        ) {
          onCreateNotification(reminder.title, reminder.message, reminder.type);
          
          // Browser notification
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(reminder.title, {
              body: reminder.message,
              icon: '/fitness-icon.png'
            });
          }
        }
      });
    };

    const interval = setInterval(checkReminders, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [reminders, onCreateNotification]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const reminderData: Reminder = {
      id: editingReminder?.id || Date.now().toString(),
      title: formData.title,
      message: formData.message,
      time: formData.time,
      days: formData.days,
      type: formData.type,
      enabled: true,
      created_at: editingReminder?.created_at || new Date().toISOString()
    };

    let updatedReminders;
    if (editingReminder) {
      updatedReminders = reminders.map(r => r.id === editingReminder.id ? reminderData : r);
    } else {
      updatedReminders = [...reminders, reminderData];
    }

    setReminders(updatedReminders);
    localStorage.setItem('fitness_reminders', JSON.stringify(updatedReminders));
    
    setIsModalOpen(false);
    setEditingReminder(null);
    setFormData({
      title: '',
      message: '',
      time: '09:00',
      days: [],
      type: 'workout'
    });
  };

  const handleEdit = (reminder: Reminder) => {
    setEditingReminder(reminder);
    setFormData({
      title: reminder.title,
      message: reminder.message,
      time: reminder.time,
      days: reminder.days,
      type: reminder.type
    });
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    const updatedReminders = reminders.filter(r => r.id !== id);
    setReminders(updatedReminders);
    localStorage.setItem('fitness_reminders', JSON.stringify(updatedReminders));
  };

  const toggleReminder = (id: string) => {
    const updatedReminders = reminders.map(r => 
      r.id === id ? { ...r, enabled: !r.enabled } : r
    );
    setReminders(updatedReminders);
    localStorage.setItem('fitness_reminders', JSON.stringify(updatedReminders));
  };

  const handleDayToggle = (day: string) => {
    setFormData(prev => ({
      ...prev,
      days: prev.days.includes(day)
        ? prev.days.filter(d => d !== day)
        : [...prev.days, day]
    }));
  };

  const getReminderTypeInfo = (type: string) => {
    return reminderTypes.find(t => t.id === type) || reminderTypes[0];
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Smart Reminders</h2>
          <p className="text-gray-600 mt-1">Set up personalized reminders for your fitness routine</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Reminder</span>
        </button>
      </div>

      {/* Reminders List */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        {reminders.length === 0 ? (
          <div className="text-center py-12">
            <Bell className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No reminders set</h3>
            <p className="text-gray-600 mb-4">Create your first reminder to stay on track</p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Create Reminder
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {reminders.map((reminder) => {
              const typeInfo = getReminderTypeInfo(reminder.type);
              return (
                <div
                  key={reminder.id}
                  className={`p-4 border rounded-lg transition-all duration-200 ${
                    reminder.enabled ? 'border-gray-200 bg-white' : 'border-gray-100 bg-gray-50 opacity-60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{typeInfo.icon}</span>
                        <div>
                          <h3 className="font-semibold text-gray-900">{reminder.title}</h3>
                          <p className="text-sm text-gray-600">{reminder.message}</p>
                          <div className="flex items-center space-x-4 mt-2">
                            <div className="flex items-center space-x-1 text-sm text-gray-500">
                              <Clock className="w-3 h-3" />
                              <span>{reminder.time}</span>
                            </div>
                            <div className="flex items-center space-x-1 text-sm text-gray-500">
                              <Repeat className="w-3 h-3" />
                              <span>
                                {reminder.days.length === 7 
                                  ? 'Daily' 
                                  : reminder.days.length === 0 
                                    ? 'No days selected'
                                    : reminder.days.map(day => day.slice(0, 3)).join(', ')
                                }
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={reminder.enabled}
                          onChange={() => toggleReminder(reminder.id)}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                      
                      <button
                        onClick={() => handleEdit(reminder)}
                        className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      
                      <button
                        onClick={() => handleDelete(reminder.id)}
                        className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Reminder Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              {editingReminder ? 'Edit Reminder' : 'Create Reminder'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {reminderTypes.map((type) => (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => setFormData({ ...formData, type: type.id as any })}
                      className={`p-3 rounded-lg border text-center transition-colors ${
                        formData.type === type.id
                          ? 'border-blue-500 bg-blue-50 text-blue-900'
                          : 'border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <div className="text-lg mb-1">{type.icon}</div>
                      <div className="text-xs font-medium">{type.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Morning Workout"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  placeholder="e.g., Time for your morning workout! Let's get moving."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                <input
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Repeat on</label>
                <div className="grid grid-cols-7 gap-2">
                  {daysOfWeek.map((day) => (
                    <button
                      key={day.id}
                      type="button"
                      onClick={() => handleDayToggle(day.id)}
                      className={`p-2 rounded-lg text-sm font-medium transition-colors ${
                        formData.days.includes(day.id)
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {day.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingReminder(null);
                    setFormData({
                      title: '',
                      message: '',
                      time: '09:00',
                      days: [],
                      type: 'workout'
                    });
                  }}
                  className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {editingReminder ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReminderSystem;