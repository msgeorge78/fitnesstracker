import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface CalorieData {
  date: string;
  consumed: number;
  burned: number;
  net: number;
}

interface CalorieChartProps {
  data: CalorieData[];
  title?: string;
}

const CalorieChart: React.FC<CalorieChartProps> = ({ data, title = "Weekly Calorie Balance" }) => {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { weekday: 'short' });
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="text-gray-600 text-sm font-medium">{formatDate(label)}</p>
          <div className="space-y-1">
            <p className="text-green-600">
              Consumed: {payload.find((p: any) => p.dataKey === 'consumed')?.value || 0} kcal
            </p>
            <p className="text-red-600">
              Burned: {payload.find((p: any) => p.dataKey === 'burned')?.value || 0} kcal
            </p>
            <p className="text-blue-600 font-semibold">
              Net: {payload.find((p: any) => p.dataKey === 'net')?.value || 0} kcal
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="date" 
              tickFormatter={formatDate}
              stroke="#6b7280"
              fontSize={12}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar dataKey="consumed" fill="#10B981" name="Consumed" />
            <Bar dataKey="burned" fill="#EF4444" name="Burned" />
            <Bar dataKey="net" fill="#3B82F6" name="Net" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default CalorieChart;