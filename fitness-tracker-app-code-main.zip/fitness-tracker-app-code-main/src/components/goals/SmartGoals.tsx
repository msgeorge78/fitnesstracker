import React, { useState } from 'react';
import { Target, Calendar, TrendingUp, Award, Plus, Edit2, Trash2, CheckCircle } from 'lucide-react';

interface SmartGoal {
  id: string;
  title: string;
  description: string;
  category: 'Fitness' | 'Weight' | 'Nutrition' | 'Wellness';
  specific: string;
  measurable: string;
  achievable: string;
  relevant: string;
  timeBound: string;
  targetDate: string;
  progress: number;
  milestones: Milestone[];
  dependencies: string[];
  completed: boolean;
  created_at: string;
}

interface Milestone {
  id: string;
  title: string;
  targetDate: string;
  completed: boolean;
  completedDate?: string;
}

interface SmartGoalsProps {
  goals: any[];
  onAddGoal: (goal: any) => void;
  onUpdateGoal: (id: string, updates: any) => void;
  onDeleteGoal: (id: string) => void;
}

const SmartGoals: React.FC<SmartGoalsProps> = ({ goals, onAddGoal, onUpdateGoal, onDeleteGoal }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<SmartGoal | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Fitness' as SmartGoal['category'],
    specific: '',
    measurable: '',
    achievable: '',
    relevant: '',
    timeBound: '',
    targetDate: '',
    milestones: [] as Milestone[]
  });

  const smartSteps = [
    {
      id: 'specific',
      title: 'Specific',
      description: 'What exactly do you want to accomplish?',
      placeholder: 'e.g., Run a 5K race without stopping'
    },
    {
      id: 'measurable',
      title: 'Measurable',
      description: 'How will you measure progress?',
      placeholder: 'e.g., Complete a 5K distance (3.1 miles) in under 30 minutes'
    },
    {
      id: 'achievable',
      title: 'Achievable',
      description: 'Is this goal realistic and attainable?',
      placeholder: 'e.g., I can currently run 2K, so 5K is challenging but achievable with training'
    },
    {
      id: 'relevant',
      title: 'Relevant',
      description: 'Why is this goal important to you?',
      placeholder: 'e.g., Improve cardiovascular health and build endurance for daily activities'
    },
    {
      id: 'timeBound',
      title: 'Time-bound',
      description: 'When will you achieve this goal?',
      placeholder: 'e.g., Complete the goal within 12 weeks of consistent training'
    }
  ];

  const goalRecommendations = {
    Fitness: [
      'Run a 5K without stopping',
      'Complete 50 push-ups in a row',
      'Attend gym 4 times per week for 3 months',
      'Master 10 yoga poses'
    ],
    Weight: [
      'Lose 10 pounds in 3 months',
      'Gain 5 pounds of muscle mass',
      'Maintain current weight for 6 months',
      'Reduce body fat percentage by 5%'
    ],
    Nutrition: [
      'Eat 5 servings of vegetables daily',
      'Drink 8 glasses of water daily',
      'Meal prep for 4 weeks straight',
      'Reduce sugar intake by 50%'
    ],
    Wellness: [
      'Meditate for 10 minutes daily',
      'Sleep 8 hours per night for 30 days',
      'Practice gratitude journaling daily',
      'Take 10,000 steps daily'
    ]
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const goalData = {
      ...formData,
      progress: 0,
      completed: false
    };

    if (editingGoal) {
      onUpdateGoal(editingGoal.id, goalData);
    } else {
      onAddGoal(goalData);
    }

    setIsModalOpen(false);
    setEditingGoal(null);
    setCurrentStep(1);
    setFormData({
      title: '',
      description: '',
      category: 'Fitness',
      specific: '',
      measurable: '',
      achievable: '',
      relevant: '',
      timeBound: '',
      targetDate: '',
      milestones: []
    });
  };

  const addMilestone = () => {
    const newMilestone: Milestone = {
      id: Date.now().toString(),
      title: '',
      targetDate: '',
      completed: false
    };
    setFormData(prev => ({
      ...prev,
      milestones: [...prev.milestones, newMilestone]
    }));
  };

  const updateMilestone = (index: number, field: keyof Milestone, value: string) => {
    setFormData(prev => ({
      ...prev,
      milestones: prev.milestones.map((milestone, i) => 
        i === index ? { ...milestone, [field]: value } : milestone
      )
    }));
  };

  const removeMilestone = (index: number) => {
    setFormData(prev => ({
      ...prev,
      milestones: prev.milestones.filter((_, i) => i !== index)
    }));
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      Fitness: 'bg-blue-100 text-blue-800',
      Weight: 'bg-green-100 text-green-800',
      Nutrition: 'bg-yellow-100 text-yellow-800',
      Wellness: 'bg-purple-100 text-purple-800'
    };
    return colors[category as keyof typeof colors];
  };

  const calculateGoalScore = (goal: any) => {
    let score = 0;
    if (goal.specific) score += 20;
    if (goal.measurable) score += 20;
    if (goal.achievable) score += 20;
    if (goal.relevant) score += 20;
    if (goal.timeBound) score += 20;
    return score;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">SMART Goals</h2>
          <p className="text-gray-600 mt-1">Create Specific, Measurable, Achievable, Relevant, Time-bound goals</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Create SMART Goal</span>
        </button>
      </div>

      {/* Goal Recommendations */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recommended Goals</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.entries(goalRecommendations).map(([category, recommendations]) => (
            <div key={category} className="space-y-2">
              <h4 className={`text-sm font-medium px-2 py-1 rounded-full inline-block ${getCategoryColor(category)}`}>
                {category}
              </h4>
              <div className="space-y-1">
                {recommendations.map((rec, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setFormData(prev => ({
                        ...prev,
                        title: rec,
                        category: category as any
                      }));
                      setIsModalOpen(true);
                    }}
                    className="block w-full text-left text-sm text-gray-600 hover:text-blue-600 hover:bg-blue-50 p-2 rounded transition-colors"
                  >
                    {rec}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Goals List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {goals.map((goal) => {
          const smartScore = calculateGoalScore(goal);
          return (
            <div key={goal.id} className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(goal.category)}`}>
                      {goal.category}
                    </span>
                    <div className="flex items-center space-x-1">
                      <Award className="w-4 h-4 text-yellow-500" />
                      <span className="text-sm font-medium text-gray-600">{smartScore}% SMART</span>
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{goal.title}</h3>
                  <p className="text-sm text-gray-600 mb-4">{goal.description}</p>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => {
                      setEditingGoal(goal);
                      setFormData({
                        title: goal.title,
                        description: goal.description,
                        category: goal.category,
                        specific: goal.specific || '',
                        measurable: goal.measurable || '',
                        achievable: goal.achievable || '',
                        relevant: goal.relevant || '',
                        timeBound: goal.timeBound || '',
                        targetDate: goal.target_date,
                        milestones: goal.milestones || []
                      });
                      setIsModalOpen(true);
                    }}
                    className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteGoal(goal.id)}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Progress */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Progress</span>
                  <span className="text-sm font-medium text-gray-900">{goal.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-blue-600 to-green-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${goal.progress}%` }}
                  />
                </div>
              </div>

              {/* Target Date */}
              <div className="flex items-center space-x-2 text-sm text-gray-500 mb-4">
                <Calendar className="w-4 h-4" />
                <span>Target: {new Date(goal.target_date).toLocaleDateString()}</span>
              </div>

              {/* SMART Criteria */}
              {smartScore < 100 && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                  <p className="text-sm text-yellow-800 font-medium mb-1">Improve your SMART score:</p>
                  <div className="text-xs text-yellow-700 space-y-1">
                    {!goal.specific && <p>• Add specific details</p>}
                    {!goal.measurable && <p>• Define measurable criteria</p>}
                    {!goal.achievable && <p>• Confirm it's achievable</p>}
                    {!goal.relevant && <p>• Explain why it's relevant</p>}
                    {!goal.timeBound && <p>• Set a clear timeline</p>}
                  </div>
                </div>
              )}

              {/* Complete Goal Button */}
              {!goal.completed && (
                <button
                  onClick={() => onUpdateGoal(goal.id, { completed: true, progress: 100 })}
                  className="w-full mt-4 flex items-center justify-center space-x-2 bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 transition-colors"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Mark Complete</span>
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* SMART Goal Creation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">
                {editingGoal ? 'Edit SMART Goal' : 'Create SMART Goal'}
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Progress Steps */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                {[1, 2, 3, 4, 5, 6].map((step) => (
                  <div
                    key={step}
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      step <= currentStep
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {step}
                  </div>
                ))}
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(currentStep / 6) * 100}%` }}
                />
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {currentStep === 1 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Basic Information</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Goal Title</label>
                    <input
                      type="text"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="e.g., Run a 5K race"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Fitness">Fitness</option>
                      <option value="Weight">Weight</option>
                      <option value="Nutrition">Nutrition</option>
                      <option value="Wellness">Wellness</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      rows={3}
                      placeholder="Brief description of your goal"
                    />
                  </div>
                </div>
              )}

              {currentStep >= 2 && currentStep <= 6 && (
                <div className="space-y-4">
                  {currentStep <= 6 && smartSteps[currentStep - 2] && (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {smartSteps[currentStep - 2].title}
                      </h3>
                      <p className="text-gray-600 mb-4">{smartSteps[currentStep - 2].description}</p>
                      <textarea
                        value={formData[smartSteps[currentStep - 2].id as keyof typeof formData] as string}
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          [smartSteps[currentStep - 2].id]: e.target.value 
                        })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        rows={4}
                        placeholder={smartSteps[currentStep - 2].placeholder}
                        required
                      />
                    </div>
                  )}

                  {currentStep === 6 && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Target Date</label>
                      <input
                        type="date"
                        value={formData.targetDate}
                        onChange={(e) => setFormData({ ...formData, targetDate: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                  )}
                </div>
              )}

              <div className="flex space-x-4 pt-4">
                {currentStep > 1 && (
                  <button
                    type="button"
                    onClick={() => setCurrentStep(currentStep - 1)}
                    className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Previous
                  </button>
                )}
                
                {currentStep < 6 ? (
                  <button
                    type="button"
                    onClick={() => setCurrentStep(currentStep + 1)}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Next
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    {editingGoal ? 'Update Goal' : 'Create Goal'}
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default SmartGoals;