import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2 } from 'lucide-react';

interface VoiceInputProps {
  onResult: (text: string) => void;
  placeholder?: string;
  isActive?: boolean;
  onToggle?: (active: boolean) => void;
}

const VoiceInput: React.FC<VoiceInputProps> = ({ 
  onResult, 
  placeholder = "Click to start voice input", 
  isActive = false,
  onToggle 
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = 'en-US';

      recognitionInstance.onstart = () => {
        setIsListening(true);
        setErrorMessage('');
      };

      recognitionInstance.onresult = (event) => {
        let finalTranscript = '';
        let interimTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }

        setTranscript(finalTranscript + interimTranscript);
        
        if (finalTranscript) {
          onResult(finalTranscript);
        }
      };

      recognitionInstance.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        
        if (event.error === 'no-speech') {
          setErrorMessage('No speech detected. Please: 1) Check your microphone is connected and powered on, 2) Verify microphone permissions in your browser settings, 3) Check system sound input settings, 4) Speak closer to the microphone or louder.');
        } else if (event.error === 'not-allowed') {
          setErrorMessage('Microphone access denied. Please allow microphone permissions.');
        } else if (event.error === 'network') {
          setErrorMessage('Network error. Please check your internet connection.');
        } else {
          setErrorMessage(`Speech recognition error: ${event.error}`);
        }
        
        setIsListening(false);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
      setIsSupported(true);
    } else {
      setIsSupported(false);
    }
  }, [onResult]);

  const toggleListening = () => {
    if (!recognition) return;

    if (isListening) {
      recognition.stop();
      onToggle?.(false);
    } else {
      setTranscript('');
      setErrorMessage('');
      recognition.start();
      onToggle?.(true);
    }
  };

  if (!isSupported) {
    return (
      <div className="flex items-center space-x-2 text-gray-500 text-sm">
        <Volume2 className="w-4 h-4" />
        <span>Voice input not supported in this browser</span>
      </div>
    );
  }

  return (
    <div className="flex items-center space-x-3">
      <button
        onClick={toggleListening}
        className={`flex items-center justify-center w-10 h-10 rounded-full transition-all duration-200 ${
          isListening
            ? 'bg-red-500 text-white animate-pulse'
            : 'bg-blue-500 text-white hover:bg-blue-600'
        }`}
        title={isListening ? 'Stop listening' : 'Start voice input'}
      >
        {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
      </button>
      
      {transcript && (
        <div className="flex-1 p-2 bg-gray-100 rounded-lg">
          <p className="text-sm text-gray-700">{transcript}</p>
        </div>
      )}
      
      {errorMessage && (
        <div className="flex-1 p-2 bg-red-100 border border-red-300 rounded-lg">
          <p className="text-sm text-red-700">{errorMessage}</p>
        </div>
      )}
      
      {!transcript && !isListening && !errorMessage && (
        <p className="text-sm text-gray-500">{placeholder}</p>
      )}
    </div>
  );
};

export default VoiceInput;