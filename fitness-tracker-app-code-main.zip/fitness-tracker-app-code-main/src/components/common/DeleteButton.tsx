import React, { useState } from 'react';
import { Trash2, Undo } from 'lucide-react';

interface DeleteButtonProps {
  onDelete: () => void;
  onUndo?: () => void;
  itemName?: string;
  showUndo?: boolean;
  undoTimeLeft?: number;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'icon' | 'button' | 'text';
}

const DeleteButton: React.FC<DeleteButtonProps> = ({
  onDelete,
  onUndo,
  itemName = 'item',
  showUndo = false,
  undoTimeLeft = 0,
  size = 'md',
  variant = 'icon'
}) => {
  const [isDeleted, setIsDeleted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(undoTimeLeft);

  React.useEffect(() => {
    if (showUndo && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1000) {
            setIsDeleted(false);
            return 0;
          }
          return prev - 1000;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [showUndo, timeLeft]);

  const handleDelete = () => {
    if (confirm(`Are you sure you want to delete this ${itemName}?`)) {
      setIsDeleted(true);
      setTimeLeft(undoTimeLeft);
      onDelete();
    }
  };

  const handleUndo = () => {
    setIsDeleted(false);
    setTimeLeft(0);
    onUndo?.();
  };

  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'w-3 h-3';
      case 'lg':
        return 'w-6 h-6';
      default:
        return 'w-4 h-4';
    }
  };

  const getButtonClasses = () => {
    const baseClasses = 'transition-colors';
    
    switch (variant) {
      case 'button':
        return `${baseClasses} px-3 py-2 rounded-lg border border-red-300 text-red-600 hover:bg-red-50`;
      case 'text':
        return `${baseClasses} text-red-600 hover:text-red-800 underline`;
      default:
        return `${baseClasses} p-2 text-gray-400 hover:text-red-600`;
    }
  };

  if (isDeleted && showUndo) {
    return (
      <div className="flex items-center space-x-2 bg-yellow-50 border border-yellow-200 rounded-lg p-2">
        <span className="text-sm text-yellow-800">
          {itemName} deleted. Undo in {Math.ceil(timeLeft / 1000)}s
        </span>
        <button
          onClick={handleUndo}
          className="flex items-center space-x-1 text-yellow-600 hover:text-yellow-800 transition-colors"
        >
          <Undo className="w-3 h-3" />
          <span className="text-sm">Undo</span>
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={handleDelete}
      className={getButtonClasses()}
      title={`Delete ${itemName}`}
    >
      {variant === 'icon' ? (
        <Trash2 className={getSizeClasses()} />
      ) : (
        <span className="flex items-center space-x-1">
          <Trash2 className={getSizeClasses()} />
          <span>Delete</span>
        </span>
      )}
    </button>
  );
};

export default DeleteButton;