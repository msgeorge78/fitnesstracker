import React from 'react';
import { Achievement } from '../../types/enhanced';
import { Trophy, Lock } from 'lucide-react';

interface AchievementBadgeProps {
  achievement: Achievement;
  size?: 'small' | 'medium' | 'large';
  showProgress?: boolean;
}

const AchievementBadge: React.FC<AchievementBadgeProps> = ({ 
  achievement, 
  size = 'medium',
  showProgress = true 
}) => {
  const sizeClasses = {
    small: 'w-12 h-12 text-lg',
    medium: 'w-16 h-16 text-2xl',
    large: 'w-20 h-20 text-3xl'
  };

  const progressPercentage = (achievement.progress / achievement.target) * 100;

  return (
    <div className="flex flex-col items-center space-y-2">
      <div className="relative">
        <div 
          className={`${sizeClasses[size]} rounded-full flex items-center justify-center border-4 transition-all duration-300 ${
            achievement.unlocked 
              ? 'bg-gradient-to-br from-yellow-400 to-yellow-600 border-yellow-500 shadow-lg' 
              : 'bg-gray-200 border-gray-300'
          }`}
        >
          {achievement.unlocked ? (
            <span className="text-white">{achievement.icon}</span>
          ) : (
            <Lock className="text-gray-500 w-1/2 h-1/2" />
          )}
        </div>
        
        {!achievement.unlocked && showProgress && (
          <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
            <span className="text-white text-xs font-bold">
              {Math.round(progressPercentage)}%
            </span>
          </div>
        )}
      </div>
      
      <div className="text-center">
        <p className={`font-semibold ${achievement.unlocked ? 'text-gray-900' : 'text-gray-500'}`}>
          {achievement.name}
        </p>
        <p className="text-xs text-gray-600 max-w-24 leading-tight">
          {achievement.description}
        </p>
        
        {showProgress && !achievement.unlocked && (
          <div className="mt-1">
            <div className="w-16 bg-gray-200 rounded-full h-1">
              <div 
                className="bg-blue-500 h-1 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(progressPercentage, 100)}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {achievement.progress}/{achievement.target}
            </p>
          </div>
        )}
        
        {achievement.unlocked && achievement.dateEarned && (
          <p className="text-xs text-gray-500 mt-1">
            {new Date(achievement.dateEarned).toLocaleDateString()}
          </p>
        )}
      </div>
    </div>
  );
};

export default AchievementBadge;