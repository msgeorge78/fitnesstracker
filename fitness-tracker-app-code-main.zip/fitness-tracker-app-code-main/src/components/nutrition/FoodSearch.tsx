import React, { useState, useEffect } from 'react';
import { Search, Plus } from 'lucide-react';
import { Food, MealFood } from '../../types/enhanced';
import { searchFoods } from '../../data/foodDatabase';

interface FoodSearchProps {
  onAddFood: (food: MealFood) => void;
  onClose: () => void;
}

const FoodSearch: React.FC<FoodSearchProps> = ({ onAddFood, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Food[]>([]);
  const [selectedFood, setSelectedFood] = useState<Food | null>(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const results = searchFoods(searchQuery);
    setSearchResults(results.slice(0, 10)); // Limit to 10 results
  }, [searchQuery]);

  const handleAddFood = () => {
    if (!selectedFood) return;

    const mealFood: MealFood = {
      foodId: selectedFood.id,
      name: selectedFood.name,
      calories: Math.round(selectedFood.calories * quantity),
      protein: Math.round(selectedFood.protein * quantity * 10) / 10,
      carbs: Math.round(selectedFood.carbs * quantity * 10) / 10,
      fats: Math.round(selectedFood.fats * quantity * 10) / 10,
      quantity,
      servingSize: selectedFood.servingSize
    };

    onAddFood(mealFood);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl p-6 w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Add Food</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search for foods..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Search Results */}
        <div className="flex-1 overflow-y-auto mb-4">
          <div className="grid grid-cols-1 gap-2">
            {searchResults.map((food) => (
              <button
                key={food.id}
                onClick={() => setSelectedFood(food)}
                className={`p-4 border rounded-lg text-left transition-colors ${
                  selectedFood?.id === food.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium text-gray-900">{food.name}</h3>
                    <p className="text-sm text-gray-600">{food.servingSize}</p>
                    <p className="text-sm text-gray-500">{food.category}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{food.calories} kcal</p>
                    <div className="text-xs text-gray-500 space-y-1">
                      <p>P: {food.protein}g</p>
                      <p>C: {food.carbs}g</p>
                      <p>F: {food.fats}g</p>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Food Details */}
        {selectedFood && (
          <div className="border-t pt-4">
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <h3 className="font-semibold text-gray-900 mb-2">{selectedFood.name}</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Quantity
                  </label>
                  <input
                    type="number"
                    min="0.1"
                    step="0.1"
                    value={quantity}
                    onChange={(e) => setQuantity(parseFloat(e.target.value) || 1)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <p className="text-xs text-gray-500 mt-1">{selectedFood.servingSize}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Nutrition (total)</p>
                  <div className="space-y-1 text-sm text-gray-600">
                    <p>Calories: {Math.round(selectedFood.calories * quantity)}</p>
                    <p>Protein: {Math.round(selectedFood.protein * quantity * 10) / 10}g</p>
                    <p>Carbs: {Math.round(selectedFood.carbs * quantity * 10) / 10}g</p>
                    <p>Fats: {Math.round(selectedFood.fats * quantity * 10) / 10}g</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={onClose}
                className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddFood}
                className="flex-1 flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add Food</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FoodSearch;