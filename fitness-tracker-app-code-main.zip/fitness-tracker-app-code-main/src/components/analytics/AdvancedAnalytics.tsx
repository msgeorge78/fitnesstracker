import React, { useState } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Area, AreaChart } from 'recharts';
import { TrendingUp, Download, Calendar, Filter, Target, Activity, Utensils, Scale } from 'lucide-react';

interface AnalyticsData {
  goals: any[];
  workouts: any[];
  meals: any[];
  weightLogs: any[];
}

interface AdvancedAnalyticsProps {
  data: AnalyticsData;
}

const AdvancedAnalytics: React.FC<AdvancedAnalyticsProps> = ({ data }) => {
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('month');
  const [selectedMetric, setSelectedMetric] = useState('overview');

  const generateWeeklyData = () => {
    const days = 7;
    const weekData = [];
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dayWorkouts = data.workouts.filter(w => w.date === dateStr);
      const dayMeals = data.meals.filter(m => m.date === dateStr);
      const dayWeight = data.weightLogs.find(w => w.date === dateStr);
      
      weekData.push({
        date: date.toLocaleDateString('en-US', { weekday: 'short' }),
        workouts: dayWorkouts.length,
        calories: dayMeals.reduce((sum, meal) => sum + meal.calories, 0),
        caloriesBurned: dayWorkouts.reduce((sum, workout) => sum + workout.calories_burned, 0),
        weight: dayWeight?.weight || null,
        duration: dayWorkouts.reduce((sum, workout) => sum + workout.duration, 0)
      });
    }
    
    return weekData;
  };

  const generateMonthlyData = () => {
    const days = 30;
    const monthData = [];
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dayWorkouts = data.workouts.filter(w => w.date === dateStr);
      const dayMeals = data.meals.filter(m => m.date === dateStr);
      
      monthData.push({
        date: date.getDate(),
        workouts: dayWorkouts.length,
        calories: dayMeals.reduce((sum, meal) => sum + meal.calories, 0),
        caloriesBurned: dayWorkouts.reduce((sum, workout) => sum + workout.calories_burned, 0),
        duration: dayWorkouts.reduce((sum, workout) => sum + workout.duration, 0)
      });
    }
    
    return monthData;
  };

  const getWorkoutTypeDistribution = () => {
    const typeCount = data.workouts.reduce((acc, workout) => {
      acc[workout.type] = (acc[workout.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(typeCount).map(([type, count]) => ({
      name: type,
      value: count,
      color: getWorkoutTypeColor(type)
    }));
  };

  const getWorkoutTypeColor = (type: string) => {
    const colors = {
      Cardio: '#EF4444',
      Strength: '#3B82F6',
      Flexibility: '#10B981',
      Sports: '#8B5CF6',
      Other: '#6B7280'
    };
    return colors[type as keyof typeof colors] || '#6B7280';
  };

  const calculateStats = () => {
    const totalWorkouts = data.workouts.length;
    const totalCaloriesBurned = data.workouts.reduce((sum, w) => sum + w.calories_burned, 0);
    const totalDuration = data.workouts.reduce((sum, w) => sum + w.duration, 0);
    const avgWorkoutDuration = totalWorkouts > 0 ? Math.round(totalDuration / totalWorkouts) : 0;
    
    const completedGoals = data.goals.filter(g => g.completed).length;
    const goalCompletionRate = data.goals.length > 0 ? Math.round((completedGoals / data.goals.length) * 100) : 0;
    
    const currentWeight = data.weightLogs.length > 0 ? data.weightLogs[data.weightLogs.length - 1].weight : null;
    const firstWeight = data.weightLogs.length > 0 ? data.weightLogs[0].weight : null;
    const weightChange = currentWeight && firstWeight ? currentWeight - firstWeight : 0;

    return {
      totalWorkouts,
      totalCaloriesBurned,
      avgWorkoutDuration,
      goalCompletionRate,
      weightChange,
      currentWeight
    };
  };

  const exportData = () => {
    const csvData = [
      ['Date', 'Workouts', 'Calories Consumed', 'Calories Burned', 'Duration (min)'],
      ...generateMonthlyData().map(day => [
        day.date,
        day.workouts,
        day.calories,
        day.caloriesBurned,
        day.duration
      ])
    ];

    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fitness-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const chartData = timeRange === 'week' ? generateWeeklyData() : generateMonthlyData();
  const workoutDistribution = getWorkoutTypeDistribution();
  const stats = calculateStats();

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Advanced Analytics</h1>
          <p className="text-gray-600 mt-1">Comprehensive insights into your fitness journey</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex bg-gray-100 rounded-lg p-1">
            {['week', 'month', 'year'].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range as any)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  timeRange === range
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {range.charAt(0).toUpperCase() + range.slice(1)}
              </button>
            ))}
          </div>
          <button
            onClick={exportData}
            className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-blue-100 rounded-xl">
              <Activity className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Total Workouts</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalWorkouts}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-red-100 rounded-xl">
              <TrendingUp className="h-6 w-6 text-red-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Calories Burned</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalCaloriesBurned.toLocaleString()}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-green-100 rounded-xl">
              <Target className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Goal Completion</p>
              <p className="text-2xl font-bold text-gray-900">{stats.goalCompletionRate}%</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-purple-100 rounded-xl">
              <Scale className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Weight Change</p>
              <p className={`text-2xl font-bold ${stats.weightChange >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                {stats.weightChange > 0 ? '+' : ''}{stats.weightChange.toFixed(1)}kg
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Activity Trends */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Activity Trends</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
              <YAxis stroke="#6b7280" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e5e7eb', 
                  borderRadius: '8px' 
                }} 
              />
              <Area 
                type="monotone" 
                dataKey="workouts" 
                stackId="1"
                stroke="#3B82F6" 
                fill="#3B82F6" 
                fillOpacity={0.6}
                name="Workouts"
              />
              <Area 
                type="monotone" 
                dataKey="duration" 
                stackId="2"
                stroke="#10B981" 
                fill="#10B981" 
                fillOpacity={0.6}
                name="Duration (min)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Calorie Balance */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Calorie Balance</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
              <YAxis stroke="#6b7280" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e5e7eb', 
                  borderRadius: '8px' 
                }} 
              />
              <Bar dataKey="calories" fill="#10B981" name="Consumed" />
              <Bar dataKey="caloriesBurned" fill="#EF4444" name="Burned" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Workout Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Workout Type Distribution</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={workoutDistribution}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {workoutDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Performance Insights</h2>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h3 className="font-semibold text-blue-900 mb-2">Most Active Day</h3>
              <p className="text-blue-700">
                {chartData.reduce((max, day) => day.workouts > max.workouts ? day : max, chartData[0])?.date || 'N/A'}
              </p>
            </div>
            
            <div className="p-4 bg-green-50 rounded-lg">
              <h3 className="font-semibold text-green-900 mb-2">Average Workout Duration</h3>
              <p className="text-green-700">{stats.avgWorkoutDuration} minutes</p>
            </div>
            
            <div className="p-4 bg-purple-50 rounded-lg">
              <h3 className="font-semibold text-purple-900 mb-2">Consistency Score</h3>
              <p className="text-purple-700">
                {Math.round((chartData.filter(day => day.workouts > 0).length / chartData.length) * 100)}%
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdvancedAnalytics;