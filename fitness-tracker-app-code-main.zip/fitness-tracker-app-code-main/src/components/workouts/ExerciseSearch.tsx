import React, { useState, useEffect } from 'react';
import { Search, Plus, Clock, Zap } from 'lucide-react';
import { Exercise, WorkoutExercise } from '../../types/enhanced';
import { searchExercises } from '../../data/exerciseDatabase';

interface ExerciseSearchProps {
  onAddExercise: (exercise: WorkoutExercise) => void;
  onClose: () => void;
}

const ExerciseSearch: React.FC<ExerciseSearchProps> = ({ onAddExercise, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Exercise[]>([]);
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  const [exerciseData, setExerciseData] = useState({
    duration: 30,
    sets: 3,
    reps: 10,
    weight: 0,
    restTime: 60
  });

  useEffect(() => {
    const results = searchExercises(searchQuery);
    setSearchResults(results.slice(0, 10));
  }, [searchQuery]);

  const handleAddExercise = () => {
    if (!selectedExercise) return;

    const calories = Math.round(selectedExercise.caloriesPerMinute * exerciseData.duration);

    const workoutExercise: WorkoutExercise = {
      exerciseId: selectedExercise.id,
      name: selectedExercise.name,
      duration: exerciseData.duration,
      calories,
      ...(selectedExercise.category === 'Strength' && {
        sets: exerciseData.sets,
        reps: exerciseData.reps,
        weight: exerciseData.weight || undefined,
        restTime: exerciseData.restTime
      })
    };

    onAddExercise(workoutExercise);
    onClose();
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      Cardio: 'bg-red-100 text-red-800',
      Strength: 'bg-blue-100 text-blue-800',
      Flexibility: 'bg-green-100 text-green-800',
      Sports: 'bg-purple-100 text-purple-800',
      Other: 'bg-gray-100 text-gray-800'
    };
    return colors[category as keyof typeof colors] || colors.Other;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl p-6 w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Add Exercise</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search for exercises..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Search Results */}
        <div className="flex-1 overflow-y-auto mb-4">
          <div className="grid grid-cols-1 gap-2">
            {searchResults.map((exercise) => (
              <button
                key={exercise.id}
                onClick={() => setSelectedExercise(exercise)}
                className={`p-4 border rounded-lg text-left transition-colors ${
                  selectedExercise?.id === exercise.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900">{exercise.name}</h3>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(exercise.category)}`}>
                        {exercise.category}
                      </span>
                      <div className="flex items-center space-x-1 text-xs text-gray-500">
                        <Zap className="w-3 h-3" />
                        <span>{exercise.caloriesPerMinute} kcal/min</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">
                      {exercise.muscleGroups.join(', ')}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Exercise Details */}
        {selectedExercise && (
          <div className="border-t pt-4">
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <h3 className="font-semibold text-gray-900 mb-2">{selectedExercise.name}</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Duration (minutes)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={exerciseData.duration}
                    onChange={(e) => setExerciseData(prev => ({ ...prev, duration: parseInt(e.target.value) || 30 }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Estimated Calories</p>
                  <p className="text-lg font-semibold text-blue-600">
                    {Math.round(selectedExercise.caloriesPerMinute * exerciseData.duration)} kcal
                  </p>
                </div>
              </div>

              {selectedExercise.category === 'Strength' && (
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Sets
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={exerciseData.sets}
                      onChange={(e) => setExerciseData(prev => ({ ...prev, sets: parseInt(e.target.value) || 3 }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Reps
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={exerciseData.reps}
                      onChange={(e) => setExerciseData(prev => ({ ...prev, reps: parseInt(e.target.value) || 10 }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Weight (kg) - Optional
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.5"
                      value={exerciseData.weight}
                      onChange={(e) => setExerciseData(prev => ({ ...prev, weight: parseFloat(e.target.value) || 0 }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Rest Time (seconds)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={exerciseData.restTime}
                      onChange={(e) => setExerciseData(prev => ({ ...prev, restTime: parseInt(e.target.value) || 60 }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              )}

              {selectedExercise.instructions && (
                <div className="mt-4">
                  <p className="text-sm font-medium text-gray-700 mb-1">Instructions</p>
                  <p className="text-sm text-gray-600">{selectedExercise.instructions}</p>
                </div>
              )}
            </div>

            <div className="flex space-x-4">
              <button
                onClick={onClose}
                className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddExercise}
                className="flex-1 flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add Exercise</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExerciseSearch;