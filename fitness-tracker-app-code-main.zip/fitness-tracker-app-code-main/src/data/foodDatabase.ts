import { Food } from '../types/enhanced';

export const foodDatabase: Food[] = [
  // Fruits
  {
    id: 'apple',
    name: 'Apple',
    calories: 52,
    protein: 0.3,
    carbs: 14,
    fats: 0.2,
    servingSize: '1 medium (182g)',
    category: 'Fruits'
  },
  {
    id: 'banana',
    name: 'Banana',
    calories: 89,
    protein: 1.1,
    carbs: 23,
    fats: 0.3,
    servingSize: '1 medium (118g)',
    category: 'Fruits'
  },
  {
    id: 'orange',
    name: 'Orange',
    calories: 47,
    protein: 0.9,
    carbs: 12,
    fats: 0.1,
    servingSize: '1 medium (154g)',
    category: 'Fruits'
  },
  {
    id: 'strawberries',
    name: 'Strawberries',
    calories: 32,
    protein: 0.7,
    carbs: 8,
    fats: 0.3,
    servingSize: '1 cup (152g)',
    category: 'Fruits'
  },
  {
    id: 'blueberries',
    name: 'Blueberries',
    calories: 57,
    protein: 0.7,
    carbs: 14,
    fats: 0.3,
    servingSize: '1 cup (148g)',
    category: 'Fruits'
  },

  // Vegetables
  {
    id: 'broccoli',
    name: 'Broccoli',
    calories: 34,
    protein: 2.8,
    carbs: 7,
    fats: 0.4,
    servingSize: '1 cup chopped (91g)',
    category: 'Vegetables'
  },
  {
    id: 'spinach',
    name: 'Spinach',
    calories: 23,
    protein: 2.9,
    carbs: 3.6,
    fats: 0.4,
    servingSize: '1 cup (30g)',
    category: 'Vegetables'
  },
  {
    id: 'carrots',
    name: 'Carrots',
    calories: 41,
    protein: 0.9,
    carbs: 10,
    fats: 0.2,
    servingSize: '1 medium (61g)',
    category: 'Vegetables'
  },
  {
    id: 'sweet-potato',
    name: 'Sweet Potato',
    calories: 86,
    protein: 1.6,
    carbs: 20,
    fats: 0.1,
    servingSize: '1 medium (128g)',
    category: 'Vegetables'
  },

  // Proteins
  {
    id: 'chicken-breast',
    name: 'Chicken Breast',
    calories: 165,
    protein: 31,
    carbs: 0,
    fats: 3.6,
    servingSize: '100g',
    category: 'Proteins'
  },
  {
    id: 'salmon',
    name: 'Salmon',
    calories: 208,
    protein: 22,
    carbs: 0,
    fats: 12,
    servingSize: '100g',
    category: 'Proteins'
  },
  {
    id: 'eggs',
    name: 'Eggs',
    calories: 155,
    protein: 13,
    carbs: 1.1,
    fats: 11,
    servingSize: '2 large eggs (100g)',
    category: 'Proteins'
  },
  {
    id: 'greek-yogurt',
    name: 'Greek Yogurt',
    calories: 59,
    protein: 10,
    carbs: 3.6,
    fats: 0.4,
    servingSize: '100g',
    category: 'Proteins'
  },
  {
    id: 'tofu',
    name: 'Tofu',
    calories: 76,
    protein: 8,
    carbs: 1.9,
    fats: 4.8,
    servingSize: '100g',
    category: 'Proteins'
  },

  // Grains & Carbs
  {
    id: 'brown-rice',
    name: 'Brown Rice',
    calories: 111,
    protein: 2.6,
    carbs: 23,
    fats: 0.9,
    servingSize: '100g cooked',
    category: 'Grains'
  },
  {
    id: 'quinoa',
    name: 'Quinoa',
    calories: 120,
    protein: 4.4,
    carbs: 22,
    fats: 1.9,
    servingSize: '100g cooked',
    category: 'Grains'
  },
  {
    id: 'oats',
    name: 'Oats',
    calories: 68,
    protein: 2.4,
    carbs: 12,
    fats: 1.4,
    servingSize: '100g cooked',
    category: 'Grains'
  },
  {
    id: 'whole-wheat-bread',
    name: 'Whole Wheat Bread',
    calories: 247,
    protein: 13,
    carbs: 41,
    fats: 4.2,
    servingSize: '100g',
    category: 'Grains'
  },

  // Nuts & Seeds
  {
    id: 'almonds',
    name: 'Almonds',
    calories: 579,
    protein: 21,
    carbs: 22,
    fats: 50,
    servingSize: '100g',
    category: 'Nuts & Seeds'
  },
  {
    id: 'walnuts',
    name: 'Walnuts',
    calories: 654,
    protein: 15,
    carbs: 14,
    fats: 65,
    servingSize: '100g',
    category: 'Nuts & Seeds'
  },
  {
    id: 'chia-seeds',
    name: 'Chia Seeds',
    calories: 486,
    protein: 17,
    carbs: 42,
    fats: 31,
    servingSize: '100g',
    category: 'Nuts & Seeds'
  },

  // Dairy
  {
    id: 'milk',
    name: 'Milk (2%)',
    calories: 50,
    protein: 3.3,
    carbs: 4.8,
    fats: 2,
    servingSize: '100ml',
    category: 'Dairy'
  },
  {
    id: 'cheese-cheddar',
    name: 'Cheddar Cheese',
    calories: 403,
    protein: 25,
    carbs: 1.3,
    fats: 33,
    servingSize: '100g',
    category: 'Dairy'
  }
];

export const searchFoods = (query: string): Food[] => {
  if (!query.trim()) return foodDatabase;
  
  const lowercaseQuery = query.toLowerCase();
  return foodDatabase.filter(food =>
    food.name.toLowerCase().includes(lowercaseQuery) ||
    food.category.toLowerCase().includes(lowercaseQuery)
  );
};

export const getFoodById = (id: string): Food | undefined => {
  return foodDatabase.find(food => food.id === id);
};