import { Exercise } from '../types/enhanced';

export const exerciseDatabase: Exercise[] = [
  // Cardio
  {
    id: 'running',
    name: 'Running',
    category: 'Cardio',
    muscleGroups: ['Legs', 'Core'],
    caloriesPerMinute: 12,
    instructions: 'Maintain steady pace, land on midfoot, keep posture upright'
  },
  {
    id: 'cycling',
    name: 'Cycling',
    category: 'Cardio',
    muscleGroups: ['Legs', 'Glutes'],
    caloriesPerMinute: 10,
    instructions: 'Maintain steady cadence, adjust resistance as needed'
  },
  {
    id: 'swimming',
    name: 'Swimming',
    category: 'Cardio',
    muscleGroups: ['Full Body'],
    caloriesPerMinute: 11,
    instructions: 'Focus on technique, breathe rhythmically'
  },
  {
    id: 'jump-rope',
    name: 'Jump Rope',
    category: 'Cardio',
    muscleGroups: ['Legs', 'Arms', 'Core'],
    caloriesPerMinute: 13,
    instructions: 'Stay on balls of feet, keep elbows close to body'
  },
  {
    id: 'elliptical',
    name: 'Elliptical',
    category: 'Cardio',
    muscleGroups: ['Legs', 'Arms'],
    caloriesPerMinute: 8,
    instructions: 'Maintain upright posture, use arm handles for full body workout'
  },

  // Strength Training
  {
    id: 'push-ups',
    name: 'Push-ups',
    category: 'Strength',
    muscleGroups: ['Chest', 'Triceps', 'Shoulders'],
    caloriesPerMinute: 7,
    instructions: 'Keep body straight, lower chest to ground, push up explosively'
  },
  {
    id: 'squats',
    name: 'Squats',
    category: 'Strength',
    muscleGroups: ['Legs', 'Glutes'],
    caloriesPerMinute: 8,
    instructions: 'Feet shoulder-width apart, lower until thighs parallel to ground'
  },
  {
    id: 'deadlifts',
    name: 'Deadlifts',
    category: 'Strength',
    muscleGroups: ['Back', 'Legs', 'Core'],
    caloriesPerMinute: 9,
    instructions: 'Keep back straight, lift with legs, squeeze glutes at top'
  },
  {
    id: 'bench-press',
    name: 'Bench Press',
    category: 'Strength',
    muscleGroups: ['Chest', 'Triceps', 'Shoulders'],
    caloriesPerMinute: 6,
    instructions: 'Lower bar to chest, press up explosively, keep feet planted'
  },
  {
    id: 'pull-ups',
    name: 'Pull-ups',
    category: 'Strength',
    muscleGroups: ['Back', 'Biceps'],
    caloriesPerMinute: 8,
    instructions: 'Hang from bar, pull chin over bar, lower with control'
  },
  {
    id: 'lunges',
    name: 'Lunges',
    category: 'Strength',
    muscleGroups: ['Legs', 'Glutes'],
    caloriesPerMinute: 7,
    instructions: 'Step forward, lower back knee toward ground, push back to start'
  },
  {
    id: 'planks',
    name: 'Planks',
    category: 'Strength',
    muscleGroups: ['Core', 'Shoulders'],
    caloriesPerMinute: 5,
    instructions: 'Hold straight line from head to heels, engage core'
  },

  // Flexibility
  {
    id: 'yoga-flow',
    name: 'Yoga Flow',
    category: 'Flexibility',
    muscleGroups: ['Full Body'],
    caloriesPerMinute: 3,
    instructions: 'Flow between poses, focus on breath and alignment'
  },
  {
    id: 'stretching',
    name: 'Static Stretching',
    category: 'Flexibility',
    muscleGroups: ['Full Body'],
    caloriesPerMinute: 2,
    instructions: 'Hold stretches for 30 seconds, breathe deeply'
  },
  {
    id: 'pilates',
    name: 'Pilates',
    category: 'Flexibility',
    muscleGroups: ['Core', 'Full Body'],
    caloriesPerMinute: 4,
    instructions: 'Focus on controlled movements and core engagement'
  },

  // Sports
  {
    id: 'basketball',
    name: 'Basketball',
    category: 'Sports',
    muscleGroups: ['Full Body'],
    caloriesPerMinute: 10,
    instructions: 'Mix of running, jumping, and quick movements'
  },
  {
    id: 'tennis',
    name: 'Tennis',
    category: 'Sports',
    muscleGroups: ['Arms', 'Legs', 'Core'],
    caloriesPerMinute: 9,
    instructions: 'Focus on footwork and racket technique'
  },
  {
    id: 'soccer',
    name: 'Soccer',
    category: 'Sports',
    muscleGroups: ['Legs', 'Core'],
    caloriesPerMinute: 11,
    instructions: 'Continuous running with ball control skills'
  }
];

export const searchExercises = (query: string): Exercise[] => {
  if (!query.trim()) return exerciseDatabase;
  
  const lowercaseQuery = query.toLowerCase();
  return exerciseDatabase.filter(exercise =>
    exercise.name.toLowerCase().includes(lowercaseQuery) ||
    exercise.category.toLowerCase().includes(lowercaseQuery) ||
    exercise.muscleGroups.some(group => group.toLowerCase().includes(lowercaseQuery))
  );
};

export const getExerciseById = (id: string): Exercise | undefined => {
  return exerciseDatabase.find(exercise => exercise.id === id);
};

export const getExercisesByCategory = (category: string): Exercise[] => {
  return exerciseDatabase.filter(exercise => exercise.category === category);
};