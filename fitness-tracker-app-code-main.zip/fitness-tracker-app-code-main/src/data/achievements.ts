import { Achievement } from '../types/enhanced';

export const achievementTemplates: Omit<Achievement, 'id' | 'dateEarned' | 'progress' | 'unlocked'>[] = [
  // Consistency Achievements
  {
    name: 'First Steps',
    description: 'Complete your first workout',
    category: 'consistency',
    icon: '🎯',
    target: 1
  },
  {
    name: 'Week Warrior',
    description: 'Work out for 7 consecutive days',
    category: 'consistency',
    icon: '🔥',
    target: 7
  },
  {
    name: 'Month Master',
    description: 'Work out for 30 consecutive days',
    category: 'consistency',
    icon: '💪',
    target: 30
  },
  {
    name: 'Nutrition Novice',
    description: 'Log meals for 3 consecutive days',
    category: 'consistency',
    icon: '🥗',
    target: 3
  },
  {
    name: 'Healthy Habits',
    description: 'Log meals for 7 consecutive days',
    category: 'consistency',
    icon: '🌟',
    target: 7
  },
  {
    name: 'Nutrition Master',
    description: 'Log meals for 30 consecutive days',
    category: 'consistency',
    icon: '👑',
    target: 30
  },

  // Goal Achievements
  {
    name: 'Goal Getter',
    description: 'Complete your first goal',
    category: 'goals',
    icon: '🎯',
    target: 1
  },
  {
    name: 'Achiever',
    description: 'Complete 5 goals',
    category: 'goals',
    icon: '🏆',
    target: 5
  },
  {
    name: 'Goal Crusher',
    description: 'Complete 10 goals',
    category: 'goals',
    icon: '💎',
    target: 10
  },

  // Activity Achievements
  {
    name: 'Getting Started',
    description: 'Complete 5 workouts',
    category: 'activity',
    icon: '🚀',
    target: 5
  },
  {
    name: 'Fitness Enthusiast',
    description: 'Complete 25 workouts',
    category: 'activity',
    icon: '⚡',
    target: 25
  },
  {
    name: 'Workout Warrior',
    description: 'Complete 50 workouts',
    category: 'activity',
    icon: '🔥',
    target: 50
  },
  {
    name: 'Fitness Legend',
    description: 'Complete 100 workouts',
    category: 'activity',
    icon: '👑',
    target: 100
  },
  {
    name: 'Calorie Burner',
    description: 'Burn 1000 calories in workouts',
    category: 'activity',
    icon: '🔥',
    target: 1000
  },
  {
    name: 'Calorie Crusher',
    description: 'Burn 5000 calories in workouts',
    category: 'activity',
    icon: '💥',
    target: 5000
  },

  // Nutrition Achievements
  {
    name: 'Meal Logger',
    description: 'Log 10 meals',
    category: 'nutrition',
    icon: '📝',
    target: 10
  },
  {
    name: 'Nutrition Tracker',
    description: 'Log 50 meals',
    category: 'nutrition',
    icon: '📊',
    target: 50
  },
  {
    name: 'Food Journal Master',
    description: 'Log 100 meals',
    category: 'nutrition',
    icon: '📚',
    target: 100
  },
  {
    name: 'Protein Power',
    description: 'Meet protein goals for 7 days',
    category: 'nutrition',
    icon: '💪',
    target: 7
  },
  {
    name: 'Balanced Eater',
    description: 'Meet all macro goals for 7 days',
    category: 'nutrition',
    icon: '⚖️',
    target: 7
  }
];

export const generateAchievements = (): Achievement[] => {
  return achievementTemplates.map((template, index) => ({
    ...template,
    id: `achievement_${index}`,
    progress: 0,
    unlocked: false
  }));
};

export const checkAchievements = (
  achievements: Achievement[],
  stats: {
    totalWorkouts: number;
    totalMeals: number;
    completedGoals: number;
    totalCaloriesBurned: number;
    workoutStreak: number;
    nutritionStreak: number;
    proteinGoalDays: number;
    macroGoalDays: number;
  }
): Achievement[] => {
  return achievements.map(achievement => {
    let progress = 0;
    
    switch (achievement.name) {
      case 'First Steps':
      case 'Getting Started':
      case 'Fitness Enthusiast':
      case 'Workout Warrior':
      case 'Fitness Legend':
        progress = stats.totalWorkouts;
        break;
      case 'Week Warrior':
      case 'Month Master':
        progress = stats.workoutStreak;
        break;
      case 'Nutrition Novice':
      case 'Healthy Habits':
      case 'Nutrition Master':
        progress = stats.nutritionStreak;
        break;
      case 'Goal Getter':
      case 'Achiever':
      case 'Goal Crusher':
        progress = stats.completedGoals;
        break;
      case 'Meal Logger':
      case 'Nutrition Tracker':
      case 'Food Journal Master':
        progress = stats.totalMeals;
        break;
      case 'Calorie Burner':
      case 'Calorie Crusher':
        progress = stats.totalCaloriesBurned;
        break;
      case 'Protein Power':
        progress = stats.proteinGoalDays;
        break;
      case 'Balanced Eater':
        progress = stats.macroGoalDays;
        break;
    }

    const wasUnlocked = achievement.unlocked;
    const isNowUnlocked = progress >= achievement.target;

    return {
      ...achievement,
      progress: Math.min(progress, achievement.target),
      unlocked: isNowUnlocked,
      dateEarned: isNowUnlocked && !wasUnlocked ? new Date().toISOString() : achievement.dateEarned
    };
  });
};