import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// Check if we have valid Supabase configuration
const isValidUrl = (url: string) => {
  try {
    new URL(url)
    return true
  } catch {
    return false
  }
}

const hasValidConfig = supabaseUrl && 
  supabaseAnonKey && 
  isValidUrl(supabaseUrl) &&
  !supabaseUrl.includes('your_supabase_project_url_here') &&
  !supabaseAnonKey.includes('your_supabase_anon_key_here')

// Only log in development
if (import.meta.env.DEV) {
  console.log('🔧 Supabase Environment Check:');
  console.log('URL exists:', !!supabaseUrl);
  console.log('Key exists:', !!supabaseAnonKey);
  if (supabaseUrl) {
    console.log('URL format:', supabaseUrl.startsWith('https://') ? 'Valid' : 'Invalid - should start with https://');
  }
}

if (!supabaseUrl || !supabaseAnonKey) {
  if (import.meta.env.DEV) {
    console.error('❌ Missing Supabase environment variables');
    console.error('Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your .env file');
  }
  // Don't throw error, let the app handle it gracefully
}

// Only create Supabase client if we have valid configuration
export const supabase = hasValidConfig 
  ? createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce'
  },
  db: {
    schema: 'public'
  },
  global: {
    headers: {
      'X-Client-Info': 'fittracker-pro'
    }
  }
})
  : null

export const isSupabaseConfigured = hasValidConfig


// Types for database tables
export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          name: string;
          height: number | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          name: string;
          height?: number | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          name?: string;
          height?: number | null;
          updated_at?: string;
        };
      };
      goals: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          description: string;
          category: 'Fitness' | 'Weight' | 'Nutrition' | 'Wellness';
          target_date: string;
          progress: number;
          completed: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          title: string;
          description: string;
          category: 'Fitness' | 'Weight' | 'Nutrition' | 'Wellness';
          target_date: string;
          progress?: number;
          completed?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          title?: string;
          description?: string;
          category?: 'Fitness' | 'Weight' | 'Nutrition' | 'Wellness';
          target_date?: string;
          progress?: number;
          completed?: boolean;
          updated_at?: string;
        };
      };
      weight_logs: {
        Row: {
          id: string;
          user_id: string;
          date: string;
          weight: number;
          bmi: number | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          date: string;
          weight: number;
          bmi?: number | null;
          created_at?: string;
        };
        Update: {
          date?: string;
          weight?: number;
          bmi?: number | null;
        };
      };
      meals: {
        Row: {
          id: string;
          user_id: string;
          date: string;
          meal_type: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
          food_name: string;
          calories: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          date: string;
          meal_type: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
          food_name: string;
          calories: number;
          created_at?: string;
        };
        Update: {
          date?: string;
          meal_type?: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
          food_name?: string;
          calories?: number;
        };
      };
      workouts: {
        Row: {
          id: string;
          user_id: string;
          date: string;
          name: string;
          duration: number;
          type: 'Cardio' | 'Strength' | 'Flexibility' | 'Sports' | 'Other';
          calories_burned: number;
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          date: string;
          name: string;
          duration: number;
          type: 'Cardio' | 'Strength' | 'Flexibility' | 'Sports' | 'Other';
          calories_burned: number;
          notes?: string | null;
          created_at?: string;
        };
        Update: {
          date?: string;
          name?: string;
          duration?: number;
          type?: 'Cardio' | 'Strength' | 'Flexibility' | 'Sports' | 'Other';
          calories_burned?: number;
          notes?: string | null;
        };
      };
    };
  };
}