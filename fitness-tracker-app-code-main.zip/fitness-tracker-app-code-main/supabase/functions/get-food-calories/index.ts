import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface RequestBody {
  foodName: string;
  quantity?: string;
}

// Simple calorie estimation database
const calorieDatabase: Record<string, number> = {
  // Fruits (per 100g)
  'apple': 52,
  'banana': 89,
  'orange': 47,
  'grapes': 62,
  'strawberry': 32,
  'blueberry': 57,
  'watermelon': 30,
  'pineapple': 50,
  
  // Vegetables (per 100g)
  'broccoli': 34,
  'carrot': 41,
  'spinach': 23,
  'tomato': 18,
  'cucumber': 16,
  'lettuce': 15,
  'onion': 40,
  'potato': 77,
  
  // Proteins (per 100g)
  'chicken breast': 165,
  'salmon': 208,
  'tuna': 144,
  'beef': 250,
  'pork': 242,
  'egg': 155,
  'tofu': 76,
  
  // Grains & Carbs (per 100g cooked)
  'rice': 130,
  'pasta': 131,
  'bread': 265,
  'oats': 68,
  'quinoa': 120,
  
  // Dairy (per 100g)
  'milk': 42,
  'cheese': 113,
  'yogurt': 59,
  'butter': 717,
  
  // Nuts & Seeds (per 100g)
  'almonds': 579,
  'walnuts': 654,
  'peanuts': 567,
  'sunflower seeds': 584,
  
  // Common foods
  'pizza': 266,
  'hamburger': 295,
  'french fries': 365,
  'chocolate': 546,
  'ice cream': 207,
};

function estimateCalories(foodName: string, quantity: string = '1 serving'): number {
  const normalizedFood = foodName.toLowerCase().trim();
  
  // Try to find exact match first
  let baseCalories = calorieDatabase[normalizedFood];
  
  // If no exact match, try partial matches
  if (!baseCalories) {
    for (const [key, value] of Object.entries(calorieDatabase)) {
      if (normalizedFood.includes(key) || key.includes(normalizedFood)) {
        baseCalories = value;
        break;
      }
    }
  }
  
  // Default calories if no match found
  if (!baseCalories) {
    baseCalories = 100; // Default estimate
  }
  
  // Parse quantity to adjust calories
  const quantityLower = quantity.toLowerCase();
  let multiplier = 1;
  
  if (quantityLower.includes('cup')) {
    multiplier = 1.5; // Rough estimate for 1 cup
  } else if (quantityLower.includes('tablespoon') || quantityLower.includes('tbsp')) {
    multiplier = 0.1;
  } else if (quantityLower.includes('teaspoon') || quantityLower.includes('tsp')) {
    multiplier = 0.03;
  } else if (quantityLower.includes('slice')) {
    multiplier = 0.3;
  } else if (quantityLower.includes('piece') || quantityLower.includes('medium')) {
    multiplier = 1;
  } else if (quantityLower.includes('large')) {
    multiplier = 1.5;
  } else if (quantityLower.includes('small')) {
    multiplier = 0.7;
  }
  
  // Extract numbers from quantity
  const numberMatch = quantity.match(/(\d+(?:\.\d+)?)/);
  if (numberMatch) {
    const number = parseFloat(numberMatch[1]);
    multiplier *= number;
  }
  
  return Math.round(baseCalories * multiplier);
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { foodName, quantity = '1 serving' }: RequestBody = await req.json();

    if (!foodName) {
      return new Response(
        JSON.stringify({ error: 'Food name is required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Use local calorie estimation instead of OpenAI
    const calories = estimateCalories(foodName, quantity);

    return new Response(
      JSON.stringify({ 
        calories,
        foodName,
        quantity 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in get-food-calories function:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Failed to get calorie information',
        details: error.message 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});