# Meditation Videos

This folder contains meditation videos for the wellness hub.

## How to add your video:

1. Place your MP4 file in this folder
2. Name it `meditation-video.mp4` (or update the component to match your filename)
3. The video should be:
   - MP4 format
   - Reasonable file size (under 50MB recommended)
   - Calming/peaceful content suitable for meditation
   - Any resolution (will be automatically scaled)

## Current video setup:
- The meditation timer will look for `/videos/meditation-video.mp4`
- Video will auto-play when meditation starts
- Video will be muted by default to prevent autoplay issues
- Video will loop continuously during meditation
- Timer overlay will display over the video

## Supported formats:
- MP4 (recommended)
- WebM
- OGG

## Tips:
- Keep file size reasonable for web loading
- Consider compressing video for faster loading
- Ensure video content is appropriate for meditation/relaxation
</content>